#![no_std]
#![feature(allocator_api)]
#![feature(nonnull_slice_from_raw_parts)]
#![feature(slice_ptr_get)]
// TODO(yan): See if we still need to allow these once we are done with the
// code. These are stylistic lints that that should improve readability, but
// following them blindly sometimes decreases it.
#![allow(clippy::derive_partial_eq_without_eq)] // tag: style
#![allow(clippy::manual_map)] // tag: style

use core::alloc::{AllocError, Allocator, Layout};
use core::borrow::Borrow;
use core::cell::Cell;
use core::convert::AsRef;
use core::ops::Deref;
use core::ptr::{self, NonNull};

// TODO(yan): Add tests and miri tests.
// TODO(yan): Add benchmarks agains jemalloc/mimalloc.

// TODO(yan): If we ever need to de-genericize a function that wants to take a
// collection allocated in both &'static Linear and Global, we can do a dyn
// allocator, something like:
//
// Dyn(&'static dyn Allocator);
//
// However, gameplay functions only deal with Linear as of now, and editor
// functions at the moment also don't need to support Linear and Global at the
// same time.

#[derive(Debug, Clone, PartialEq)]
pub struct LinearOptions {
    pub fill_with_zeros: bool,
    // TODO(yan): Add grow_fail_on_copy: bool that asserts (or errors) if
    // Linear::grow and Linear::grow_zeroed would copy
    // memory. #[cfg(debug_assertions)] only.
    //
    // TODO(yan): Add grow_record_copy: bool that triggers recording of events
    // when Linear::grow and Linear::grow_zeroed would copy
    // memory. #[cfg(debug_assertions)] only.
}

#[derive(Debug)]
pub struct AllocInitError;

#[derive(Debug, PartialEq, Eq)]
pub struct Linear {
    base: NonNull<u8>,
    head: Cell<NonNull<u8>>,
    capacity: usize,
}

// TODO(yan): Is MIN_ALIGN worth it? We align the address in Linear::allocate
// anyway. Unless there's something safety related I am missing, this only adds
// assertions that any memory managed by linear allocators is aligned to
// MIN_ALIGN. Is this useful for something?
const MIN_ALIGN: usize = 16;

// TODO(yan): @Speed Replace this placeholder with core::intrinsics::unlikely
// for release builds.
#[inline(always)]
fn unlikely(cond: bool) -> bool {
    cond
}

impl Linear {
    /// Creates a new linear allocator governing the provided memory.
    ///
    /// # Safety
    ///
    /// The memory described by the `base` pointer and `capacity` must be
    /// *dereferencable*, as described in [`core::ptr`] module documentation.
    pub unsafe fn new(
        base: NonNull<u8>,
        capacity: usize,
        options: &LinearOptions,
    ) -> Result<Self, AllocInitError> {
        let base_usize = base.as_ptr() as usize;

        {
            // Check that memory is aligned at least to MIN_ALIGN sot that we
            // won't have to align the next request, or any request,
            // potentially, if the caller knows what we are doing here.
            let base_usize_align = next_align(base_usize, MIN_ALIGN).ok_or(AllocInitError)?;
            if base_usize != base_usize_align {
                return Err(AllocInitError);
            }
        }

        {
            // Check that the capacity is sized such that we can allocate
            // objects with MIN_ALIGN immediately after using Linear::split with
            // another aligned capacity.. ugh, is this worth it?
            let capacity_align = next_align(capacity, MIN_ALIGN).ok_or(AllocInitError)?;
            if capacity != capacity_align {
                return Err(AllocInitError);
            }
        }

        // Check we can compute the end of our allocation without overflowing.
        base_usize.checked_add(capacity).ok_or(AllocInitError)?;

        // Fill the memory with zeroes to test access.
        if options.fill_with_zeros {
            NonNull::slice_from_raw_parts(base, capacity)
                .as_mut()
                .fill(0);
        }

        Ok(Self {
            base,
            head: Cell::new(base),
            capacity,
        })
    }

    /// Creates a temporary scope to allocate objects in.
    ///
    /// Once the scope is dropped, the allocator head is reset to the original
    /// position it had at the moment the scope was created.
    ///
    /// Because [`Self::scope_mut`] borrows the allocator uniquely, the
    /// allocator itself can't be used while the scope exists. This allows for
    /// [`LinearScopeMut`] to have no overhead over the underlying linear allocator.
    ///
    /// The following code compiles:
    ///
    /// ```
    /// #![feature(allocator_api)]
    /// use core::ptr::NonNull;
    /// use lfg_alloc::{Linear, LinearOptions};
    ///
    /// let mut linear = unsafe {
    ///     let base = NonNull::new(16 as *mut u8).unwrap();
    ///     let capacity = 16;
    ///     Linear::new(
    ///         base,
    ///         capacity,
    ///         &LinearOptions { fill_with_zeros: false },
    ///     ).unwrap()
    /// };
    ///
    /// let scope = linear.scope_mut();
    /// let vec: Vec<u8, _> = Vec::new_in(&scope);
    /// ```
    ///
    /// But this one correctly doesn't:
    ///
    /// ```compile_fail
    /// #![feature(allocator_api)]
    /// use core::ptr::NonNull;
    /// use lfg_alloc::{Linear, LinearOptions};
    ///
    /// let mut linear = unsafe {
    ///     let base = NonNull::new(16 as *mut u8).unwrap();
    ///     let capacity = 16;
    ///     Linear::new(
    ///         base,
    ///         capacity,
    ///         &LinearOptions { fill_with_zeros: false },
    ///     ).unwrap()
    /// };
    ///
    /// let scope = linear.scope_mut();             // <-- mutable borrow
    /// let vec: Vec<u8, _> = Vec::new_in(&linear); // <-- immutable borrow
    /// ```
    pub fn scope_mut(&mut self) -> LinearScopeMut<'_> {
        let head_restore = Cell::new(self.head.get());
        LinearScopeMut {
            linear: self,
            head_restore,
        }
    }

    // TODO(yan): @Corrrectness This alone needs a lot of stress testing. There
    // might be cases we missed and it might be completely unsafe to use.
    /// Creates a temporary scope to allocate objects in.
    ///
    /// This is like [`Self::scope_mut`], but does runtime checks on each use to
    /// track if it is still safe to reset the allocator head to the original
    /// position it had at the moment the scope was created.
    ///
    /// If the checks detect an inconsistency, it is assumed the that the
    /// underlying allocator was modified while the scope existed, and the head
    /// pointer will not be reset.
    ///
    /// To verify if the reset will happen on drop, use
    /// [`LinearScopeChecked::can_restore`] and
    /// [`LinearscopeChecked::drop_and_report_can_restore`].
    pub fn scope_checked(&self) -> LinearScopeChecked<'_> {
        LinearScopeChecked {
            linear: self,
            head_restore: Cell::new(self.head.get()),
            head_last: Cell::new(self.head.get()),
            can_restore: Cell::new(true),
        }
    }

    /// Splits a linear allocator with a certain capacity from this one. Returns
    /// error, if there is not enough capacity, the alignment doesn't match, or
    /// the split point is inside already allocated data.
    pub fn split(&mut self, split_capacity: usize) -> Result<Self, AllocInitError> {
        {
            // Check that the capacity is correctly sized to allocate objects with
            // MIN_ALIGN.
            let split_capacity_align =
                next_align(split_capacity, MIN_ALIGN).ok_or(AllocInitError)?;

            if split_capacity != split_capacity_align {
                return Err(AllocInitError);
            }
        }

        // Can't give memory you don't have.
        if self.capacity < split_capacity {
            return Err(AllocInitError);
        }

        let new_self_capacity = self.capacity.saturating_sub(split_capacity);

        // If we already allocated something, we check whether we have enough
        // remaining capacity left.
        let split_base = unsafe { self.base.as_ptr().add(new_self_capacity) };
        if split_base < self.head.get().as_ptr() {
            return Err(AllocInitError);
        }

        let split_base = unsafe { NonNull::new_unchecked(split_base) };
        let split_head = split_base;

        let split_allocator = Self {
            base: split_base,
            head: Cell::new(split_head),
            capacity: split_capacity,
        };

        self.capacity = new_self_capacity;

        Ok(split_allocator)
    }

    /// Joins another linear allocator that was previously split with
    /// [`Linear::split`]. Returns error, if the allocators do not match.
    pub fn join(&mut self, tail: Linear) -> Result<(), AllocInitError> {
        if self.base.as_ptr() as usize + self.capacity != tail.base.as_ptr() as usize {
            return Err(AllocInitError);
        }

        self.capacity += tail.capacity;

        Ok(())
    }

    /// Returns all available memory in this allocator in bytes.
    pub fn capacity(&self) -> usize {
        self.capacity
    }

    pub fn used_capacity(&self) -> usize {
        let head = self.head.get().as_ptr() as usize;
        let base = self.base.as_ptr() as usize;

        debug_assert!(base <= head);
        head - base
    }

    /// Returns remaining available memory in this allocator in bytes.
    pub fn remaining_capacity(&self) -> usize {
        let head = self.head.get().as_ptr() as usize;
        let base = self.base.as_ptr() as usize;
        let end = base + self.capacity;

        debug_assert!(head <= end);
        end - head
    }

    /// Resets the allocator, moving the head pointer back to the beginning.
    pub fn reset(&mut self) {
        self.head.set(self.base);
    }

    /// Attempts to allocate memory.
    ///
    /// Allocating can fail, if there is not enough memory, in which
    /// case [`AllocError`] is returned.
    #[inline]
    pub fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        let head = self.head.get().as_ptr() as usize;
        let base = self.base.as_ptr() as usize;
        let end = base + self.capacity;

        let ptr = next_align(head, layout.align()).ok_or(AllocError)?;

        let new_head = ptr.checked_add(layout.size()).ok_or(AllocError)?;
        if new_head > end {
            return Err(AllocError);
        }

        self.head
            .set(unsafe { NonNull::new_unchecked(new_head as *mut u8) });

        let ptr = unsafe { NonNull::new_unchecked(ptr as *mut u8) };

        Ok(NonNull::slice_from_raw_parts(ptr, layout.size()))
    }

    /// Attempts to deallocate memory.
    ///
    /// Since this is a linear allocator, it avoids work that amounts to more
    /// than just simple pointer arithmetic.
    ///
    /// Deallocating always succeeds, but memory is only reclamied if this is
    /// the last allocation.
    ///
    /// # Safety
    ///
    /// See [`Allocator::deallocate`].
    #[inline]
    pub unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // We could theoretically reset further back, because we might have
        // inserted alignment padding at the beginning of this allocation, but
        // we don't remember.
        if self.is_last_allocation(ptr, layout) {
            self.head.set(ptr);
        }
    }

    /// Attempts to grow allocation.
    ///
    /// Since this is a linear allocator, it avoids work that amounts to more
    /// than just simple pointer arithmetic.
    ///
    /// [`Self::grow`] (and [`Self::grow_zeroed`]) is the only exception to the
    /// above: if growing would fail, because this is not the last allocation,
    /// the allocator falls back to [`Self::allocate`] and copies the data to
    /// the new memory.
    ///
    /// Growing can also fail, if there is not enough memory to grow, in which
    /// case [`AllocError`] is returned.
    ///
    /// While [`Allocator::grow`] does not require `new_layout.align()` to be
    /// smaller or equal to `old_layout.align()`, this allocator does, and
    /// returns [`AllocError`] in this case.
    ///
    /// # Safety
    ///
    /// See [`Allocator::grow`].
    #[inline]
    pub unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        if unlikely(old_layout.align() < new_layout.align()) {
            return Err(AllocError);
        }

        // Safety docs of Allocator::grow say new size *must* be GTE old size,
        // so we don't have to validate that for correctness.
        #[cfg(debug_assertions)]
        if unlikely(old_layout.size() > new_layout.size()) {
            return Err(AllocError);
        }

        if self.is_last_allocation(ptr, old_layout) {
            // ptr is assumed to have been produced by this allocator, and
            // therefore already properly aligned. New size is checked to be GTE
            // old size. We can therefore compute the new head by offsetting the
            // provided pointer without knowing, where the current head is.

            let base = self.base.as_ptr() as usize;
            let end = base + self.capacity;

            let new_head = (ptr.as_ptr() as usize)
                .checked_add(new_layout.size())
                .ok_or(AllocError)?;
            if new_head > end {
                return Err(AllocError);
            }

            self.head.set(NonNull::new_unchecked(new_head as *mut u8));

            Ok(NonNull::slice_from_raw_parts(ptr, new_layout.size()))
        } else {
            let new_ptr = self.allocate(new_layout)?;

            // SAFETY: This is ok, because Self::allocate always gives fresh
            // memory, so the regions won't overlap.
            ptr::copy_nonoverlapping(
                ptr.as_ptr(),
                new_ptr.as_non_null_ptr().as_ptr(),
                old_layout.size(),
            );

            Ok(new_ptr)
        }
    }

    /// Same as [`Self::grow`], but also fills memory with zeros.
    ///
    /// # Safety
    ///
    /// See [`Allocator::grow_zeroed`].
    #[inline]
    pub unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        let mut result = self.grow(ptr, old_layout, new_layout)?;
        result.as_mut()[old_layout.size()..].fill(0);

        Ok(result)
    }

    /// Attempts to shrink allocation.
    ///
    /// Since this is a linear allocator, it avoids work that amounts to more
    /// than just simple pointer arithmetic.
    ///
    /// Shrinking always succeeds, but memory is only reclamied if this is
    /// the last allocation.
    ///
    /// While [`Allocator::shrink`] does not require `new_layout.align()` to be
    /// smaller or equal to `old_layout.align()`, this allocator does, and
    /// returns [`AllocError`] in this case.
    ///
    /// # Safety
    ///
    /// See [`Allocator::shrink`].
    #[inline]
    pub unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        if unlikely(old_layout.align() < new_layout.align()) {
            // Even if we could satisfy layouts with larger alignments by
            // reallocating to a fresh allocation, we won't. Shrinking should be
            // as cheap as possible.
            return Err(AllocError);
        }

        // Safety docs of Allocator::shrink say new size *must* be LTE old size,
        // so we don't have to validate that for correctness.
        #[cfg(debug_assertions)]
        if unlikely(old_layout.size() < new_layout.size()) {
            return Err(AllocError);
        }

        if self.is_last_allocation(ptr, old_layout) {
            // ptr is assumed to have been produced by this allocator, and
            // therefore already properly aligned. New size is checked to be LTE
            // old size. We can therefore compute the new head by offsetting the
            // provided pointer without knowing, where the current head is.

            let base = self.base.as_ptr() as usize;
            let end = base + self.capacity;

            // No need for overflow checks or bounds checks - new size is LTE
            // old size and we'd fail allocating the original region already, if
            // this overflowed.
            let new_head = ptr.as_ptr() as usize + new_layout.size();
            debug_assert!(new_head <= end);

            self.head.set(NonNull::new_unchecked(new_head as *mut u8));
        }

        Ok(NonNull::slice_from_raw_parts(ptr, new_layout.size()))
    }

    #[inline]
    fn is_last_allocation(&self, ptr: NonNull<u8>, layout: Layout) -> bool {
        // Assuming the caller gave us correct data, we can reason about the
        // following:
        //
        // When we make an allocation, we have a head, which is not necessarilly
        // aligned to carry out the requested allocation. We next_align this
        // head to produce a pointer which fits the requested alignment, and
        // give it to the user. From this pointer, we compute a new head by
        // adding requested size and not adding any padding.
        //
        // Because we don't have to reconstruct the old head, but only validate
        // the pointer, we can just repeat the neccessary computations here
        // again and see if we get to the current head.
        let ptr = ptr.as_ptr() as usize;
        // No need for overflow checks - we'd fail allocating this in the first
        // place it if overflowed.
        let new_head = ptr + layout.size();

        self.head.get().as_ptr() as usize == new_head
    }
}

unsafe impl Allocator for Linear {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        Linear::allocate(self, layout)
    }

    // Allocator::allocate_zeroed has a default we can't improve upon.

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        Linear::deallocate(self, ptr, layout)
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        Linear::grow(self, ptr, old_layout, new_layout)
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        Linear::grow_zeroed(self, ptr, old_layout, new_layout)
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        Linear::shrink(self, ptr, old_layout, new_layout)
    }
}

/// A scoped linear allocator, branched from [`Linear`] via
/// [`Linear::scope_mut`].
#[derive(Debug, PartialEq, Eq)]
pub struct LinearScopeMut<'a> {
    linear: &'a mut Linear,
    head_restore: Cell<NonNull<u8>>,
}

// LinearScopeMut implements Borrow, AsRef, Deref, so clients can get to the
// underlying linear allocator and not have to make their functions generic over
// allocators.
//
// LinearScopeMut does *not* implement BorrowMut, AsMut and DerefMut, because
// that would give clients access to a &mut Linear, which is too many
// capabilities like join/split, ..

impl<'a> Borrow<Linear> for LinearScopeMut<'a> {
    fn borrow(&self) -> &Linear {
        &self.linear
    }
}

impl<'a> AsRef<Linear> for LinearScopeMut<'a> {
    fn as_ref(&self) -> &Linear {
        &self.linear
    }
}

impl<'a> Deref for LinearScopeMut<'a> {
    type Target = Linear;

    fn deref(&self) -> &Linear {
        &self.linear
    }
}

// Note: we implement and forward all allocator methods, even if Linear
// sometimes defaults, just to be safe. This is not stricly necessary here, but
// is crucial to LinearScopeChecked.
unsafe impl<'a> Allocator for LinearScopeMut<'a> {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        Linear::allocate(&self.linear, layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        Linear::allocate_zeroed(&self.linear, layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        Linear::deallocate(&self.linear, ptr, layout)
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        Linear::grow(&self.linear, ptr, old_layout, new_layout)
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        Linear::grow_zeroed(&self.linear, ptr, old_layout, new_layout)
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        Linear::shrink(&self.linear, ptr, old_layout, new_layout)
    }
}

impl<'a> Drop for LinearScopeMut<'a> {
    fn drop(&mut self) {
        self.linear.head.set(self.head_restore.get());
    }
}

/// A scoped linear allocator, branched from [`Linear`] via
/// [`Linear::scope_checked`].
#[derive(Debug, PartialEq, Eq)]
pub struct LinearScopeChecked<'a> {
    linear: &'a Linear,
    head_restore: Cell<NonNull<u8>>,
    head_last: Cell<NonNull<u8>>,
    can_restore: Cell<bool>,
}

impl<'a> LinearScopeChecked<'a> {
    pub fn can_restore(&self) -> bool {
        self.can_restore.get()
    }

    pub fn drop_and_report_can_restore(self) -> bool {
        // The underlying allocator still might have been used after we stopped
        // using scope, so we need to check.
        self.can_restore.get() && self.head_last == self.linear.head
    }
}

// Note: we implement and forward all allocator methods, this is crucial for our
// attempts to detect circumventive usage of Linear while this scope exists.
unsafe impl<'a> Allocator for LinearScopeChecked<'a> {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        if self.head_last != self.linear.head {
            self.can_restore.set(false);
        }

        let result = Linear::allocate(&self.linear, layout);

        self.head_last.set(self.linear.head.get());

        result
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        if self.head_last != self.linear.head {
            self.can_restore.set(false);
        }

        let result = Linear::allocate_zeroed(&self.linear, layout);

        self.head_last.set(self.linear.head.get());

        result
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        if self.head_last != self.linear.head {
            self.can_restore.set(false);
        }

        let result = Linear::deallocate(&self.linear, ptr, layout);

        self.head_last.set(self.linear.head.get());

        result
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        if self.head_last != self.linear.head {
            self.can_restore.set(false);
        }

        let result = Linear::grow(&self.linear, ptr, old_layout, new_layout);

        self.head_last.set(self.linear.head.get());

        result
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        if self.head_last != self.linear.head {
            self.can_restore.set(false);
        }

        let result = Linear::grow_zeroed(&self.linear, ptr, old_layout, new_layout);

        self.head_last.set(self.linear.head.get());

        result
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        if self.head_last != self.linear.head {
            self.can_restore.set(false);
        }

        let result = Linear::shrink(&self.linear, ptr, old_layout, new_layout);

        self.head_last.set(self.linear.head.get());

        result
    }
}

impl<'a> Drop for LinearScopeChecked<'a> {
    fn drop(&mut self) {
        if self.can_restore.get() {
            // The underlying allocator still might have been used after we stopped
            // using scope, so we need to check.
            if self.head_last == self.linear.head {
                self.linear.head.set(self.head_restore.get());
            }
        }
    }
}

#[inline]
fn next_align(n: usize, align: usize) -> Option<usize> {
    debug_assert!(align > 0);
    debug_assert!(align.is_power_of_two());

    let mask = align - 1;

    match n.checked_add(mask) {
        Some(inc) => Some(inc & !mask),
        None => None,
    }
}
