#![no_std]
#![feature(const_num_from_num)]
#![feature(const_trait_impl)]

mod color;

use core::cmp::Ordering;
use core::fmt;
use core::mem;
use core::ops::{Add, Deref, Sub};

pub use color::{color_array, color_u32, Color};
pub use glam::*;
use lfg_common::static_assert;
pub use libm;

// TODO(yan): Use f32::to_radians instead, if it ever gets constified.
#[macro_export]
macro_rules! const_radians {
    ($value:expr) => {
        $value * core::f32::consts::PI / 180.0_f32
    };
}

// TODO(yan): Use glam::Vec2 internally in Rect to get SIMD
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct Rect {
    x: f32,
    y: f32,
    width: f32,
    height: f32,
}

impl Rect {
    pub const ZERO: Self = Self {
        x: 0.0,
        y: 0.0,
        width: 0.0,
        height: 0.0,
    };

    pub const ONE: Self = Self {
        x: 0.0,
        y: 0.0,
        width: 1.0,
        height: 1.0,
    };

    #[inline]
    pub fn new(x: f32, y: f32, width: f32, height: f32) -> Self {
        assert!(width >= 0.0);
        assert!(height >= 0.0);

        Self {
            x,
            y,
            width,
            height,
        }
    }

    #[inline]
    pub const fn const_new(x: i16, y: i16, width: u16, height: u16) -> Self {
        // NB: Maintains invariants of Rect::new by using integer types as
        // params. i16/u16 can be losslessly cast to f32 and u16 is nonnegative.
        Self {
            x: x as f32,
            y: y as f32,
            width: width as f32,
            height: height as f32,
        }
    }

    #[inline]
    pub fn from_points(point_a: Vec2, point_b: Vec2) -> Self {
        let min_point = point_a.min(point_b);
        let max_point = point_a.max(point_b);
        let size = max_point - min_point;

        Self {
            x: min_point.x,
            y: min_point.y,
            width: size.x,
            height: size.y,
        }
    }

    /// Fits rectangle with `inner_size` dimensions into a rectangle with
    /// `outer_size` dimensions, performing uniform scaling and letterboxing if
    /// necessary.
    ///
    /// This is the same as CSS
    /// [`object-fit: contain`](https://developer.mozilla.org/en-US/docs/Web/CSS/object-fit).
    #[inline]
    pub fn contain(inner_size: Vec2, outer_size: Vec2) -> Self {
        // Note: these asserts really mean GT, not GTE to prevent production of
        // infinities and NaNs later on.
        assert!(inner_size.x > 0.0);
        assert!(inner_size.y > 0.0);
        assert!(outer_size.x > 0.0);
        assert!(outer_size.y > 0.0);

        let inner_width = inner_size.x;
        let inner_height = inner_size.y;
        let outer_width = outer_size.x;
        let outer_height = outer_size.y;

        let inner_aspect = inner_size.x / inner_size.y;
        let outer_aspect = outer_size.x / outer_size.y;

        if outer_aspect > inner_aspect {
            // Outer is wider than inner, pad out the sides.
            let inner_to_outer = outer_height / inner_height;
            let width = inner_width * inner_to_outer;
            let x = (outer_width - width) / 2.0;

            Self {
                x,
                y: 0.0,
                width,
                height: outer_height,
            }
        } else {
            // Inner is wider than the outer, pad out top and bottom.
            let inner_to_outer = outer_width / inner_width;
            let height = inner_height * inner_to_outer;
            let y = (outer_height - height) / 2.0;

            Self {
                x: 0.0,
                y,
                width: outer_width,
                height,
            }
        }
    }

    #[inline]
    pub fn extend_by_point(&self, point: Vec2) -> Self {
        let min_point = self.min_point().min(point);
        let max_point = self.max_point().max(point);
        let size = max_point - min_point;

        Self {
            x: min_point.x,
            y: min_point.y,
            width: size.x,
            height: size.y,
        }
    }

    #[inline]
    pub fn extend_by_rect(&self, rect: Self) -> Self {
        let min_point = self.min_point().min(rect.min_point());
        let max_point = self.max_point().max(rect.max_point());
        let size = max_point - min_point;

        Self {
            x: min_point.x,
            y: min_point.y,
            width: size.x,
            height: size.y,
        }
    }

    // TODO(yan): Make vector versions of Rect::inset, Rect::offset and Rect::scale?

    #[inline]
    pub fn inset(&self, amount: f32) -> Self {
        assert!(amount >= 0.0);

        let x = f32::clamp(self.x + amount, self.x, self.max_x());
        let y = f32::clamp(self.y + amount, self.y, self.max_y());
        let width = f32::clamp(self.width - 2.0 * amount, 0.0, self.width);
        let height = f32::clamp(self.height - 2.0 * amount, 0.0, self.height);

        Self::new(x, y, width, height)
    }

    #[inline]
    pub fn offset(&self, amount: f32) -> Self {
        assert!(amount >= 0.0);

        Self::new(
            self.x - amount,
            self.y - amount,
            self.width + 2.0 * amount,
            self.height + 2.0 * amount,
        )
    }

    // TODO(yan): Consider making this an ops::Mul/ops::Div and automatically
    // flip for negative scales?
    #[inline]
    pub fn scale(&self, amount: f32) -> Self {
        assert!(amount >= 0.0);

        Self {
            x: self.x * amount,
            y: self.y * amount,
            width: self.width * amount,
            height: self.height * amount,
        }
    }

    /// Clamps a point to lie inside this rectangle.
    ///
    /// If the point initially does no lie inside this rectangle, it is moved to
    /// lie on its edge.
    #[inline]
    pub fn clamp_point(&self, point: Vec2) -> Vec2 {
        point.clamp(self.min_point(), self.max_point())
    }

    /// Clamps another rectangle to fit inside this one.
    ///
    /// If the other rectangle has no intersection with this rectangle, a
    /// zero-area rectangle lying on the edge of this one is produced.
    #[inline]
    pub fn clamp_rect(&self, rect: Self) -> Self {
        Rect::from_points(
            self.clamp_point(rect.min_point()),
            self.clamp_point(rect.max_point()),
        )
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.width == 0.0 || self.height == 0.0
    }

    #[inline]
    pub fn contains_point(&self, point: Vec2) -> bool {
        let contains_x = self.x <= point.x && self.max_x() >= point.x;
        let contains_y = self.y <= point.y && self.max_y() >= point.y;

        contains_x && contains_y
    }

    #[inline]
    pub fn contains_rect(&self, rect: Self) -> bool {
        let contains_x = self.x <= rect.x && self.max_x() >= rect.max_x();
        let contains_y = self.y <= rect.y && self.max_y() >= rect.max_y();

        contains_x && contains_y
    }

    #[inline]
    pub fn intersects_rect(&self, rect: Self) -> bool {
        let intersects_x = self.x <= rect.max_x() && self.max_x() >= rect.x;
        let intersects_y = self.y <= rect.max_y() && self.max_y() >= rect.y;

        intersects_x && intersects_y
    }

    #[inline]
    pub fn max_x(&self) -> f32 {
        self.x + self.width
    }

    #[inline]
    pub fn max_y(&self) -> f32 {
        self.y + self.height
    }

    #[inline]
    pub fn min_point(&self) -> Vec2 {
        Vec2::new(self.x, self.y)
    }

    #[inline]
    pub fn max_point(&self) -> Vec2 {
        Vec2::new(self.x + self.width, self.y + self.height)
    }

    #[inline]
    pub fn size(&self) -> Vec2 {
        Vec2::new(self.width, self.height)
    }
}

// TODO(yan): Impl ops::XYZAssign<Vec2> for Rect

impl Add<Vec2> for Rect {
    type Output = Self;

    #[inline]
    fn add(self, other: Vec2) -> Self {
        Self {
            x: self.x + other.x,
            y: self.y + other.y,
            width: self.width,
            height: self.height,
        }
    }
}

impl Sub<Vec2> for Rect {
    type Output = Self;

    #[inline]
    fn sub(self, other: Vec2) -> Self {
        Self {
            x: self.x - other.x,
            y: self.y - other.y,
            width: self.width,
            height: self.height,
        }
    }
}

impl fmt::Display for Rect {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(
            f,
            "Rect {{ x: {}, y: {}, width: {}, height: {} }}",
            self.x, self.y, self.width, self.height,
        )
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct RectDeref {
    pub x: f32,
    pub y: f32,
    pub width: f32,
    pub height: f32,
}

static_assert!(mem::size_of::<Rect>() == 16);
static_assert!(mem::size_of::<RectDeref>() == 16);

impl Deref for Rect {
    type Target = RectDeref;

    #[inline]
    fn deref(&self) -> &Self::Target {
        bytemuck::cast_ref(self)
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct IRect {
    x: i32,
    y: i32,
    width: i32,
    height: i32,
}

impl IRect {
    pub const ZERO: IRect = IRect {
        x: 0,
        y: 0,
        width: 0,
        height: 0,
    };

    pub const ONE: IRect = IRect {
        x: 0,
        y: 0,
        width: 1,
        height: 1,
    };

    #[inline]
    pub fn new(x: i32, y: i32, width: i32, height: i32) -> Self {
        assert!(width >= 0);
        assert!(height >= 0);

        Self {
            x,
            y,
            width,
            height,
        }
    }

    #[inline]
    pub const fn const_new(x: i32, y: i32, width: u16, height: u16) -> Self {
        // NB: Maintains invariants of IRect::new by using integer types as
        // params. i32/u16 can be losslessly cast to i32 and u16 is nonnegative.
        IRect {
            x,
            y,
            width: i32::from(width),
            height: i32::from(height),
        }
    }

    #[inline]
    pub fn as_rect(&self) -> Rect {
        Rect {
            x: self.x as f32,
            y: self.y as f32,
            width: self.width as f32,
            height: self.height as f32,
        }
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct IRectDeref {
    pub x: i32,
    pub y: i32,
    pub width: i32,
    pub height: i32,
}

static_assert!(mem::size_of::<IRect>() == 16);
static_assert!(mem::size_of::<IRectDeref>() == 16);

impl Deref for IRect {
    type Target = IRectDeref;

    #[inline]
    fn deref(&self) -> &Self::Target {
        bytemuck::cast_ref(self)
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct Plane {
    normal: Vec3,
    distance: f32,
}

impl Plane {
    #[inline]
    pub fn new(normal: Vec3, distance: f32) -> Self {
        assert_ne!(normal, Vec3::ZERO);

        Self {
            normal: normal.normalize(),
            distance,
        }
    }

    #[inline]
    pub fn from_normal_origin(normal: Vec3, origin: Vec3) -> Self {
        assert_ne!(normal, Vec3::ZERO);

        let normal = normal.normalize();
        let distance = normal.dot(origin);

        Self { normal, distance }
    }

    #[inline]
    pub fn ray_intersection(&self, ray_origin: Vec3, ray_direction: Vec3) -> Option<Vec3> {
        assert_ne!(ray_direction, Vec3::ZERO);

        let o = ray_origin;
        let d = ray_direction.normalize();

        let cos_theta = d.dot(self.normal);
        if libm::fabsf(cos_theta) < f32::EPSILON {
            // The ray is parallel to our plane.
            return None;
        }

        let op_signed_distance = o.dot(self.normal) - self.distance;
        let oi_signed_distance = -op_signed_distance / cos_theta;

        Some(o + d * oi_signed_distance)
    }
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct PlaneDeref {
    pub normal: Vec3,
    pub distance: f32,
}

static_assert!(mem::size_of::<Plane>() == 16);
static_assert!(mem::size_of::<PlaneDeref>() == 16);

impl Deref for Plane {
    type Target = PlaneDeref;

    #[inline]
    fn deref(&self) -> &Self::Target {
        bytemuck::cast_ref(self)
    }
}

#[inline]
pub fn cmp_f32(left: f32, right: f32) -> Ordering {
    debug_assert!(!left.is_nan());
    debug_assert!(!right.is_nan());

    left.partial_cmp(&right).unwrap_or_else(|| {
        if left.is_nan() && right.is_nan() {
            Ordering::Equal
        } else if left.is_nan() {
            Ordering::Less
        } else {
            Ordering::Greater
        }
    })
}

#[inline]
pub fn lerp(source: f32, target: f32, weight: f32) -> f32 {
    source + weight * (target - source)
}

#[inline]
pub fn decay(source: f32, target: f32, smoothness: f32, delta: f32) -> f32 {
    lerp(
        source,
        target,
        1.0 - libm::powf(f32::clamp(smoothness, 0.0, 1.0), delta),
    )
}

// Port and simplification of https://github.com/gre/bezier-easing
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CubicBezierCurve {
    p1: Vec2,
    p2: Vec2,
}

impl CubicBezierCurve {
    #[inline]
    pub fn new(p1: Vec2, p2: Vec2) -> Self {
        Self { p1, p2 }
    }

    #[inline]
    pub fn evaluate(&self, t: f32) -> f32 {
        let bezier_t = self.compute_t(f32::clamp(t, 0.0, 1.0));
        Self::compute_bezier(bezier_t, self.p1[1], self.p2[1])
    }

    #[inline]
    fn a(a1: f32, a2: f32) -> f32 {
        1.0 - 3.0 * a2 + 3.0 * a1
    }

    #[inline]
    fn b(a1: f32, a2: f32) -> f32 {
        3.0 * a2 - 6.0 * a1
    }

    #[inline]
    fn c(a1: f32) -> f32 {
        a1 * 3.0
    }

    // Return x(t) given t, x1, and x2, or y(t) given t, y1, and y2.
    #[inline]
    fn compute_bezier(t: f32, a1: f32, a2: f32) -> f32 {
        ((Self::a(a1, a2) * t + Self::b(a1, a2)) * t + Self::c(a1)) * t
    }

    // Return dx/dt given t, x1, and x2, or dy/dt given t, y1, and y2.
    #[inline]
    fn compute_slope(t: f32, a1: f32, a2: f32) -> f32 {
        3.0 * Self::a(a1, a2) * t * t + 2.0 * Self::b(a1, a2) * t + Self::c(a1)
    }

    // Iteratively find approximation for parameter t along a cubic
    // bezier curve for x.
    #[inline]
    fn compute_t(&self, x: f32) -> f32 {
        // Newton Raphson iteration
        // https://en.wikipedia.org/wiki/Newton%27s_method

        // The more the prettier, with diminishing returns.
        // 1 iteration already looks very nice
        const N_ITERATIONS: u32 = 3;
        let mut t = x;

        for _ in 0..N_ITERATIONS {
            let slope = Self::compute_slope(t, self.p1[0], self.p2[0]);
            if slope == 0.0 {
                return t;
            }
            let current_x = Self::compute_bezier(t, self.p1[0], self.p2[0]) - x;
            t -= current_x / slope;
        }

        t
    }
}

// These functions below override the originals from glam, so that we don't have
// to f32::from(u16) or i32::from(u16) all the time. They only help sometimes.

pub fn vec2<X, Y>(x: X, y: Y) -> Vec2
where
    X: Into<f32>,
    Y: Into<f32>,
{
    Vec2::new(x.into(), y.into())
}

pub fn vec3<X, Y, Z>(x: X, y: Y, z: Z) -> Vec3
where
    X: Into<f32>,
    Y: Into<f32>,
    Z: Into<f32>,
{
    Vec3::new(x.into(), y.into(), z.into())
}

pub fn vec4<X, Y, Z, W>(x: X, y: Y, z: Z, w: W) -> Vec4
where
    X: Into<f32>,
    Y: Into<f32>,
    Z: Into<f32>,
    W: Into<f32>,
{
    Vec4::new(x.into(), y.into(), z.into(), w.into())
}

pub fn ivec2<X, Y>(x: X, y: Y) -> IVec2
where
    X: Into<i32>,
    Y: Into<i32>,
{
    IVec2::new(x.into(), y.into())
}

pub fn ivec3<X, Y, Z>(x: X, y: Y, z: Z) -> IVec3
where
    X: Into<i32>,
    Y: Into<i32>,
    Z: Into<i32>,
{
    IVec3::new(x.into(), y.into(), z.into())
}

pub fn ivec4<X, Y, Z, W>(x: X, y: Y, z: Z, w: W) -> IVec4
where
    X: Into<i32>,
    Y: Into<i32>,
    Z: Into<i32>,
    W: Into<i32>,
{
    IVec4::new(x.into(), y.into(), z.into(), w.into())
}
