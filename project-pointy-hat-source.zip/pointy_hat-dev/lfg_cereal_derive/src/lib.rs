extern crate proc_macro;

use proc_macro::TokenStream;
use proc_macro2::{Span, TokenStream as TokenStream2};
use quote::quote;

#[proc_macro_derive(Serialize, attributes(cereal))]
pub fn derive_serialize(input: TokenStream) -> TokenStream {
    let parsed_input = syn::parse_macro_input!(input as syn::DeriveInput);
    serialize(parsed_input)
        .unwrap_or_else(|err| err.to_compile_error())
        .into()
}

#[proc_macro_derive(Deserialize, attributes(cereal))]
pub fn derive_deserialize(input: TokenStream) -> TokenStream {
    let parsed_input = syn::parse_macro_input!(input as syn::DeriveInput);
    deserialize(parsed_input)
        .unwrap_or_else(|err| err.to_compile_error())
        .into()
}

fn serialize(input: syn::DeriveInput) -> syn::Result<TokenStream2> {
    match &input.data {
        syn::Data::Struct(data) => serialize_struct(&input, data),
        syn::Data::Enum(data) => serialize_enum(&input, data),
        syn::Data::Union(_) => Err(syn::Error::new(
            Span::call_site(),
            "Unions are not supported, Dave",
        )),
    }
}

fn serialize_struct(input: &syn::DeriveInput, data: &syn::DataStruct) -> syn::Result<TokenStream2> {
    const ALLOWED_ATTRS: &[&str] = &["allocator", "rename"];

    let ident = &input.ident;
    let ns = syn::Ident::new(&format!("__SERIALIZE__{ident}"), Span::call_site());

    let rename_ident = match attr_rename(&input.attrs, ALLOWED_ATTRS)? {
        Some(rename_ident) => rename_ident,
        None => ident.clone(),
    };

    let (impl_generics, ty_generics, where_clause) = input.generics.split_for_impl();

    let mut field_codes: Vec<TokenStream2> = Vec::new();
    match &data.fields {
        syn::Fields::Named(fields) => {
            for field in &fields.named {
                let field_ident = field.ident.as_ref().unwrap();
                let field_code = quote! {
                    f.field(stringify!(#field_ident), |f| self.#field_ident.serialize(f));
                };

                field_codes.push(field_code);
            }
        }
        syn::Fields::Unnamed(fields) => {
            for (i, _) in fields.unnamed.iter().enumerate() {
                let field_index = syn::Index::from(i);
                let field_code = quote! {
                    f.item(|f| self.#field_index.serialize(f));
                };

                field_codes.push(field_code);
            }
        }
        syn::Fields::Unit => (),
    }

    let fields_len = data.fields.len();
    let serialize_code = match data.fields {
        syn::Fields::Named(_) => {
            quote! {
                f.dictionary_struct(
                    stringify!(#rename_ident),
                    #fields_len > lfg_cereal::DICTIONARY_LIKE_MULTILINE_THRESHOLD,
                    |f| {
                        #(#field_codes)*
                    },
                );
            }
        }
        syn::Fields::Unnamed(_) => {
            quote! {
                f.tuple_struct(
                    stringify!(#rename_ident),
                    #fields_len > lfg_cereal::ARRAY_LIKE_MULTILINE_THRESHOLD,
                    |f| {
                        #(#field_codes)*
                    },
                );
            }
        }
        syn::Fields::Unit => {
            quote! {
                f.unit_struct(stringify!(#rename_ident));
            }
        }
    };

    Ok(quote! {
        const #ns: () = {
            #[allow(deprecated)]
            impl #impl_generics lfg_cereal::Serialize for #ident #ty_generics #where_clause {
                fn serialize<A: core::alloc::Allocator>(&self, f: &mut lfg_cereal::Formatter<A>) {
                    #serialize_code
                }
            }
        };
    })
}

fn serialize_enum(input: &syn::DeriveInput, data: &syn::DataEnum) -> syn::Result<TokenStream2> {
    let ident = &input.ident;
    let ns = syn::Ident::new(&format!("__SERIALIZE__{ident}"), Span::call_site());

    // TODO(yan): Rename attribute for enum variants.

    let (impl_generics, ty_generics, where_clause) = input.generics.split_for_impl();

    let mut match_arm_codes: Vec<TokenStream2> = Vec::new();
    for variant in &data.variants {
        let variant_ident = &variant.ident;

        let fields_len = variant.fields.len();
        let match_arm_code = match &variant.fields {
            syn::Fields::Named(fields) => {
                let mut destructuring_codes: Vec<TokenStream2> = Vec::new();
                let mut field_codes: Vec<TokenStream2> = Vec::new();

                for field in &fields.named {
                    let field_ident = field.ident.as_ref().unwrap();

                    let destructuring_code = quote! {
                        #field_ident,
                    };
                    let field_code = quote! {
                        f.field(stringify!(#field_ident), |f| #field_ident.serialize(f));
                    };

                    destructuring_codes.push(destructuring_code);
                    field_codes.push(field_code);
                }

                quote! {
                    #ident::#variant_ident { #(#destructuring_codes)* } => {
                        f.dictionary_struct(
                            stringify!(#variant_ident),
                            #fields_len > lfg_cereal::DICTIONARY_LIKE_MULTILINE_THRESHOLD,
                            |f| {
                                #(#field_codes)*
                            },
                        );
                    }
                }
            }
            syn::Fields::Unnamed(fields) => {
                let mut destructuring_codes: Vec<TokenStream2> = Vec::new();
                let mut field_codes: Vec<TokenStream2> = Vec::new();

                for (i, _) in fields.unnamed.iter().enumerate() {
                    let field_ident = syn::Ident::new(&format!("__CEREAL__{i}"), Span::call_site());

                    let destructuring_code = quote! {
                        #field_ident,
                    };
                    let field_code = quote! {
                        f.item(|f| #field_ident.serialize(f));
                    };

                    destructuring_codes.push(destructuring_code);
                    field_codes.push(field_code);
                }

                quote! {
                    #ident::#variant_ident( #(#destructuring_codes)* ) => {
                        f.tuple_struct(
                            stringify!(#variant_ident),
                            #fields_len > lfg_cereal::ARRAY_LIKE_MULTILINE_THRESHOLD,
                            |f| {
                                #(#field_codes)*
                            },
                        );
                    }
                }
            }
            syn::Fields::Unit => {
                quote! {
                    #ident::#variant_ident => {
                        f.unit_struct(stringify!(#variant_ident))
                    }
                }
            }
        };

        match_arm_codes.push(match_arm_code);
    }

    Ok(quote! {
        const #ns: () = {
            #[allow(deprecated)]
            impl #impl_generics lfg_cereal::Serialize for #ident #ty_generics #where_clause {
                fn serialize<A: core::alloc::Allocator>(&self, f: &mut lfg_cereal::Formatter<A>) {
                    match self {
                        #(#match_arm_codes)*
                    }
                }
            }
        };
    })
}

fn deserialize(input: syn::DeriveInput) -> syn::Result<TokenStream2> {
    match &input.data {
        syn::Data::Struct(data) => deserialize_struct(&input, data),
        syn::Data::Enum(data) => deserialize_enum(&input, data),
        syn::Data::Union(_) => Err(syn::Error::new(
            Span::call_site(),
            "Unions are not supported, Dave",
        )),
    }
}

fn deserialize_struct(
    input: &syn::DeriveInput,
    data: &syn::DataStruct,
) -> syn::Result<TokenStream2> {
    const ALLOWED_ATTRS: &[&str] = &["allocator", "rename"];

    let ident = &input.ident;
    let ns = syn::Ident::new(&format!("__DESERIALIZE__{ident}"), Span::call_site());

    // TODO(yan): Add allocator_is_generic to know whether we should emit the
    // spliced impl_generics for it. Also for enums.
    let (allocator_ty, generic) = match attr_allocator(&input.attrs, ALLOWED_ATTRS)? {
        Some(allocator_ty) => (allocator_ty, false),
        None => {
            let allocator_ty = syn::Type::Path(syn::TypePath {
                qself: None,
                path: syn::Path {
                    leading_colon: None,
                    segments: {
                        let mut segments_punct = syn::punctuated::Punctuated::new();
                        segments_punct.push(syn::PathSegment {
                            ident: syn::Ident::new("__CEREAL_A__", Span::call_site()),
                            arguments: syn::PathArguments::None,
                        });

                        segments_punct
                    },
                },
            });

            (allocator_ty, true)
        }
    };

    let rename_ident = match attr_rename(&input.attrs, ALLOWED_ATTRS)? {
        Some(rename_ident) => rename_ident,
        None => ident.clone(),
    };

    // NB: Unlike Serialize, the Deserialize trait has a generic parameter
    // itself, meaning we can't just cut-n-paste generics from the original
    // type, but instead we need to splice the generic parameter of the trait to
    // the impl_generics from the original type, but NOT the ty_generics or the
    // where_clause. We only need to do this, if the provided allocator
    // attribute is a generic type parameter and not a concrete type, and thus
    // needs to be present in the impl_generics.
    let mut impl_augmented_generics = input.generics.clone();

    // TODO(yan): Implement cereal(allocator_generic) for when the user provides
    // no concrete allocator, but wants to tie the allocator type parameter to
    // the allocator generic type defined on the struct.
    if generic {
        impl_augmented_generics
            .params
            .push(syn::GenericParam::Type(syn::TypeParam {
                attrs: Vec::new(),
                ident: syn::Ident::new("__CEREAL_A__", Span::call_site()),
                colon_token: Some(syn::token::Colon {
                    spans: [Span::call_site()],
                }),
                bounds: {
                    let mut bounds_punct = syn::punctuated::Punctuated::new();

                    bounds_punct.push(syn::TypeParamBound::Trait(syn::TraitBound {
                        paren_token: None,
                        modifier: syn::TraitBoundModifier::None,
                        lifetimes: None,
                        path: syn::Path {
                            leading_colon: None,
                            segments: {
                                let mut segments_punct = syn::punctuated::Punctuated::new();
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("core", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("alloc", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("Allocator", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });

                                segments_punct
                            },
                        },
                    }));

                    bounds_punct.push(syn::TypeParamBound::Trait(syn::TraitBound {
                        paren_token: None,
                        modifier: syn::TraitBoundModifier::None,
                        lifetimes: None,
                        path: syn::Path {
                            leading_colon: None,
                            segments: {
                                let mut segments_punct = syn::punctuated::Punctuated::new();
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("core", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("clone", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("Clone", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });

                                segments_punct
                            },
                        },
                    }));

                    bounds_punct
                },
                eq_token: None,
                default: None,
            }));
    }

    let (_, ty_generics, where_clause) = input.generics.split_for_impl();
    let (impl_generics, _, _) = impl_augmented_generics.split_for_impl();

    let deserialize_code = match &data.fields {
        syn::Fields::Named(fields) => {
            let mut field_decl_codes: Vec<TokenStream2> = Vec::new();
            let mut field_init_codes: Vec<TokenStream2> = Vec::new();
            for field in &fields.named {
                let field_ident = field.ident.as_ref().unwrap();
                let field_ty = &field.ty;

                // NB: <#field_ty> is wrapped in angle brackets because the
                // following generic code would not be valid Rust:
                //
                // Vec<T>::deserialize
                let field_decl_code = quote! {
                    let #field_ident = {
                        let field_node = node_fields
                            .get(stringify!(#field_ident).as_bytes())
                            .ok_or(lfg_cereal::DeserializeError)?;

                        <#field_ty>::deserialize(field_node, allocator.clone())?
                    };
                };
                let field_init_code = quote! {
                    #field_ident,
                };

                field_decl_codes.push(field_decl_code);
                field_init_codes.push(field_init_code);
            }

            quote! {
                match node {
                    lfg_cereal::Node::DictionaryStruct(node_ident_bytes, node_fields) => {
                        let node_ident = lfg_cereal::cast_ident(&node_ident_bytes);
                        if stringify!(#rename_ident) == node_ident {
                            #(#field_decl_codes)*
                            Ok(#ident { #(#field_init_codes)* })
                        } else {
                            Err(lfg_cereal::DeserializeError)
                        }
                    }
                    _ => Err(lfg_cereal::DeserializeError),
                }
            }
        }
        syn::Fields::Unnamed(fields) => {
            let mut field_decl_codes: Vec<TokenStream2> = Vec::new();
            let mut field_init_codes: Vec<TokenStream2> = Vec::new();
            for (i, field) in fields.unnamed.iter().enumerate() {
                let field_ident = syn::Ident::new(&format!("__CEREAL__{i}"), Span::call_site());
                let field_ty = &field.ty;

                // NB: <#field_ty> is wrapped in angle brackets because the
                // following generic code would not be valid Rust:
                //
                // Vec<T>::deserialize
                let field_decl_code = quote! {
                    let #field_ident = {
                        let field_node = node_fields.get(#i).ok_or(lfg_cereal::DeserializeError)?;
                        <#field_ty>::deserialize(field_node, allocator.clone())?
                    };
                };
                let field_init_code = quote! {
                    #field_ident,
                };

                field_decl_codes.push(field_decl_code);
                field_init_codes.push(field_init_code);
            }

            quote! {
                match node {
                    lfg_cereal::Node::TupleStruct(node_ident_bytes, node_fields) => {
                        let node_ident = lfg_cereal::cast_ident(&node_ident_bytes);
                        if stringify!(#rename_ident) == node_ident {
                            #(#field_decl_codes)*
                            Ok(#ident(#(#field_init_codes)*))
                        } else {
                            Err(lfg_cereal::DeserializeError)
                        }
                    }
                    _ => Err(lfg_cereal::DeserializeError),
                }
            }
        }
        syn::Fields::Unit => {
            quote! {
                match node {
                    lfg_cereal::Node::UnitStruct(node_ident_bytes) => {
                        let node_ident = lfg_cereal::cast_ident(&node_ident_bytes);
                        if stringify!(#rename_ident) == node_ident {
                            Ok(#ident)
                        } else {
                            Err(lfg_cereal::DeserializeError)
                        }
                    }
                    _ => Err(lfg_cereal::DeserializeError),
                }
            }
        }
    };

    Ok(quote! {
        const #ns: () = {
            #[allow(deprecated)]
            impl #impl_generics lfg_cereal::Deserialize<#allocator_ty> for #ident #ty_generics #where_clause {
                fn deserialize<__CEREAL_NA__>(
                    node: &lfg_cereal::Node<__CEREAL_NA__>,
                    allocator: #allocator_ty,
                ) -> Result<Self, lfg_cereal::DeserializeError>
                where
                    __CEREAL_NA__: core::alloc::Allocator + core::clone::Clone,
                {
                    #deserialize_code
                }
            }
        };
    })
}

fn deserialize_enum(input: &syn::DeriveInput, data: &syn::DataEnum) -> syn::Result<TokenStream2> {
    const ALLOWED_ATTRS: &[&str] = &["allocator"];

    let ident = &input.ident;
    let ns = syn::Ident::new(&format!("__DESERIALIZE__{ident}"), Span::call_site());

    // TODO(yan): @Cleanup Attribute parsing and type parameter generation could
    // be reused between structs and enums.

    // TODO(yan): Add allocator_is_generic to know whether we should emit the
    // spliced impl_generics for it. Also for enums.
    let (allocator_ty, generic) = match attr_allocator(&input.attrs, ALLOWED_ATTRS)? {
        Some(allocator_ty) => (allocator_ty, false),
        None => {
            let allocator_ty = syn::Type::Path(syn::TypePath {
                qself: None,
                path: syn::Path {
                    leading_colon: None,
                    segments: {
                        let mut segments_punct = syn::punctuated::Punctuated::new();
                        segments_punct.push(syn::PathSegment {
                            ident: syn::Ident::new("__CEREAL_A__", Span::call_site()),
                            arguments: syn::PathArguments::None,
                        });

                        segments_punct
                    },
                },
            });

            (allocator_ty, true)
        }
    };

    // NB: Unlike Serialize, the Deserialize trait has a generic parameter
    // itself, meaning we can't just cut-n-paste generics from the original
    // type, but instead we need to splice the generic parameter of the trait to
    // the impl_generics from the original type, but NOT the ty_generics or the
    // where_clause. We only need to do this, if the provided allocator
    // attribute is a generic type parameter and not a concrete type, and thus
    // needs to be present in the impl_generics.
    let mut impl_augmented_generics = input.generics.clone();

    // TODO(yan): Implement cereal(allocator_generic) for when the user provides
    // no concrete allocator, but wants to tie the allocator type parameter to
    // the allocator generic type defined on the struct.
    if generic {
        impl_augmented_generics
            .params
            .push(syn::GenericParam::Type(syn::TypeParam {
                attrs: Vec::new(),
                ident: syn::Ident::new("__CEREAL_A__", Span::call_site()),
                colon_token: Some(syn::token::Colon {
                    spans: [Span::call_site()],
                }),
                bounds: {
                    let mut bounds_punct = syn::punctuated::Punctuated::new();

                    bounds_punct.push(syn::TypeParamBound::Trait(syn::TraitBound {
                        paren_token: None,
                        modifier: syn::TraitBoundModifier::None,
                        lifetimes: None,
                        path: syn::Path {
                            leading_colon: None,
                            segments: {
                                let mut segments_punct = syn::punctuated::Punctuated::new();
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("core", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("alloc", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("Allocator", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });

                                segments_punct
                            },
                        },
                    }));

                    bounds_punct.push(syn::TypeParamBound::Trait(syn::TraitBound {
                        paren_token: None,
                        modifier: syn::TraitBoundModifier::None,
                        lifetimes: None,
                        path: syn::Path {
                            leading_colon: None,
                            segments: {
                                let mut segments_punct = syn::punctuated::Punctuated::new();
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("core", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("clone", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });
                                segments_punct.push(syn::PathSegment {
                                    ident: syn::Ident::new("Clone", Span::call_site()),
                                    arguments: syn::PathArguments::None,
                                });

                                segments_punct
                            },
                        },
                    }));

                    bounds_punct
                },
                eq_token: None,
                default: None,
            }));
    }

    let (_, ty_generics, where_clause) = input.generics.split_for_impl();
    let (impl_generics, _, _) = impl_augmented_generics.split_for_impl();

    let mut match_arm_codes: Vec<TokenStream2> = Vec::new();
    for variant in &data.variants {
        let variant_ident = &variant.ident;

        let match_arm_code = match &variant.fields {
            syn::Fields::Named(fields) => {
                let mut field_decl_codes: Vec<TokenStream2> = Vec::new();
                let mut field_init_codes: Vec<TokenStream2> = Vec::new();
                for field in &fields.named {
                    let field_ident = field.ident.as_ref().unwrap();
                    let field_ty = &field.ty;

                    // NB: <#field_ty> is wrapped in angle brackets because the
                    // following generic code would not be valid Rust:
                    //
                    // Vec<T>::deserialize
                    let field_decl_code = quote! {
                        let #field_ident = {
                            let field_node = node_fields
                                .get(stringify!(#field_ident).as_bytes())
                                .ok_or(lfg_cereal::DeserializeError)?;

                            <#field_ty>::deserialize(field_node, allocator.clone())?
                        };
                    };
                    let field_init_code = quote! {
                        #field_ident,
                    };

                    field_decl_codes.push(field_decl_code);
                    field_init_codes.push(field_init_code);
                }

                quote! {
                    lfg_cereal::Node::DictionaryStruct(node_ident_bytes, node_fields)
                        if lfg_cereal::cast_ident(&node_ident_bytes) == stringify!(#variant_ident) =>
                    {
                        #(#field_decl_codes)*
                        Ok(#ident::#variant_ident { #(#field_init_codes)* })
                    }
                }
            }
            syn::Fields::Unnamed(fields) => {
                let mut field_decl_codes: Vec<TokenStream2> = Vec::new();
                let mut field_init_codes: Vec<TokenStream2> = Vec::new();
                for (i, field) in fields.unnamed.iter().enumerate() {
                    let field_ident = syn::Ident::new(&format!("__CEREAL__{i}"), Span::call_site());
                    let field_ty = &field.ty;

                    // NB: <#field_ty> is wrapped in angle brackets because the
                    // following generic code would not be valid Rust:
                    //
                    // Vec<T>::deserialize
                    let field_decl_code = quote! {
                        let #field_ident = {
                            let field_node = node_fields.get(#i).ok_or(lfg_cereal::DeserializeError)?;
                            <#field_ty>::deserialize(field_node, allocator.clone())?
                        };
                    };
                    let field_init_code = quote! {
                        #field_ident,
                    };

                    field_decl_codes.push(field_decl_code);
                    field_init_codes.push(field_init_code);
                }

                quote! {
                    lfg_cereal::Node::TupleStruct(node_ident_bytes, node_fields)
                        if lfg_cereal::cast_ident(&node_ident_bytes) == stringify!(#variant_ident) =>
                    {
                        #(#field_decl_codes)*
                        Ok(#ident::#variant_ident(#(#field_init_codes)*))
                    }
                }
            }
            syn::Fields::Unit => {
                quote! {
                    lfg_cereal::Node::UnitStruct(node_ident_bytes)
                        if lfg_cereal::cast_ident(&node_ident_bytes) == stringify!(#variant_ident) =>
                    {
                        Ok(#ident::#variant_ident)
                    }
                }
            }
        };

        match_arm_codes.push(match_arm_code);
    }

    Ok(quote! {
        const #ns: () = {
            impl #impl_generics lfg_cereal::Deserialize<#allocator_ty> for #ident #ty_generics #where_clause {
                fn deserialize<__CEREAL_NA__>(
                    node: &lfg_cereal::Node<__CEREAL_NA__>,
                    allocator: #allocator_ty,
                ) -> Result<Self, lfg_cereal::DeserializeError>
                where
                    __CEREAL_NA__: core::alloc::Allocator + core::clone::Clone,
                {
                    match node {
                        #(#match_arm_codes)*
                        _ => Err(lfg_cereal::DeserializeError),
                    }
                }
            }
        };
    })
}

fn attr_allocator(
    attrs: &[syn::Attribute],
    allowed_attrs: &[&str],
) -> syn::Result<Option<syn::Type>> {
    let mut allocator: Option<syn::Type> = None;

    for attr in attrs {
        if !attr.path.is_ident("cereal") {
            continue;
        }

        let list = match attr.parse_meta()? {
            syn::Meta::List(list) => list,
            other => return Err(syn::Error::new_spanned(other, "unsupported attribute")),
        };

        for meta in &list.nested {
            if let syn::NestedMeta::Meta(syn::Meta::List(allocator_list)) = meta {
                if allocator_list.path.is_ident("allocator") {
                    if allocator_list.nested.len() != 1 {
                        return Err(syn::Error::new_spanned(
                            meta,
                            "allocator attribute requires exactly one value",
                        ));
                    }

                    if allocator.is_some() {
                        return Err(syn::Error::new_spanned(
                            meta,
                            "duplicate allocator attribute",
                        ));
                    }

                    let allocator_ty = match allocator_list.nested.first().unwrap() {
                        syn::NestedMeta::Meta(syn::Meta::Path(p)) => {
                            syn::Type::Path(syn::TypePath {
                                qself: None,
                                path: p.clone(),
                            })
                        }
                        syn::NestedMeta::Lit(syn::Lit::Str(lit)) => {
                            syn::parse_str::<syn::Type>(&lit.value())?
                        }
                        _ => {
                            return Err(syn::Error::new_spanned(
                                meta,
                                "allocator attributes requires a path or string literal value",
                            ))
                        }
                    };

                    allocator = Some(allocator_ty);
                    continue;
                }

                let mut allowed = false;
                for allowed_attr in allowed_attrs {
                    if allocator_list.path.is_ident(allowed_attr) {
                        allowed = true;
                    }
                }

                if allowed {
                    continue;
                }
            }

            return Err(syn::Error::new_spanned(meta, "unsupported attribute"));
        }
    }

    Ok(allocator)
}

fn attr_rename(
    attrs: &[syn::Attribute],
    allowed_attrs: &[&str],
) -> syn::Result<Option<syn::Ident>> {
    let mut rename: Option<syn::Ident> = None;

    for attr in attrs {
        if !attr.path.is_ident("cereal") {
            continue;
        }

        let list = match attr.parse_meta()? {
            syn::Meta::List(list) => list,
            other => return Err(syn::Error::new_spanned(other, "unsupported attribute")),
        };

        for meta in &list.nested {
            if let syn::NestedMeta::Meta(syn::Meta::List(rename_list)) = meta {
                if rename_list.path.is_ident("rename") {
                    if rename_list.nested.len() != 1 {
                        return Err(syn::Error::new_spanned(
                            meta,
                            "rename attribute requires exactly one value",
                        ));
                    }

                    if rename.is_some() {
                        return Err(syn::Error::new_spanned(meta, "duplicate rename attribute"));
                    }

                    let rename_ident = match rename_list.nested.first().unwrap() {
                        syn::NestedMeta::Lit(syn::Lit::Str(lit)) => {
                            syn::Ident::new(&lit.value(), lit.span())
                        }
                        _ => {
                            return Err(syn::Error::new_spanned(
                                meta,
                                "rename attributes requires a string literal value",
                            ))
                        }
                    };

                    rename = Some(rename_ident);
                    continue;
                }

                let mut allowed = false;
                for allowed_attr in allowed_attrs {
                    if rename_list.path.is_ident(allowed_attr) {
                        allowed = true;
                    }
                }

                if allowed {
                    continue;
                }
            }

            return Err(syn::Error::new_spanned(meta, "unsupported attribute"));
        }
    }

    Ok(rename)
}
