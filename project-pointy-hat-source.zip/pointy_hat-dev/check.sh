#!/bin/sh

# For the poor souls using WSL
if ! command -v cargo &> /dev/null
then
    echo "cargo not found, attempting to alias to cargo.exe"
    alias cargo="cargo.exe"
fi

# Check individual crates isolated from the workspace to prevent accidental
# ignore of #![no_std].

echo "[check ph]"
cargo check -p ph

echo "[check lfg_common]"
cargo check -p lfg_common

echo "[check lfg_alloc]"
cargo check -p lfg_alloc

echo "[check lfg_math]"
cargo check -p lfg_math

echo "[check ph_platform]"
cargo check -p ph_platform

echo "[check ph_platform_winit]"
cargo check -p ph_platform_winit

echo "[check ph_renderer]"
cargo check -p ph_renderer

echo "[check ph_renderer_wgpu]"
cargo check -p ph_renderer_wgpu

echo "[check workspace]"
cargo check
