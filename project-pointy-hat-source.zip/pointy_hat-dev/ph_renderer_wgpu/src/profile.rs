macro_rules! profile_scope {
    ($name:expr) => {
        #[cfg(feature = "ph_profile")]
        let _span = tracy_client::span!($name);
    };
}
