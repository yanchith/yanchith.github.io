#![feature(const_num_from_num)]
#![feature(const_trait_impl)]
#![feature(generic_associated_types)]

#[macro_use]
mod profile;

use std::borrow::Cow;
use std::collections::HashMap;
use std::fmt;
use std::iter;
use std::num::NonZeroU64;

use arrayvec::ArrayVec;
use lfg_common::{cast_u32, cast_usize};
use lfg_math::{cmp_f32, Mat4, UVec2, Vec3};
use ph_renderer::{
    ColorSpace,
    Draw2DRectCommand,
    Draw2DRectPrimitive,
    Draw3DDebugOutlinePrimitive,
    Draw3DRectPrimitive,
    Draw3DVoxelPrimitive,
    DrawUiCommand,
    DrawUiVertex,
    Frame,
    RenderMode,
    Renderer,
    Sampler,
};
use wgpu::util::DeviceExt as _;

// TODO(yan): Subpixel alpha: https://guide.handmadehero.org/chat/chat018/

// TODO(yan): Do pre-multiplied alpha.
//
// 1) It gives us correct associative blends and prevents color bleeds. Not sure
//    this will affect pixel art that much, although it may if we decide to make
//    the intermediate framebuffer the size of the backbuffer (to do
//    rotation/scaling on pixel art) instead of a pixel-art-friendly size,
//    because this would require subpixel blending instead of the nearest
//    filtering we do now (Casey's Handmade Chat on Children of Morta).
//
// 2) It is also usefult for additive blending, which can in turn be useful for
//    particles. Pre-multiplied alpha should allow us to just have one render
//    pipeline for both alpha blending and additive blending - if alpha is zero,
//    the alpha blending equation should simplify out to the additive blending
//    equation.
//
//      C = SRC_Color * 1 + DST_Color * (1 - SRC_Alpha)
//
// The question is, when do we pre-multiply? We need to do this in linear space,
// so whenever we do this, we must sRGB decode, pre-multiply, and sRGB encode
// again. This could be done in data-compile, or during load-time.
//
// Sources:
//
// - https://youtu.be/rVp5--Gx6Ks
// - https://guide.handmadehero.org/code/day094
// - STB says non-pre-multiplied alpha doesn't distribute across linear blends
// - Tom Forsyth's blog (links are broken, just search for it)

const DRAW_2D_RECT_MAX_PRIMITIVE_COUNT: u32 = 1 << 14;
const DRAW_3D_RECT_MAX_PRIMITIVE_COUNT: u32 = 1 << 14;
const DRAW_3D_VOXEL_MAX_PRIMITIVE_COUNT: u32 = 1 << 18;
const DRAW_3D_DEBUG_OUTLINE_MAX_PRIMITIVE_COUNT: u32 = 1 << 14;

struct TextureResource {
    texture_bind_group: wgpu::BindGroup,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
struct Draw2DRectUniforms {
    screen_width: u32,
    screen_height: u32,
    // Uniform buffer structs are padded to a multiple of the size of a vec4.
    _pad1: u32,
    _pad2: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
struct Draw3DRectUniforms {
    view_projection_matrix: [f32; 16],
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
struct Draw3DVoxelUniforms {
    view_projection_matrix: [f32; 16],
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
struct Draw3DDebugOutlineUniforms {
    view_projection_matrix: [f32; 16],
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
struct DrawUiUniforms {
    transform_matrix: [f32; 16],
    color_mul: u32,
    // Uniform buffer structs are padded to a multiple of the size of a vec4.
    _pad1: u32,
    _pad2: u32,
    _pad3: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
struct BlitUniforms {
    projection_matrix_inverse: [f32; 16],
    render_mode: u32,
    // Uniform buffer structs are padded to a multiple of the size of a vec4.
    _pad1: u32,
    _pad2: u32,
    _pad3: u32,
}

pub struct WgpuRenderer {
    surface: wgpu::Surface,
    surface_format: wgpu::TextureFormat,
    surface_present_mode: wgpu::PresentMode,
    device: wgpu::Device,
    queue: wgpu::Queue,

    // Window dimensions are always in physical pixels here.
    window_size: UVec2,
    window_size_stale: bool,
    window_scale_factor: f32,

    nearest_sampler: wgpu::Sampler,
    bilinear_sampler: wgpu::Sampler,
    sampled_texture_bind_group_layout: wgpu::BindGroupLayout,

    intermediate_color_texture_view: wgpu::TextureView,
    intermediate_color_texture_bind_group: wgpu::BindGroup,
    intermediate_depth_texture_view: wgpu::TextureView,
    intermediate_depth_texture_bind_group: wgpu::BindGroup,

    draw_2d_rect_uniform_buffer: wgpu::Buffer,
    draw_2d_rect_instance_buffer: wgpu::Buffer,
    draw_2d_rect_uniform_bind_group: wgpu::BindGroup,
    draw_2d_rect_render_pipeline: wgpu::RenderPipeline,

    draw_3d_rect_uniform_buffer: wgpu::Buffer,
    draw_3d_rect_instance_buffer: wgpu::Buffer,
    draw_3d_rect_instance_buffer_mem: Vec<Draw3DRectPrimitive>,
    draw_3d_rect_uniform_bind_group: wgpu::BindGroup,
    draw_3d_rect_render_pipeline: wgpu::RenderPipeline,

    draw_3d_voxel_uniform_buffer: wgpu::Buffer,
    draw_3d_voxel_instance_buffer: wgpu::Buffer,
    draw_3d_voxel_uniform_bind_group: wgpu::BindGroup,
    draw_3d_voxel_render_pipeline: wgpu::RenderPipeline,

    draw_3d_debug_outline_uniform_buffer: wgpu::Buffer,
    draw_3d_debug_outline_instance_buffer: wgpu::Buffer,
    draw_3d_debug_outline_uniform_bind_group: wgpu::BindGroup,
    draw_3d_debug_outline_render_pipeline: wgpu::RenderPipeline,

    draw_ui_uniform_buffer: wgpu::Buffer,
    draw_ui_uniform_bind_group: wgpu::BindGroup,
    draw_ui_render_pipeline: wgpu::RenderPipeline,

    blit_uniform_buffer: wgpu::Buffer,
    blit_uniform_bind_group: wgpu::BindGroup,
    blit_render_pipeline: wgpu::RenderPipeline,

    texture_resources: HashMap<u64, TextureResource>,
}

impl WgpuRenderer {
    pub fn new<H>(window_handle: &H, window_size: UVec2, window_scale_factor: f32) -> Self
    where
        H: raw_window_handle::HasRawWindowHandle,
    {
        // TODO(yan): Determine backend/platform combos. Do we want to support
        // all of Vulkan/Windows, D3D12/Windows, Vulkan/Linux, Metal/macOS,
        // Vulkan/macOS (through Vulkan portability) or just a subset? Do we let
        // the player choose? Also, quite likely - neither of the above will be
        // running wgpu, unless it becomes very reliable.
        let backends = wgpu::Backends::PRIMARY;
        let instance = wgpu::Instance::new(backends);
        let surface = unsafe { instance.create_surface(window_handle) };

        struct AdapterInfo {
            backend: wgpu::Backend,
            name: String,
        }

        impl fmt::Debug for AdapterInfo {
            fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
                write!(f, "{} ({:?})", self.name, self.backend)
            }
        }

        let mut adapter_infos: ArrayVec<AdapterInfo, 64> = ArrayVec::new();
        for adapter in instance.enumerate_adapters(backends) {
            let adapter_info = adapter.get_info();
            adapter_infos.push(AdapterInfo {
                backend: adapter_info.backend,
                name: adapter_info.name,
            });
        }

        log::debug!("Available GPU adapters: {adapter_infos:?}");

        let adapter = {
            let future = instance.request_adapter(&wgpu::RequestAdapterOptions {
                power_preference: wgpu::PowerPreference::HighPerformance,
                force_fallback_adapter: false,
                compatible_surface: Some(&surface),
            });

            pollster::block_on(future).unwrap()
        };

        let adapter_info = adapter.get_info();
        log::info!(
            "Selected GPU adapter: {} ({:?})",
            adapter_info.name,
            adapter_info.backend,
        );

        let (device, queue) = {
            let future = adapter.request_device(
                &wgpu::DeviceDescriptor {
                    label: None,
                    features: wgpu::Features::empty(),
                    limits: wgpu::Limits::default(),
                },
                None,
            );

            pollster::block_on(future).unwrap()
        };

        // We attempt fallback to anotther surface format, if Bgra8UnormSrgb is
        // not available. Fifo present mode should be supported everywhere, so
        // we do not fallback.
        let mut surface_format = wgpu::TextureFormat::Bgra8UnormSrgb;
        let surface_present_mode = wgpu::PresentMode::Fifo;

        let supported_formats = surface.get_supported_formats(&adapter);
        let supported_present_modes = surface.get_supported_modes(&adapter);

        log::debug!("Surface supports formats: {supported_formats:?}");
        log::debug!("Surface supports present modes: {supported_present_modes:?}");

        // TODO(yan): @Correctness Bgra8UnormSrgb surface format handles
        // linear-to-srgb for us. If it is not supported, we fall back to
        // Bgra8Unorm, but that is not gamma-correct!

        if !supported_formats.contains(&surface_format) {
            log::warn!("Surface doesn't support Bgra8UnormSrgb, falling back to Bgra8Unorm");
            if supported_formats.contains(&wgpu::TextureFormat::Bgra8Unorm) {
                surface_format = wgpu::TextureFormat::Bgra8Unorm;
            } else {
                log::error!("Surface doesn't support Bgra8Unorm");
            }
        }

        surface.configure(
            &device,
            &wgpu::SurfaceConfiguration {
                usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
                format: surface_format,
                width: window_size.x,
                height: window_size.y,
                present_mode: surface_present_mode,
            },
        );

        let nearest_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: None,
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Nearest,
            min_filter: wgpu::FilterMode::Nearest,
            mipmap_filter: wgpu::FilterMode::Nearest,
            lod_min_clamp: -100.0,
            lod_max_clamp: 100.0,
            compare: None,
            anisotropy_clamp: None,
            border_color: None,
        });

        let bilinear_sampler = device.create_sampler(&wgpu::SamplerDescriptor {
            label: None,
            address_mode_u: wgpu::AddressMode::ClampToEdge,
            address_mode_v: wgpu::AddressMode::ClampToEdge,
            address_mode_w: wgpu::AddressMode::ClampToEdge,
            mag_filter: wgpu::FilterMode::Linear,
            min_filter: wgpu::FilterMode::Linear,
            mipmap_filter: wgpu::FilterMode::Nearest,
            lod_min_clamp: -100.0,
            lod_max_clamp: 100.0,
            compare: None,
            anisotropy_clamp: None,
            border_color: None,
        });

        let sampled_texture_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[
                    wgpu::BindGroupLayoutEntry {
                        binding: 0,
                        // Also visible for vertex shaders, so that we can query
                        // the size. This is used for draw_2d_rect pipeline, and
                        // maybe even more.
                        visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Sampler(wgpu::SamplerBindingType::Filtering),
                        count: None,
                    },
                    wgpu::BindGroupLayoutEntry {
                        binding: 1,
                        // Also visible for vertex shaders, so that we can query
                        // the size. This is used for draw_2d_rect pipeline, and
                        // maybe even more.
                        visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                        ty: wgpu::BindingType::Texture {
                            sample_type: wgpu::TextureSampleType::Float { filterable: true },
                            view_dimension: wgpu::TextureViewDimension::D2,
                            multisampled: false,
                        },
                        count: None,
                    },
                ],
            });

        let (intermediate_color_texture_view, intermediate_depth_texture_view) =
            create_intermediate_textures(&device, window_size);

        let intermediate_color_texture_bind_group =
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &sampled_texture_bind_group_layout,
                entries: &[
                    wgpu::BindGroupEntry {
                        binding: 0,
                        // Nearest sampling should be ok here, because
                        // dimensions match.
                        resource: wgpu::BindingResource::Sampler(&nearest_sampler),
                    },
                    wgpu::BindGroupEntry {
                        binding: 1,
                        resource: wgpu::BindingResource::TextureView(
                            &intermediate_color_texture_view,
                        ),
                    },
                ],
            });

        let intermediate_depth_texture_bind_group =
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &sampled_texture_bind_group_layout,
                entries: &[
                    wgpu::BindGroupEntry {
                        binding: 0,
                        // Nearest sampling should be ok here, because dimensions
                        // match.
                        resource: wgpu::BindingResource::Sampler(&nearest_sampler),
                    },
                    wgpu::BindGroupEntry {
                        binding: 1,
                        resource: wgpu::BindingResource::TextureView(
                            &intermediate_depth_texture_view,
                        ),
                    },
                ],
            });

        let draw_2d_rect_uniform_buffer_size =
            NonZeroU64::new(size_of_u64::<Draw2DRectUniforms>()).unwrap();
        log::debug!(
            "Uniform buffer size for render pipeline draw_2d_rect: {}",
            draw_2d_rect_uniform_buffer_size,
        );

        let draw_2d_rect_uniform_buffer =
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::bytes_of(&Draw2DRectUniforms {
                    screen_width: window_size.x,
                    screen_height: window_size.y,
                    _pad1: 0,
                    _pad2: 0,
                }),
                usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::UNIFORM,
            });

        let draw_2d_rect_instance_buffer_size = NonZeroU64::new(
            u64::from(DRAW_2D_RECT_MAX_PRIMITIVE_COUNT) * size_of_u64::<Draw2DRectPrimitive>(),
        )
        .unwrap();

        let draw_2d_rect_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size: draw_2d_rect_instance_buffer_size.get(),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::VERTEX,
            mapped_at_creation: false,
        });

        log::debug!(
            "Instance buffer size for render pipeline draw_2d_rect: {}",
            draw_2d_rect_instance_buffer_size,
        );

        let draw_2d_rect_uniform_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    // TODO(yan): @Speed Cut down visibility to only required stages.
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: Some(draw_2d_rect_uniform_buffer_size),
                    },
                    count: None,
                }],
            });

        let draw_2d_rect_uniform_bind_group =
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &draw_2d_rect_uniform_bind_group_layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                        buffer: &draw_2d_rect_uniform_buffer,
                        offset: 0,
                        size: Some(draw_2d_rect_uniform_buffer_size),
                    }),
                }],
            });

        let draw_2d_rect_pipeline_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[
                    &draw_2d_rect_uniform_bind_group_layout,
                    &sampled_texture_bind_group_layout,
                ],
                push_constant_ranges: &[],
            });

        static DRAW_2D_RECT_VS: &[u32] = vk_shader_macros::include_glsl!("src/draw_2d_rect.vert");
        static DRAW_2D_RECT_FS: &[u32] = vk_shader_macros::include_glsl!("src/draw_2d_rect.frag");
        let draw_2d_rect_vs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_2D_RECT_VS));
        let draw_2d_rect_fs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_2D_RECT_FS));
        let draw_2d_rect_vs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_2d_rect_vs_source,
        });
        let draw_2d_rect_fs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_2d_rect_fs_source,
        });

        let draw_2d_rect_render_pipeline =
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: None,
                layout: Some(&draw_2d_rect_pipeline_layout),
                vertex: wgpu::VertexState {
                    module: &draw_2d_rect_vs_module,
                    entry_point: "main",
                    buffers: &[wgpu::VertexBufferLayout {
                        array_stride: size_of_u64::<Draw2DRectPrimitive>(),
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &[
                            // a_rect
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 0,
                                shader_location: 0,
                            },
                            // a_texture_rect
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 16,
                                shader_location: 1,
                            },
                            // a_color
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Uint32,
                                offset: 32,
                                shader_location: 2,
                            },
                        ],
                    }],
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: Some(wgpu::Face::Back),
                    unclipped_depth: false,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    conservative: false,
                },
                depth_stencil: None,
                multisample: wgpu::MultisampleState {
                    count: 1,
                    mask: !0,
                    alpha_to_coverage_enabled: false,
                },
                fragment: Some(wgpu::FragmentState {
                    module: &draw_2d_rect_fs_module,
                    entry_point: "main",
                    targets: &[Some(wgpu::ColorTargetState {
                        format: wgpu::TextureFormat::Rgba8UnormSrgb,
                        blend: Some(wgpu::BlendState {
                            color: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                            alpha: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                        }),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                }),
                multiview: None,
            });

        let draw_3d_rect_uniform_buffer_size =
            NonZeroU64::new(size_of_u64::<Draw3DRectUniforms>()).unwrap();
        log::debug!(
            "Uniform buffer size for render pipeline draw_3d_rect: {}",
            draw_3d_rect_uniform_buffer_size,
        );

        let draw_3d_rect_uniform_buffer =
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::bytes_of(&Draw3DRectUniforms {
                    view_projection_matrix: Mat4::IDENTITY.to_cols_array(),
                }),
                usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::UNIFORM,
            });

        let draw_3d_rect_instance_buffer_size = NonZeroU64::new(
            u64::from(DRAW_3D_RECT_MAX_PRIMITIVE_COUNT) * size_of_u64::<Draw3DRectPrimitive>(),
        )
        .unwrap();

        let draw_3d_rect_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size: draw_3d_rect_instance_buffer_size.get(),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::VERTEX,
            mapped_at_creation: false,
        });

        log::debug!(
            "Instance buffer size for render pipeline draw_3d_rect: {}",
            draw_3d_rect_instance_buffer_size,
        );

        let draw_3d_rect_instance_buffer_mem =
            Vec::with_capacity(cast_usize!(DRAW_3D_RECT_MAX_PRIMITIVE_COUNT));

        let draw_3d_rect_uniform_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    // TODO(yan): @Speed Cut down visibility to only required stages.
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: Some(draw_3d_rect_uniform_buffer_size),
                    },
                    count: None,
                }],
            });

        let draw_3d_rect_uniform_bind_group =
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &draw_3d_rect_uniform_bind_group_layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                        buffer: &draw_3d_rect_uniform_buffer,
                        offset: 0,
                        size: Some(draw_3d_rect_uniform_buffer_size),
                    }),
                }],
            });

        let draw_3d_rect_pipeline_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[
                    &draw_3d_rect_uniform_bind_group_layout,
                    &sampled_texture_bind_group_layout,
                ],
                push_constant_ranges: &[],
            });

        static DRAW_3D_RECT_VS: &[u32] = vk_shader_macros::include_glsl!("src/draw_3d_rect.vert");
        static DRAW_3D_RECT_FS: &[u32] = vk_shader_macros::include_glsl!("src/draw_3d_rect.frag");
        let draw_3d_rect_vs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_3D_RECT_VS));
        let draw_3d_rect_fs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_3D_RECT_FS));
        let draw_3d_rect_vs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_3d_rect_vs_source,
        });
        let draw_3d_rect_fs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_3d_rect_fs_source,
        });

        let draw_3d_rect_render_pipeline =
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: None,
                layout: Some(&draw_3d_rect_pipeline_layout),
                vertex: wgpu::VertexState {
                    module: &draw_3d_rect_vs_module,
                    entry_point: "main",
                    buffers: &[wgpu::VertexBufferLayout {
                        array_stride: size_of_u64::<Draw3DRectPrimitive>(),
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &[
                            // The primitive stores the matrix in a column major
                            // format. We just decompose it here, into 4 vec4s,
                            // because that's where the vertex attribs' limit is.

                            // a_transform_matrix_x
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 0,
                                shader_location: 0,
                            },
                            // a_transform_matrix_y
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 16,
                                shader_location: 1,
                            },
                            // a_transform_matrix_z
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 32,
                                shader_location: 2,
                            },
                            // a_transform_matrix_w
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 48,
                                shader_location: 3,
                            },
                            // a_texture_rect
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 64,
                                shader_location: 4,
                            },
                            // a_color_mul
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Uint32,
                                offset: 80,
                                shader_location: 5,
                            },
                            // a_color_add
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Uint32,
                                offset: 84,
                                shader_location: 6,
                            },
                            // texture_id is omitted. We really don't need it on
                            // the shader and we account for it in the stride.
                        ],
                    }],
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: Some(wgpu::Face::Back),
                    unclipped_depth: false,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    conservative: false,
                },
                depth_stencil: Some(wgpu::DepthStencilState {
                    format: wgpu::TextureFormat::Depth32Float,
                    depth_write_enabled: true,
                    depth_compare: wgpu::CompareFunction::Less,
                    stencil: wgpu::StencilState::default(),
                    bias: wgpu::DepthBiasState::default(),
                }),
                multisample: wgpu::MultisampleState {
                    count: 1,
                    mask: !0,
                    alpha_to_coverage_enabled: false,
                },
                fragment: Some(wgpu::FragmentState {
                    module: &draw_3d_rect_fs_module,
                    entry_point: "main",
                    targets: &[Some(wgpu::ColorTargetState {
                        format: wgpu::TextureFormat::Rgba8UnormSrgb,
                        blend: Some(wgpu::BlendState {
                            color: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                            alpha: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                        }),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                }),
                multiview: None,
            });

        let draw_3d_voxel_uniform_buffer_size =
            NonZeroU64::new(size_of_u64::<Draw3DVoxelUniforms>()).unwrap();
        log::debug!(
            "Uniform buffer size for render pipeline draw_3d_voxel: {}",
            draw_3d_voxel_uniform_buffer_size,
        );

        let draw_3d_voxel_uniform_buffer =
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::bytes_of(&Draw3DVoxelUniforms {
                    view_projection_matrix: Mat4::IDENTITY.to_cols_array(),
                }),
                usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::UNIFORM,
            });

        let draw_3d_voxel_instance_buffer_size = NonZeroU64::new(
            u64::from(DRAW_3D_VOXEL_MAX_PRIMITIVE_COUNT) * size_of_u64::<Draw3DVoxelPrimitive>(),
        )
        .unwrap();

        let draw_3d_voxel_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size: draw_3d_voxel_instance_buffer_size.get(),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::VERTEX,
            mapped_at_creation: false,
        });

        log::debug!(
            "Instance buffer size for render pipeline draw_3d_voxel: {}",
            draw_3d_voxel_instance_buffer_size,
        );

        let draw_3d_voxel_uniform_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    // TODO(yan): @Speed Cut down visibility to only required stages.
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: Some(draw_3d_voxel_uniform_buffer_size),
                    },
                    count: None,
                }],
            });

        let draw_3d_voxel_uniform_bind_group =
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &draw_3d_voxel_uniform_bind_group_layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                        buffer: &draw_3d_voxel_uniform_buffer,
                        offset: 0,
                        size: Some(draw_3d_voxel_uniform_buffer_size),
                    }),
                }],
            });

        let draw_3d_voxel_pipeline_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[&draw_3d_voxel_uniform_bind_group_layout],
                push_constant_ranges: &[],
            });

        static DRAW_3D_VOXEL_VS: &[u32] = vk_shader_macros::include_glsl!("src/draw_3d_voxel.vert");
        static DRAW_3D_VOXEL_FS: &[u32] = vk_shader_macros::include_glsl!("src/draw_3d_voxel.frag");
        let draw_3d_voxel_vs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_3D_VOXEL_VS));
        let draw_3d_voxel_fs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_3D_VOXEL_FS));
        let draw_3d_voxel_vs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_3d_voxel_vs_source,
        });
        let draw_3d_voxel_fs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_3d_voxel_fs_source,
        });

        let draw_3d_voxel_render_pipeline =
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: None,
                layout: Some(&draw_3d_voxel_pipeline_layout),
                vertex: wgpu::VertexState {
                    module: &draw_3d_voxel_vs_module,
                    entry_point: "main",
                    buffers: &[wgpu::VertexBufferLayout {
                        array_stride: size_of_u64::<Draw3DVoxelPrimitive>(),
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &[
                            // The primitive stores the matrix in a column major
                            // format. We just decompose it here, into 4 vec4s,
                            // because that's where the vertex attribs' limit is.

                            // a_transform_matrix_x
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 0,
                                shader_location: 0,
                            },
                            // a_transform_matrix_y
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 16,
                                shader_location: 1,
                            },
                            // a_transform_matrix_z
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 32,
                                shader_location: 2,
                            },
                            // a_transform_matrix_w
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 48,
                                shader_location: 3,
                            },
                            // a_color
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Uint32,
                                offset: 64,
                                shader_location: 4,
                            },
                        ],
                    }],
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: Some(wgpu::Face::Back),
                    unclipped_depth: false,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    conservative: false,
                },
                depth_stencil: Some(wgpu::DepthStencilState {
                    format: wgpu::TextureFormat::Depth32Float,
                    depth_write_enabled: true,
                    depth_compare: wgpu::CompareFunction::Less,
                    stencil: wgpu::StencilState::default(),
                    bias: wgpu::DepthBiasState::default(),
                }),
                multisample: wgpu::MultisampleState {
                    count: 1,
                    mask: !0,
                    alpha_to_coverage_enabled: false,
                },
                fragment: Some(wgpu::FragmentState {
                    module: &draw_3d_voxel_fs_module,
                    entry_point: "main",
                    targets: &[Some(wgpu::ColorTargetState {
                        format: wgpu::TextureFormat::Rgba8UnormSrgb,
                        blend: Some(wgpu::BlendState {
                            color: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                            alpha: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                        }),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                }),
                multiview: None,
            });

        let draw_3d_debug_outline_uniform_buffer_size =
            NonZeroU64::new(size_of_u64::<Draw3DDebugOutlineUniforms>()).unwrap();
        log::debug!(
            "Uniform buffer size for render pipeline draw_3d_debug_outline: {}",
            draw_3d_debug_outline_uniform_buffer_size,
        );

        let draw_3d_debug_outline_uniform_buffer =
            device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::bytes_of(&Draw3DDebugOutlineUniforms {
                    view_projection_matrix: Mat4::IDENTITY.to_cols_array(),
                }),
                usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::UNIFORM,
            });

        let draw_3d_debug_outline_instance_buffer_size = NonZeroU64::new(
            u64::from(DRAW_3D_DEBUG_OUTLINE_MAX_PRIMITIVE_COUNT)
                * size_of_u64::<Draw3DDebugOutlinePrimitive>(),
        )
        .unwrap();

        let draw_3d_debug_outline_instance_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: None,
            size: draw_3d_debug_outline_instance_buffer_size.get(),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::VERTEX,
            mapped_at_creation: false,
        });

        log::debug!(
            "Instance buffer size for render pipeline draw_3d_debug_outline: {}",
            draw_3d_debug_outline_instance_buffer_size,
        );

        let draw_3d_debug_outline_uniform_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    // TODO(yan): @Speed Cut down visibility to only required stages.
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: Some(draw_3d_debug_outline_uniform_buffer_size),
                    },
                    count: None,
                }],
            });

        let draw_3d_debug_outline_uniform_bind_group =
            device.create_bind_group(&wgpu::BindGroupDescriptor {
                label: None,
                layout: &draw_3d_debug_outline_uniform_bind_group_layout,
                entries: &[wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                        buffer: &draw_3d_debug_outline_uniform_buffer,
                        offset: 0,
                        size: Some(draw_3d_debug_outline_uniform_buffer_size),
                    }),
                }],
            });

        let draw_3d_debug_outline_pipeline_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[&draw_3d_debug_outline_uniform_bind_group_layout],
                push_constant_ranges: &[],
            });

        static DRAW_3D_DEBUG_OUTLINE_VS: &[u32] =
            vk_shader_macros::include_glsl!("src/draw_3d_debug_outline.vert");
        static DRAW_3D_DEBUG_OUTLINE_FS: &[u32] =
            vk_shader_macros::include_glsl!("src/draw_3d_debug_outline.frag");
        let draw_3d_debug_outline_vs_source =
            wgpu::ShaderSource::SpirV(Cow::from(DRAW_3D_DEBUG_OUTLINE_VS));
        let draw_3d_debug_outline_fs_source =
            wgpu::ShaderSource::SpirV(Cow::from(DRAW_3D_DEBUG_OUTLINE_FS));
        let draw_3d_debug_outline_vs_module =
            device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: None,
                source: draw_3d_debug_outline_vs_source,
            });
        let draw_3d_debug_outline_fs_module =
            device.create_shader_module(wgpu::ShaderModuleDescriptor {
                label: None,
                source: draw_3d_debug_outline_fs_source,
            });

        let draw_3d_debug_outline_render_pipeline =
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: None,
                layout: Some(&draw_3d_debug_outline_pipeline_layout),
                vertex: wgpu::VertexState {
                    module: &draw_3d_debug_outline_vs_module,
                    entry_point: "main",
                    buffers: &[wgpu::VertexBufferLayout {
                        array_stride: size_of_u64::<Draw3DDebugOutlinePrimitive>(),
                        step_mode: wgpu::VertexStepMode::Instance,
                        attributes: &[
                            // The primitive stores the matrix in a column major
                            // format. We just decompose it here, into 4 vec4s,
                            // because that's where the vertex attribs' limit is.

                            // a_transform_matrix_x
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 0,
                                shader_location: 0,
                            },
                            // a_transform_matrix_y
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 16,
                                shader_location: 1,
                            },
                            // a_transform_matrix_z
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 32,
                                shader_location: 2,
                            },
                            // a_transform_matrix_w
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x4,
                                offset: 48,
                                shader_location: 3,
                            },
                            // a_color
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Uint32,
                                offset: 64,
                                shader_location: 4,
                            },
                        ],
                    }],
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::LineList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: None,
                    unclipped_depth: false,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    conservative: false,
                },
                depth_stencil: Some(wgpu::DepthStencilState {
                    format: wgpu::TextureFormat::Depth32Float,
                    depth_write_enabled: false,
                    depth_compare: wgpu::CompareFunction::Always,
                    stencil: wgpu::StencilState::default(),
                    bias: wgpu::DepthBiasState::default(),
                }),
                multisample: wgpu::MultisampleState {
                    count: 1,
                    mask: !0,
                    alpha_to_coverage_enabled: false,
                },
                fragment: Some(wgpu::FragmentState {
                    module: &draw_3d_debug_outline_fs_module,
                    entry_point: "main",
                    targets: &[Some(wgpu::ColorTargetState {
                        format: wgpu::TextureFormat::Rgba8UnormSrgb,
                        blend: Some(wgpu::BlendState {
                            color: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                            alpha: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                        }),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                }),
                multiview: None,
            });

        let draw_ui_uniform_buffer_size = NonZeroU64::new(size_of_u64::<DrawUiUniforms>()).unwrap();
        log::debug!(
            "Uniform buffer size for render pipeline draw_ui: {}",
            draw_ui_uniform_buffer_size,
        );

        let draw_ui_uniform_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: None,
            contents: bytemuck::bytes_of(&DrawUiUniforms {
                transform_matrix: Mat4::IDENTITY.to_cols_array(),
                color_mul: 0xffffffff,
                _pad1: 0,
                _pad2: 0,
                _pad3: 0,
            }),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::UNIFORM,
        });

        let draw_ui_uniform_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    // TODO(yan): @Speed Cut down visibility to only required stages.
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: Some(draw_ui_uniform_buffer_size),
                    },
                    count: None,
                }],
            });

        let draw_ui_uniform_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &draw_ui_uniform_bind_group_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                    buffer: &draw_ui_uniform_buffer,
                    offset: 0,
                    size: Some(draw_ui_uniform_buffer_size),
                }),
            }],
        });

        let draw_ui_pipeline_layout =
            device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
                label: None,
                bind_group_layouts: &[
                    &draw_ui_uniform_bind_group_layout,
                    &sampled_texture_bind_group_layout,
                ],
                push_constant_ranges: &[],
            });

        static DRAW_UI_VS: &[u32] = vk_shader_macros::include_glsl!("src/draw_ui.vert");
        static DRAW_UI_FS: &[u32] = vk_shader_macros::include_glsl!("src/draw_ui.frag");
        let draw_ui_vs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_UI_VS));
        let draw_ui_fs_source = wgpu::ShaderSource::SpirV(Cow::from(DRAW_UI_FS));
        let draw_ui_vs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_ui_vs_source,
        });
        let draw_ui_fs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: draw_ui_fs_source,
        });

        let draw_ui_render_pipeline =
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: None,
                layout: Some(&draw_ui_pipeline_layout),
                vertex: wgpu::VertexState {
                    module: &draw_ui_vs_module,
                    entry_point: "main",
                    buffers: &[wgpu::VertexBufferLayout {
                        array_stride: size_of_u64::<DrawUiVertex>(),
                        step_mode: wgpu::VertexStepMode::Vertex,
                        attributes: &[
                            // a_position
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x2,
                                offset: 0,
                                shader_location: 0,
                            },
                            // a_tex_coord
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Float32x2,
                                offset: 8,
                                shader_location: 1,
                            },
                            // a_color
                            wgpu::VertexAttribute {
                                format: wgpu::VertexFormat::Uint32,
                                offset: 16,
                                shader_location: 2,
                            },
                        ],
                    }],
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    cull_mode: Some(wgpu::Face::Back),
                    unclipped_depth: false,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    conservative: false,
                },
                depth_stencil: None,
                multisample: wgpu::MultisampleState {
                    count: 1,
                    mask: !0,
                    alpha_to_coverage_enabled: false,
                },
                fragment: Some(wgpu::FragmentState {
                    module: &draw_ui_fs_module,
                    entry_point: "main",
                    targets: &[Some(wgpu::ColorTargetState {
                        format: surface_format,
                        blend: Some(wgpu::BlendState {
                            color: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                            alpha: wgpu::BlendComponent {
                                src_factor: wgpu::BlendFactor::SrcAlpha,
                                dst_factor: wgpu::BlendFactor::OneMinusSrcAlpha,
                                operation: wgpu::BlendOperation::Add,
                            },
                        }),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                }),
                multiview: None,
            });

        let blit_uniform_buffer_size = NonZeroU64::new(size_of_u64::<BlitUniforms>()).unwrap();
        log::debug!(
            "Uniform buffer size for render pipeline blit: {}",
            blit_uniform_buffer_size,
        );

        let blit_uniform_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: None,
            contents: bytemuck::bytes_of(&BlitUniforms {
                projection_matrix_inverse: Mat4::IDENTITY.to_cols_array(),
                render_mode: RenderMode::Game as u32,
                _pad1: 0,
                _pad2: 0,
                _pad3: 0,
            }),
            usage: wgpu::BufferUsages::COPY_DST | wgpu::BufferUsages::UNIFORM,
        });

        let blit_uniform_bind_group_layout =
            device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
                label: None,
                entries: &[wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    // TODO(yan): @Speed Cut down visibility to only required stages.
                    visibility: wgpu::ShaderStages::VERTEX | wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: Some(blit_uniform_buffer_size),
                    },
                    count: None,
                }],
            });

        let blit_uniform_bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &blit_uniform_bind_group_layout,
            entries: &[wgpu::BindGroupEntry {
                binding: 0,
                resource: wgpu::BindingResource::Buffer(wgpu::BufferBinding {
                    buffer: &blit_uniform_buffer,
                    offset: 0,
                    size: Some(blit_uniform_buffer_size),
                }),
            }],
        });

        let blit_pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: None,
            bind_group_layouts: &[
                &blit_uniform_bind_group_layout,
                &sampled_texture_bind_group_layout,
            ],
            push_constant_ranges: &[],
        });

        static BLIT_VS: &[u32] = vk_shader_macros::include_glsl!("src/blit.vert");
        static BLIT_FS: &[u32] = vk_shader_macros::include_glsl!("src/blit.frag");
        let blit_vs_source = wgpu::ShaderSource::SpirV(Cow::from(BLIT_VS));
        let blit_fs_source = wgpu::ShaderSource::SpirV(Cow::from(BLIT_FS));
        let blit_vs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: blit_vs_source,
        });
        let blit_fs_module = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: None,
            source: blit_fs_source,
        });

        let blit_render_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: None,
            layout: Some(&blit_pipeline_layout),
            vertex: wgpu::VertexState {
                module: &blit_vs_module,
                entry_point: "main",
                buffers: &[],
            },
            primitive: wgpu::PrimitiveState {
                topology: wgpu::PrimitiveTopology::TriangleList,
                strip_index_format: None,
                front_face: wgpu::FrontFace::Ccw,
                cull_mode: Some(wgpu::Face::Back),
                unclipped_depth: false,
                polygon_mode: wgpu::PolygonMode::Fill,
                conservative: false,
            },
            depth_stencil: None,
            multisample: wgpu::MultisampleState {
                count: 1,
                mask: !0,
                alpha_to_coverage_enabled: false,
            },
            fragment: Some(wgpu::FragmentState {
                module: &blit_fs_module,
                entry_point: "main",
                targets: &[Some(wgpu::ColorTargetState {
                    format: surface_format,
                    blend: None,
                    write_mask: wgpu::ColorWrites::ALL,
                })],
            }),
            multiview: None,
        });

        Self {
            surface,
            surface_format,
            surface_present_mode,
            device,
            queue,

            window_size,
            window_size_stale: false,
            window_scale_factor,

            nearest_sampler,
            bilinear_sampler,
            sampled_texture_bind_group_layout,

            intermediate_color_texture_view,
            intermediate_color_texture_bind_group,
            intermediate_depth_texture_view,
            intermediate_depth_texture_bind_group,

            draw_2d_rect_uniform_buffer,
            draw_2d_rect_instance_buffer,
            draw_2d_rect_uniform_bind_group,
            draw_2d_rect_render_pipeline,

            draw_3d_rect_uniform_buffer,
            draw_3d_rect_instance_buffer,
            draw_3d_rect_instance_buffer_mem,
            draw_3d_rect_uniform_bind_group,
            draw_3d_rect_render_pipeline,

            draw_3d_voxel_uniform_buffer,
            draw_3d_voxel_instance_buffer,
            draw_3d_voxel_uniform_bind_group,
            draw_3d_voxel_render_pipeline,

            draw_3d_debug_outline_uniform_buffer,
            draw_3d_debug_outline_instance_buffer,
            draw_3d_debug_outline_uniform_bind_group,
            draw_3d_debug_outline_render_pipeline,

            draw_ui_uniform_buffer,
            draw_ui_uniform_bind_group,
            draw_ui_render_pipeline,

            blit_uniform_buffer,
            blit_uniform_bind_group,
            blit_render_pipeline,

            texture_resources: HashMap::new(),
        }
    }

    pub fn set_window_size(&mut self, window_size: UVec2) {
        if window_size != self.window_size {
            self.window_size = window_size;
            self.window_size_stale = true;
        }
    }

    pub fn set_window_scale_factor(&mut self, window_scale_factor: f32) {
        self.window_scale_factor = window_scale_factor;
    }

    pub fn insert_texture_rgba8_unorm(
        &mut self,
        texture_id: u64,
        data: &[u8],
        width: u16,
        height: u16,
        color_space: ColorSpace,
        sampler: Sampler,
    ) {
        profile_scope!("WgpuRenderer::insert_texture_rgba8_unorm");

        log::debug!(
            "Allocating texture: {:016x}, RGBA8_UNORM, {}x{}, {:?}, {:?}",
            texture_id,
            width,
            height,
            color_space,
            sampler,
        );

        let texture = self.device.create_texture_with_data(
            &self.queue,
            &wgpu::TextureDescriptor {
                label: None,
                size: wgpu::Extent3d {
                    width: u32::from(width),
                    height: u32::from(height),
                    depth_or_array_layers: 1,
                },
                mip_level_count: 1,
                sample_count: 1,
                dimension: wgpu::TextureDimension::D2,
                format: match color_space {
                    ColorSpace::Linear => wgpu::TextureFormat::Rgba8Unorm,
                    ColorSpace::Srgb => wgpu::TextureFormat::Rgba8UnormSrgb,
                },
                usage: wgpu::TextureUsages::COPY_DST | wgpu::TextureUsages::TEXTURE_BINDING,
            },
            data,
        );

        let texture_view = texture.create_view(&wgpu::TextureViewDescriptor::default());
        let texture_bind_group = self.device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: None,
            layout: &self.sampled_texture_bind_group_layout,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::Sampler(match sampler {
                        Sampler::Nearest => &self.nearest_sampler,
                        Sampler::Bilinear => &self.bilinear_sampler,
                    }),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: wgpu::BindingResource::TextureView(&texture_view),
                },
            ],
        });

        self.texture_resources
            .insert(texture_id, TextureResource { texture_bind_group });
    }

    pub fn remove_texture(&mut self, texture_id: u64) {
        profile_scope!("WgpuRenderer::remove_texture");

        log::debug!("Deallocating texture: {texture_id:016x}");
        self.texture_resources.remove(&texture_id);
    }

    pub fn begin_frame(
        &mut self,
        clear_color: [f32; 4],
        clear_depth: f32,
        view_matrix: Mat4,
        projection_matrix: Mat4,
        render_mode: RenderMode,
        ui_color_mul: u32,
    ) -> Option<WgpuFrame> {
        profile_scope!("WgpuRenderer::begin_frame");

        let view_projection_matrix = projection_matrix * view_matrix;

        self.queue.write_buffer(
            &self.draw_2d_rect_uniform_buffer,
            0,
            bytemuck::bytes_of(&Draw2DRectUniforms {
                screen_width: self.window_size.x,
                screen_height: self.window_size.y,
                _pad1: 0,
                _pad2: 0,
            }),
        );

        self.queue.write_buffer(
            &self.draw_3d_rect_uniform_buffer,
            0,
            bytemuck::bytes_of(&Draw3DRectUniforms {
                view_projection_matrix: view_projection_matrix.to_cols_array(),
            }),
        );

        self.queue.write_buffer(
            &self.draw_3d_voxel_uniform_buffer,
            0,
            bytemuck::bytes_of(&Draw3DVoxelUniforms {
                view_projection_matrix: view_projection_matrix.to_cols_array(),
            }),
        );

        self.queue.write_buffer(
            &self.draw_3d_debug_outline_uniform_buffer,
            0,
            bytemuck::bytes_of(&Draw3DDebugOutlineUniforms {
                view_projection_matrix: view_projection_matrix.to_cols_array(),
            }),
        );

        let ui_transform_matrix = {
            // Setup orthographic projection matrix.
            let l = 0.0;
            let r = self.window_size.x as f32 / self.window_scale_factor;
            let t = 0.0;
            let b = self.window_size.y as f32 / self.window_scale_factor;

            #[rustfmt::skip]
            let m = [
                2.0 / (r - l)    , 0.0              , 0.0, 0.0,
                0.0              , 2.0 / (t - b)    , 0.0, 0.0,
                0.0              , 0.0              , 0.5, 0.0,
                (r + l) / (l - r), (t + b) / (b - t), 0.5, 1.0,
            ];

            m
        };

        self.queue.write_buffer(
            &self.draw_ui_uniform_buffer,
            0,
            bytemuck::bytes_of(&DrawUiUniforms {
                transform_matrix: ui_transform_matrix,
                color_mul: ui_color_mul,
                _pad1: 0,
                _pad2: 0,
                _pad3: 0,
            }),
        );

        self.queue.write_buffer(
            &self.blit_uniform_buffer,
            0,
            bytemuck::bytes_of(&BlitUniforms {
                projection_matrix_inverse: projection_matrix.inverse().to_cols_array(),
                render_mode: render_mode as u32,
                _pad1: 0,
                _pad2: 0,
                _pad3: 0,
            }),
        );

        if self.window_size_stale {
            let (intermediate_color_texture_view, intermediate_depth_texture_view) =
                create_intermediate_textures(&self.device, self.window_size);

            let intermediate_color_texture_bind_group =
                self.device.create_bind_group(&wgpu::BindGroupDescriptor {
                    label: None,
                    layout: &self.sampled_texture_bind_group_layout,
                    entries: &[
                        wgpu::BindGroupEntry {
                            binding: 0,
                            // Nearest sampling should be ok here, because
                            // dimensions match.
                            resource: wgpu::BindingResource::Sampler(&self.nearest_sampler),
                        },
                        wgpu::BindGroupEntry {
                            binding: 1,
                            resource: wgpu::BindingResource::TextureView(
                                &intermediate_color_texture_view,
                            ),
                        },
                    ],
                });

            let intermediate_depth_texture_bind_group =
                self.device.create_bind_group(&wgpu::BindGroupDescriptor {
                    label: None,
                    layout: &self.sampled_texture_bind_group_layout,
                    entries: &[
                        wgpu::BindGroupEntry {
                            binding: 0,
                            // Nearest sampling should be ok here, because
                            // dimensions match.
                            resource: wgpu::BindingResource::Sampler(&self.nearest_sampler),
                        },
                        wgpu::BindGroupEntry {
                            binding: 1,
                            resource: wgpu::BindingResource::TextureView(
                                &intermediate_depth_texture_view,
                            ),
                        },
                    ],
                });

            self.surface.configure(
                &self.device,
                &wgpu::SurfaceConfiguration {
                    usage: wgpu::TextureUsages::RENDER_ATTACHMENT,
                    format: self.surface_format,
                    width: self.window_size.x,
                    height: self.window_size.y,
                    present_mode: self.surface_present_mode,
                },
            );

            self.intermediate_color_texture_view = intermediate_color_texture_view;
            self.intermediate_color_texture_bind_group = intermediate_color_texture_bind_group;
            self.intermediate_depth_texture_view = intermediate_depth_texture_view;
            self.intermediate_depth_texture_bind_group = intermediate_depth_texture_bind_group;

            self.window_size_stale = false;
        }

        let surface_texture = {
            match self.surface.get_current_texture() {
                Ok(surface_texture) => surface_texture,
                Err(err) => {
                    log::warn!("GPU current surface texture acquisition failed: {}", err);
                    return None;
                }
            }
        };

        if surface_texture.suboptimal {
            log::warn!("GPU surface texture suboptimal");
        }

        let surface_texture_view = surface_texture
            .texture
            .create_view(&wgpu::TextureViewDescriptor::default());

        let encoder = self
            .device
            .create_command_encoder(&wgpu::CommandEncoderDescriptor { label: None });

        Some(WgpuFrame {
            clear_color: Some(clear_color),
            clear_depth: Some(clear_depth),
            clear_surface_color: Some(clear_color),

            surface_texture,
            surface_texture_view,

            encoder,
            device: &self.device,
            queue: &self.queue,

            window_size: self.window_size,
            window_scale_factor: self.window_scale_factor,
            render_mode,

            view_matrix,

            intermediate_color_texture_view: &self.intermediate_color_texture_view,
            intermediate_color_texture_bind_group: &self.intermediate_color_texture_bind_group,
            intermediate_depth_texture_view: &self.intermediate_depth_texture_view,
            intermediate_depth_texture_bind_group: &self.intermediate_depth_texture_bind_group,

            draw_2d_rect_instance_buffer: &self.draw_2d_rect_instance_buffer,
            draw_2d_rect_uniform_bind_group: &self.draw_2d_rect_uniform_bind_group,
            draw_2d_rect_render_pipeline: &self.draw_2d_rect_render_pipeline,

            draw_3d_rect_instance_buffer: &self.draw_3d_rect_instance_buffer,
            draw_3d_rect_instance_buffer_mem: &mut self.draw_3d_rect_instance_buffer_mem,
            draw_3d_rect_uniform_bind_group: &self.draw_3d_rect_uniform_bind_group,
            draw_3d_rect_render_pipeline: &self.draw_3d_rect_render_pipeline,

            draw_3d_voxel_instance_buffer: &self.draw_3d_voxel_instance_buffer,
            draw_3d_voxel_uniform_bind_group: &self.draw_3d_voxel_uniform_bind_group,
            draw_3d_voxel_render_pipeline: &self.draw_3d_voxel_render_pipeline,

            draw_3d_debug_outline_instance_buffer: &self.draw_3d_debug_outline_instance_buffer,
            draw_3d_debug_outline_uniform_bind_group: &self
                .draw_3d_debug_outline_uniform_bind_group,
            draw_3d_debug_outline_render_pipeline: &self.draw_3d_debug_outline_render_pipeline,

            draw_ui_uniform_bind_group: &self.draw_ui_uniform_bind_group,
            draw_ui_render_pipeline: &self.draw_ui_render_pipeline,

            blit_uniform_bind_group: &self.blit_uniform_bind_group,
            blit_render_pipeline: &self.blit_render_pipeline,

            texture_resources: &self.texture_resources,
        })
    }
}

pub struct WgpuFrame<'a> {
    clear_color: Option<[f32; 4]>,
    clear_depth: Option<f32>,
    clear_surface_color: Option<[f32; 4]>,

    surface_texture: wgpu::SurfaceTexture,
    surface_texture_view: wgpu::TextureView,

    encoder: wgpu::CommandEncoder,
    device: &'a wgpu::Device,
    queue: &'a wgpu::Queue,

    window_size: UVec2,
    window_scale_factor: f32,
    render_mode: RenderMode,

    view_matrix: Mat4,

    intermediate_color_texture_view: &'a wgpu::TextureView,
    intermediate_color_texture_bind_group: &'a wgpu::BindGroup,
    intermediate_depth_texture_view: &'a wgpu::TextureView,
    intermediate_depth_texture_bind_group: &'a wgpu::BindGroup,

    draw_2d_rect_instance_buffer: &'a wgpu::Buffer,
    draw_2d_rect_uniform_bind_group: &'a wgpu::BindGroup,
    draw_2d_rect_render_pipeline: &'a wgpu::RenderPipeline,

    draw_3d_rect_instance_buffer: &'a wgpu::Buffer,
    draw_3d_rect_instance_buffer_mem: &'a mut Vec<Draw3DRectPrimitive>,
    draw_3d_rect_uniform_bind_group: &'a wgpu::BindGroup,
    draw_3d_rect_render_pipeline: &'a wgpu::RenderPipeline,

    draw_3d_voxel_instance_buffer: &'a wgpu::Buffer,
    draw_3d_voxel_uniform_bind_group: &'a wgpu::BindGroup,
    draw_3d_voxel_render_pipeline: &'a wgpu::RenderPipeline,

    draw_3d_debug_outline_instance_buffer: &'a wgpu::Buffer,
    draw_3d_debug_outline_uniform_bind_group: &'a wgpu::BindGroup,
    draw_3d_debug_outline_render_pipeline: &'a wgpu::RenderPipeline,

    draw_ui_uniform_bind_group: &'a wgpu::BindGroup,
    draw_ui_render_pipeline: &'a wgpu::RenderPipeline,

    blit_uniform_bind_group: &'a wgpu::BindGroup,
    blit_render_pipeline: &'a wgpu::RenderPipeline,

    texture_resources: &'a HashMap<u64, TextureResource>,
}

impl<'a> WgpuFrame<'a> {
    pub fn draw_2d_rects_to_intermediate(
        &mut self,
        commands: &[Draw2DRectCommand],
        primitives: &[Draw2DRectPrimitive],
    ) {
        profile_scope!("WgpuFrame::draw_2d_rects_to_intermediate");

        if primitives.is_empty() {
            // wgpu buffer slices panic if they are empty.
            return;
        }

        // TODO(yan): Use trunc_32 instead of cast_u32.
        let primitive_count = cast_u32!(primitives.len());
        let instance_count = u32::min(primitive_count, DRAW_2D_RECT_MAX_PRIMITIVE_COUNT);

        if primitive_count > instance_count {
            // TODO(yan): Becuase these do not interact with depth in any way,
            // we can just naturally degrade into multiple batches here instead
            // of dropping geometry.
            log::warn!(
                "Instance buffer not big enough to draw all: need {}, have {}",
                primitive_count,
                instance_count,
            );
        }

        let instances = &primitives[..cast_usize!(instance_count)];
        self.queue.write_buffer(
            &self.draw_2d_rect_instance_buffer,
            0,
            bytemuck::cast_slice(instances),
        );

        let mut render_pass = self.encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: self.intermediate_color_texture_view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: if let Some([r, g, b, a]) = self.clear_color {
                        wgpu::LoadOp::Clear(wgpu::Color {
                            r: r.into(),
                            g: g.into(),
                            b: b.into(),
                            a: a.into(),
                        })
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],
            depth_stencil_attachment: None,
        });

        render_pass.set_pipeline(self.draw_2d_rect_render_pipeline);
        render_pass.set_vertex_buffer(
            0,
            self.draw_2d_rect_instance_buffer
                .slice(..u64::from(instance_count) * size_of_u64::<Draw2DRectPrimitive>()),
        );
        render_pass.set_bind_group(0, self.draw_2d_rect_uniform_bind_group, &[]);

        let mut consumed_primitive_count = 0;
        for command in commands {
            let texture_resource = match self.texture_resources.get(&command.texture_id) {
                Some(texture_resource) => texture_resource,
                None => {
                    log::error!("Missing texture {}", command.texture_id);
                    continue;
                }
            };

            render_pass.set_bind_group(1, &texture_resource.texture_bind_group, &[]);
            render_pass.draw(
                0..6,
                consumed_primitive_count..(consumed_primitive_count + command.primitive_count),
            );

            consumed_primitive_count += command.primitive_count;
        }

        self.clear_color = None;
    }

    pub fn draw_3d_rects_to_intermediate(&mut self, primitives: &[Draw3DRectPrimitive]) {
        profile_scope!("WgpuFrame::draw_3d_rects_to_intermediate");

        if primitives.is_empty() {
            // wgpu buffer slices panic if they are empty.
            return;
        }

        self.draw_3d_rect_instance_buffer_mem.clear();
        self.draw_3d_rect_instance_buffer_mem.extend(primitives);

        {
            profile_scope!("WgpuFrame::draw_3d_rects_to_intermediate sort");

            // Because everything can be transparent and we use blends,
            // render back-to-front.
            self.draw_3d_rect_instance_buffer_mem
                .sort_unstable_by(|left_p, right_p| {
                    // TODO(yan): @Speed Isn't this quite a bit of work for a sort
                    // callback?
                    let left_m = self.view_matrix * left_p.transform_matrix;
                    let right_m = self.view_matrix * right_p.transform_matrix;

                    let left = left_m.transform_point3(Vec3::ZERO);
                    let right = right_m.transform_point3(Vec3::ZERO);

                    // After the model and view transforms we end up in the view
                    // space, which is right handed and camera points in
                    // negative Z.
                    cmp_f32(left.z, right.z)
                });
        }

        // We only need the sorted version after this.
        let primitives = &self.draw_3d_rect_instance_buffer_mem;

        // TODO(yan): Use trunc_32 instead of cast_u32.
        let primitive_count = cast_u32!(primitives.len());
        let instance_count = u32::min(primitive_count, DRAW_3D_RECT_MAX_PRIMITIVE_COUNT);

        if primitive_count > instance_count {
            log::warn!(
                "Instance buffer not big enough to draw all: need {}, have {}",
                primitive_count,
                instance_count,
            );
        }

        let instances = &primitives[..cast_usize!(instance_count)];
        self.queue.write_buffer(
            &self.draw_3d_rect_instance_buffer,
            0,
            bytemuck::cast_slice(instances),
        );

        let mut render_pass = self.encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: self.intermediate_color_texture_view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: if let Some([r, g, b, a]) = self.clear_color {
                        wgpu::LoadOp::Clear(wgpu::Color {
                            r: r.into(),
                            g: g.into(),
                            b: b.into(),
                            a: a.into(),
                        })
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view: self.intermediate_depth_texture_view,
                depth_ops: Some(wgpu::Operations {
                    load: if let Some(depth) = self.clear_depth {
                        wgpu::LoadOp::Clear(depth)
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                }),
                stencil_ops: None,
            }),
        });

        render_pass.set_pipeline(self.draw_3d_rect_render_pipeline);
        render_pass.set_vertex_buffer(
            0,
            self.draw_3d_rect_instance_buffer
                .slice(..u64::from(instance_count) * size_of_u64::<Draw3DRectPrimitive>()),
        );
        render_pass.set_bind_group(0, self.draw_3d_rect_uniform_bind_group, &[]);

        let mut consumed_primitive_count = 0;
        for instance in instances {
            let texture_resource = match self.texture_resources.get(&instance.texture_id) {
                Some(texture_resource) => texture_resource,
                None => {
                    log::error!("Missing texture {}", instance.texture_id);
                    continue;
                }
            };

            render_pass.set_bind_group(1, &texture_resource.texture_bind_group, &[]);
            render_pass.draw(0..6, consumed_primitive_count..consumed_primitive_count + 1);

            consumed_primitive_count += 1;
        }

        self.clear_color = None;
        self.clear_depth = None;
    }

    pub fn draw_3d_voxels_to_intermediate(&mut self, primitives: &[Draw3DVoxelPrimitive]) {
        profile_scope!("WgpuFrame::draw_3d_voxels_to_intermediate");

        if primitives.is_empty() {
            // wgpu buffer slices panic if they are empty.
            return;
        }

        // TODO(yan): Use trunc_32 instead of cast_u32.
        let primitive_count = cast_u32!(primitives.len());
        let instance_count = u32::min(primitive_count, DRAW_3D_VOXEL_MAX_PRIMITIVE_COUNT);

        if primitive_count > instance_count {
            log::warn!(
                "Instance buffer not big enough to draw all: need {}, have {}",
                primitive_count,
                instance_count,
            );
        }

        let instances = &primitives[..cast_usize!(instance_count)];
        self.queue.write_buffer(
            &self.draw_3d_voxel_instance_buffer,
            0,
            bytemuck::cast_slice(instances),
        );

        let mut render_pass = self.encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: self.intermediate_color_texture_view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: if let Some([r, g, b, a]) = self.clear_color {
                        wgpu::LoadOp::Clear(wgpu::Color {
                            r: r.into(),
                            g: g.into(),
                            b: b.into(),
                            a: a.into(),
                        })
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view: self.intermediate_depth_texture_view,
                depth_ops: Some(wgpu::Operations {
                    load: if let Some(depth) = self.clear_depth {
                        wgpu::LoadOp::Clear(depth)
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                }),
                stencil_ops: None,
            }),
        });

        render_pass.set_pipeline(self.draw_3d_voxel_render_pipeline);
        render_pass.set_vertex_buffer(
            0,
            self.draw_3d_voxel_instance_buffer
                .slice(..u64::from(instance_count) * size_of_u64::<Draw3DVoxelPrimitive>()),
        );
        render_pass.set_bind_group(0, self.draw_3d_voxel_uniform_bind_group, &[]);
        render_pass.draw(0..36, 0..instance_count);

        self.clear_color = None;
        self.clear_depth = None;
    }

    pub fn draw_3d_debug_outlines_to_intermediate(
        &mut self,
        primitives: &[Draw3DDebugOutlinePrimitive],
    ) {
        profile_scope!("WgpuFrame::draw_3d_debug_outlines_to_intermediate");

        if primitives.is_empty() {
            // wgpu buffer slices panic if they are empty.
            return;
        }

        // TODO(yan): Use trunc_32 instead of cast_u32.
        let primitive_count = cast_u32!(primitives.len());
        let instance_count = u32::min(primitive_count, DRAW_3D_DEBUG_OUTLINE_MAX_PRIMITIVE_COUNT);

        if primitive_count > instance_count {
            // TODO(yan): Becuase these do not interact with depth in any way
            // and are usually rendered last to xray, we can just naturally
            // degrade into multiple batches here instead of dropping geometry.
            log::warn!(
                "Instance buffer not big enough to draw all: need {}, have {}",
                primitive_count,
                instance_count,
            );
        }

        let instances = &primitives[..cast_usize!(instance_count)];
        self.queue.write_buffer(
            &self.draw_3d_debug_outline_instance_buffer,
            0,
            bytemuck::cast_slice(instances),
        );

        let mut render_pass = self.encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: self.intermediate_color_texture_view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: if let Some([r, g, b, a]) = self.clear_color {
                        wgpu::LoadOp::Clear(wgpu::Color {
                            r: r.into(),
                            g: g.into(),
                            b: b.into(),
                            a: a.into(),
                        })
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],
            depth_stencil_attachment: Some(wgpu::RenderPassDepthStencilAttachment {
                view: self.intermediate_depth_texture_view,
                depth_ops: Some(wgpu::Operations {
                    load: if let Some(depth) = self.clear_depth {
                        wgpu::LoadOp::Clear(depth)
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                }),
                stencil_ops: None,
            }),
        });

        render_pass.set_pipeline(self.draw_3d_debug_outline_render_pipeline);
        render_pass.set_vertex_buffer(
            0,
            self.draw_3d_debug_outline_instance_buffer
                .slice(..u64::from(instance_count) * size_of_u64::<Draw3DVoxelPrimitive>()),
        );
        render_pass.set_bind_group(0, self.draw_3d_debug_outline_uniform_bind_group, &[]);
        render_pass.draw(0..24, 0..instance_count);

        self.clear_color = None;
        self.clear_depth = None;
    }

    pub fn draw_ui_to_surface(
        &mut self,
        commands: &[DrawUiCommand],
        vertices: &[DrawUiVertex],
        indices: &[u32],
    ) {
        profile_scope!("WgpuFrame::draw_ui_to_surface");

        if commands.is_empty() || vertices.is_empty() || indices.is_empty() {
            return;
        }

        if self.window_size.x == 0 || self.window_size.y == 0 {
            return;
        }

        // TODO(yan): @Speed Pre-allocate and reuse vertex and index buffers.
        let vertex_buffer = self
            .device
            .create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(vertices),
                usage: wgpu::BufferUsages::VERTEX,
            });

        let index_buffer = self
            .device
            .create_buffer_init(&wgpu::util::BufferInitDescriptor {
                label: None,
                contents: bytemuck::cast_slice(indices),
                usage: wgpu::BufferUsages::INDEX,
            });

        let mut render_pass = self.encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: &self.surface_texture_view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: if let Some([r, g, b, a]) = self.clear_surface_color {
                        wgpu::LoadOp::Clear(wgpu::Color {
                            r: r.into(),
                            g: g.into(),
                            b: b.into(),
                            a: a.into(),
                        })
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],
            depth_stencil_attachment: None,
        });

        render_pass.set_pipeline(self.draw_ui_render_pipeline);
        render_pass.set_vertex_buffer(0, vertex_buffer.slice(..));
        render_pass.set_index_buffer(index_buffer.slice(..), wgpu::IndexFormat::Uint32);
        render_pass.set_bind_group(0, self.draw_ui_uniform_bind_group, &[]);

        let vw = self.window_size.x;
        let vh = self.window_size.y;

        let mut consumed_index_count: u32 = 0;
        for command in commands {
            let x = (self.window_scale_factor * command.scissor_rect.x).floor() as u32;
            let y = (self.window_scale_factor * command.scissor_rect.y).floor() as u32;
            let w = (self.window_scale_factor * command.scissor_rect.width).round() as u32;
            let h = (self.window_scale_factor * command.scissor_rect.height).round() as u32;
            if w == 0 || h == 0 || x + w > vw || y + h > vh {
                log::error!("Scissor rect ({x} {y} {w} {h}) invalid");
                continue;
            }

            let texture_resource = match self.texture_resources.get(&command.texture_id) {
                Some(texture_resource) => texture_resource,
                None => {
                    log::error!("Missing texture {}", command.texture_id);
                    continue;
                }
            };

            render_pass.set_scissor_rect(x, y, w, h);
            render_pass.set_bind_group(1, &texture_resource.texture_bind_group, &[]);
            render_pass.draw_indexed(
                consumed_index_count..(consumed_index_count + command.index_count),
                0,
                0..1,
            );

            consumed_index_count += command.index_count;
        }

        self.clear_surface_color = None;
    }

    pub fn blit_intermediate_to_surface(&mut self) {
        profile_scope!("WgpuFrame::blit_intermediate_to_surface");

        let mut blit_pass = self.encoder.begin_render_pass(&wgpu::RenderPassDescriptor {
            label: None,
            color_attachments: &[Some(wgpu::RenderPassColorAttachment {
                view: &self.surface_texture_view,
                resolve_target: None,
                ops: wgpu::Operations {
                    load: if let Some([r, g, b, a]) = self.clear_surface_color {
                        wgpu::LoadOp::Clear(wgpu::Color {
                            r: r.into(),
                            g: g.into(),
                            b: b.into(),
                            a: a.into(),
                        })
                    } else {
                        wgpu::LoadOp::Load
                    },
                    store: true,
                },
            })],
            depth_stencil_attachment: None,
        });

        blit_pass.set_pipeline(self.blit_render_pipeline);
        blit_pass.set_bind_group(0, self.blit_uniform_bind_group, &[]);

        match self.render_mode {
            RenderMode::Game => {
                blit_pass.set_bind_group(1, self.intermediate_color_texture_bind_group, &[]);
            }
            RenderMode::DepthMap => {
                blit_pass.set_bind_group(1, self.intermediate_depth_texture_bind_group, &[]);
            }
        }

        blit_pass.draw(0..3, 0..1);

        self.clear_surface_color = None;
    }

    pub fn submit_and_present(self) {
        profile_scope!("WgpuFrame::submit_and_present");

        self.queue.submit(iter::once(self.encoder.finish()));

        // TODO(yan): @Correctness According to Casey, at least in OpenGL, the
        // driver can decide to buffer up our draw call instead of blocking, and
        // only blocks once it has filled its buffer capacity with
        // frames/commands. Do we need to sleep explicitly at the end of our
        // frame? wgpu docs are not helpful here either - they kinda imply that
        // PresentMode::Fifo blocks us here, but do not say so precisely. Also,
        // unlike Vulkan, it is unclear how deep the pipeline is here is, and
        // when exactly does PresentMode::Fifo block us here.
        self.surface_texture.present();
    }
}

impl Renderer for WgpuRenderer {
    type Frame<'a> = WgpuFrame<'a>;

    #[inline]
    fn insert_texture_rgba8_unorm(
        &mut self,
        texture_id: u64,
        data: &[u8],
        width: u16,
        height: u16,
        color_space: ColorSpace,
        sampler: Sampler,
    ) {
        self.insert_texture_rgba8_unorm(texture_id, data, width, height, color_space, sampler);
    }

    #[inline]
    fn remove_texture(&mut self, texture_id: u64) {
        self.remove_texture(texture_id);
    }

    #[inline]
    fn begin_frame(
        &mut self,
        clear_color: [f32; 4],
        clear_depth: f32,
        view_matrix: Mat4,
        projection_matrix: Mat4,
        render_mode: RenderMode,
        ui_color_mul: u32,
    ) -> Option<Self::Frame<'_>> {
        self.begin_frame(
            clear_color,
            clear_depth,
            view_matrix,
            projection_matrix,
            render_mode,
            ui_color_mul,
        )
    }
}

impl<'a> Frame<'a> for WgpuFrame<'a> {
    #[inline]
    fn draw_2d_rects_to_intermediate(
        &mut self,
        commands: &[Draw2DRectCommand],
        primitives: &[Draw2DRectPrimitive],
    ) {
        self.draw_2d_rects_to_intermediate(commands, primitives);
    }

    #[inline]
    fn draw_3d_rects_to_intermediate(&mut self, primitives: &[Draw3DRectPrimitive]) {
        self.draw_3d_rects_to_intermediate(primitives);
    }

    #[inline]
    fn draw_3d_voxels_to_intermediate(&mut self, primitives: &[Draw3DVoxelPrimitive]) {
        self.draw_3d_voxels_to_intermediate(primitives);
    }

    #[inline]
    fn draw_3d_debug_outlines_to_intermediate(
        &mut self,
        primitives: &[Draw3DDebugOutlinePrimitive],
    ) {
        self.draw_3d_debug_outlines_to_intermediate(primitives);
    }

    #[inline]
    fn draw_ui_to_surface(
        &mut self,
        commands: &[DrawUiCommand],
        vertices: &[DrawUiVertex],
        indices: &[u32],
    ) {
        self.draw_ui_to_surface(commands, vertices, indices);
    }

    #[inline]
    fn blit_intermediate_to_surface(&mut self) {
        self.blit_intermediate_to_surface()
    }

    #[inline]
    fn submit_and_present(self) {
        self.submit_and_present();
    }
}

fn create_intermediate_textures(
    device: &wgpu::Device,
    size: UVec2,
) -> (wgpu::TextureView, wgpu::TextureView) {
    // TODO(yan): @Correctness Our UI gets mapped to SRBG twice, once by the
    // surface texture, and once by our own eye. We'd like to have the UI in
    // RGBA.
    //
    // To do that, we'll need the intermediate color texture to have two views -
    // one for writing and one for reading. We SRGB-encode everything we write,
    // but do not SRGB-decode things we read. We also change the surface texture
    // view to not do SRGB encoding.
    //
    // This currently doesn't work with wgpu, and maybe there is a good reason
    // why it doesn't.
    //
    // https://github.com/gfx-rs/wgpu/issues/3030

    let color = device.create_texture(&wgpu::TextureDescriptor {
        label: None,
        size: wgpu::Extent3d {
            width: size.x,
            height: size.y,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Rgba8UnormSrgb,
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
    });
    let color_view = color.create_view(&wgpu::TextureViewDescriptor::default());

    let depth = device.create_texture(&wgpu::TextureDescriptor {
        label: None,
        size: wgpu::Extent3d {
            width: size.x,
            height: size.y,
            depth_or_array_layers: 1,
        },
        mip_level_count: 1,
        sample_count: 1,
        dimension: wgpu::TextureDimension::D2,
        format: wgpu::TextureFormat::Depth32Float,
        // TODO(yan): @Speed Potentially remove the TEXTURE_BINDING usage for
        // non-developer builds. We might want to view it in developer builds.
        usage: wgpu::TextureUsages::RENDER_ATTACHMENT | wgpu::TextureUsages::TEXTURE_BINDING,
    });
    let depth_view = depth.create_view(&wgpu::TextureViewDescriptor::default());

    (color_view, depth_view)
}

const fn size_of_u64<T>() -> u64 {
    let size = std::mem::size_of::<T>();
    if usize::BITS > u64::BITS {
        assert!(size <= u64::MAX as usize);
    }

    size as u64
}
