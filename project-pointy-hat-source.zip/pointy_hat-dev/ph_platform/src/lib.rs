#![no_std]
#![feature(allocator_api)]

extern crate alloc;

use alloc::vec::Vec;
use core::alloc::Allocator;
use core::borrow::{Borrow, BorrowMut};
use core::convert::{AsMut, AsRef};
use core::fmt;
use core::ops::{Deref, DerefMut};

use lfg_alloc::Linear;

#[derive(Debug)]
pub struct PlatformError;

impl fmt::Display for PlatformError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{:?}", self)
    }
}

// Because we sometimes cast binary files directly into their types, we need to
// ensure alignment of the Vec<u8> we normally load. We can do that with a bit
// of unsafe code, but to make sure the data stays aligned at requested
// alignment, we need to prevent the Vec from reallocating. We do that by hiding
// it inside AlignedSlice, which only allows slice functions.
//
// Note: Clone not implemented on purpose, because the alignement would not be
// preserved.
#[derive(Debug, PartialEq, Eq, Hash)]
pub struct AlignSlice<A: Allocator>(Vec<u8, A>);

impl<A: Allocator> AlignSlice<A> {
    pub unsafe fn new_unchecked(vec: Vec<u8, A>) -> Self {
        Self(vec)
    }
}

impl<A: Allocator> Borrow<[u8]> for AlignSlice<A> {
    fn borrow(&self) -> &[u8] {
        &self.0
    }
}

impl<A: Allocator> BorrowMut<[u8]> for AlignSlice<A> {
    fn borrow_mut(&mut self) -> &mut [u8] {
        &mut self.0
    }
}

impl<A: Allocator> AsRef<[u8]> for AlignSlice<A> {
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

impl<A: Allocator> AsMut<[u8]> for AlignSlice<A> {
    fn as_mut(&mut self) -> &mut [u8] {
        &mut self.0
    }
}

impl<A: Allocator> Deref for AlignSlice<A> {
    type Target = [u8];

    fn deref(&self) -> &[u8] {
        &self.0
    }
}

impl<A: Allocator> DerefMut for AlignSlice<A> {
    fn deref_mut(&mut self) -> &mut [u8] {
        &mut self.0
    }
}

#[derive(Debug)]
pub struct Image<A: Allocator> {
    pub color_type: ColorType,
    pub color_bit_depth: ColorBitDepth,
    pub data: Vec<u8, A>,
    pub width: u16,
    pub height: u16,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ColorType {
    Rgb,
    Rgba,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ColorBitDepth {
    D8,
}

// TODO(yan): String<A>
pub struct ListedFile<'a> {
    pub file_path: Vec<u8, &'a Linear>,
    pub file_stem: Vec<u8, &'a Linear>,
    pub file_ext: Vec<u8, &'a Linear>,
}

pub trait Platform {
    // Note: Platform::read_file, Platform::read_file_align4 and
    // Platform::read_png are parametric over allocator instead of directly
    // using the linear allocator. This is because they might be called in loops
    // with scoped linear allocators.
    fn read_file<A: Allocator>(
        &self,
        allocator: A,
        path: &str,
    ) -> Result<Vec<u8, A>, PlatformError>;
    fn read_file_align4<A: Allocator>(
        &self,
        allocator: A,
        path: &str,
    ) -> Result<AlignSlice<A>, PlatformError>;
    // TODO(yan): The png crate is not no_std, not even the decoder, so we hide
    // it behind the platform for now. There's also
    // https://github.com/bschwind/png-decoder, which is no_std, but still does
    // not support custom allocators. We could use png or png-decoder as a
    // source for implementing our own, no_std, allocator-supporting PNG decoder
    // so that we move PNG decoding inside ph.
    fn read_png<A: Allocator>(&self, allocator: A, path: &str) -> Result<Image<A>, PlatformError>;
    fn write_file(&self, allocator: &Linear, path: &str, data: &[u8]) -> Result<(), PlatformError>;
    fn write_new_file(
        &self,
        allocator: &Linear,
        path: &str,
        data: &[u8],
    ) -> Result<(), PlatformError>;
    fn list_files<'a>(
        &self,
        allocator: &'a Linear,
        path: &str,
        exts: &[&str],
    ) -> Result<Vec<ListedFile<'a>, &'a Linear>, PlatformError>;
}
