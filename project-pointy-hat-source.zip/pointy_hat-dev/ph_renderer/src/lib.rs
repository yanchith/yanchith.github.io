#![no_std]
#![feature(generic_associated_types)]

use lfg_math::{Mat4, Rect};

// TODO(yan): Decide if we want to embrace glam types and our own repr(C) types
// for API, or continue using arrays. This might change some alignment stuff
// (SIMD), but also maybe it won't, because alignment in interface blocks is
// pretty weird too.

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Draw2DRectCommand {
    pub primitive_count: u32,
    pub texture_id: u64,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct Draw2DRectPrimitive {
    pub rect: Rect,
    pub texture_rect: Rect,
    pub color: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct Draw3DRectPrimitive {
    pub transform_matrix: Mat4,
    pub texture_rect: Rect,
    pub color_mul: u32,
    pub color_add: u32,
    // TODO(yan): @Cleanup @Speed After getting rid of push constants, many
    // things became better, but while Frame::draw_3d_rects_to_intermediate
    // looks innocuous from the outside, this is one place where things did't
    // fundamentally improve, and is currently a bit hacky. Unlike drawing
    // voxels, drawing 3D textured rects has to deal with transparency (so
    // sorting is not just an optimization, but a must) and texturing (so we can
    // not instance unless we put everything into a single atlas texture).
    //
    // To deal with both of these, WgpuFrame::draw_3d_rects first sorts and then
    // draws one by one to change textures, sort of like when it used push
    // constants.
    //
    // Moreover Draw3DRectPrimitive has the texture ID encoded in itself (and
    // not read on the shader).
    //
    // Frame::draw_2d_rects is similar in that it also needs to change textures,
    // but it does not require any sorting, so it can deal with the texture
    // changing by splitting the data into commands (containing texture ids and
    // draw counts) and the actual primitives, which allows it to hopefully draw
    // things in a slightly more batched manner.
    //
    // What can we do to improve things? Maybe we should have a texture atlas,
    // so we don't have to encode texture IDs in primitives?
    pub texture_id: u64,
}

// TODO(yan): @Speed @Memory At one point we'll need raymarching of sparse voxel
// octrees on the fragment shader (parallax raymarching):
// https://youtu.be/h81I8hR56vQ
//
// To a degree this is also what Teardown does, although it probably does it
// smarter.

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct Draw3DVoxelPrimitive {
    pub transform_matrix: Mat4,
    pub color: u32,
    pub _pad0: u32,
    pub _pad1: u32,
    pub _pad2: u32,
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct Draw3DDebugOutlinePrimitive {
    pub transform_matrix: Mat4,
    pub color: u32,
    pub _pad0: u32,
    pub _pad1: u32,
    pub _pad2: u32,
}

// This is repr(C) and layout-identical to guise::Command so that we can
// cast. Do not modify!
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct DrawUiCommand {
    pub scissor_rect: Rect,
    pub texture_id: u64,
    pub index_count: u32,
    pub _pad: u32,
}

// This is repr(C) and layout-identical to guise::Vertex so that we can cast. Do
// not modify!
#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct DrawUiVertex {
    pub position: [f32; 2],
    pub tex_coord: [f32; 2],
    pub color: u32,
}

#[repr(u32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ColorSpace {
    Linear = 0,
    Srgb = 1,
}

#[repr(u32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Sampler {
    Nearest = 0,
    Bilinear = 1,
}

#[repr(u32)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum RenderMode {
    Game = 0,
    DepthMap = 1,
}

pub trait Renderer {
    type Frame<'a>: Frame<'a>
    where
        Self: 'a;

    fn insert_texture_rgba8_unorm(
        &mut self,
        texture_id: u64,
        data: &[u8],
        width: u16,
        height: u16,
        color_space: ColorSpace,
        sampler: Sampler,
    );
    fn remove_texture(&mut self, texture_id: u64);
    fn begin_frame(
        &mut self,
        clear_color: [f32; 4],
        clear_depth: f32,
        view_matrix: Mat4,
        projection_matrix: Mat4,
        render_mode: RenderMode,
        ui_color_mul: u32,
    ) -> Option<Self::Frame<'_>>;
}

pub trait Frame<'a> {
    fn draw_2d_rects_to_intermediate(
        &mut self,
        commands: &[Draw2DRectCommand],
        primitives: &[Draw2DRectPrimitive],
    );
    fn draw_3d_rects_to_intermediate(&mut self, primitives: &[Draw3DRectPrimitive]);
    fn draw_3d_voxels_to_intermediate(&mut self, primitives: &[Draw3DVoxelPrimitive]);
    fn draw_3d_debug_outlines_to_intermediate(
        &mut self,
        primitives: &[Draw3DDebugOutlinePrimitive],
    );
    fn draw_ui_to_surface(
        &mut self,
        commands: &[DrawUiCommand],
        vertices: &[DrawUiVertex],
        indices: &[u32],
    );
    fn blit_intermediate_to_surface(&mut self);
    fn submit_and_present(self);
}
