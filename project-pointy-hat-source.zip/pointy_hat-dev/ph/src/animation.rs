use lfg_math::Vec3;

// TODO(yan): Change this into a bounded interpolation queue
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Vec3LinearInterpolation {
    src: Vec3,
    dst: Vec3,
    duration: f32,
    elapsed: f32,
}

impl Vec3LinearInterpolation {
    pub fn new(src: Vec3, dst: Vec3, duration: f32) -> Self {
        Self {
            src,
            dst,
            duration,
            elapsed: 0.0,
        }
    }

    pub fn update(&mut self, dtime: f32) {
        self.elapsed += dtime;
    }

    pub fn finished(&self) -> bool {
        self.elapsed > self.duration
    }

    pub fn value(&self) -> Vec3 {
        Vec3::lerp(
            self.src,
            self.dst,
            f32::min(1.0, self.elapsed / self.duration),
        )
    }
}
