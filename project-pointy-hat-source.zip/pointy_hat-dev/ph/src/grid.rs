use alloc::vec::Vec;
use core::alloc::Allocator;
use core::ops::{Index, IndexMut};

use lfg_common::cast_usize;
use lfg_math::{IVec3, UVec3};

// NB: derive(Clone) is fine, becuase it only derives clone for allocators that
// are also Clone, like Global, but not Linear.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Grid<T: Default, A: Allocator> {
    min: IVec3,
    max: IVec3,
    data: Vec<T, A>,
}

impl<T: Default, A: Allocator> Grid<T, A> {
    pub fn with_aabb_in(min: IVec3, max: IVec3, allocator: A) -> Self {
        assert!(min.x <= max.x);
        assert!(min.y <= max.y);
        assert!(min.z <= max.z);

        let capacity = capacity(min, max);
        let mut data = Vec::with_capacity_in(capacity, allocator);

        data.resize_with(capacity, T::default);

        Self { min, max, data }
    }

    pub fn min(&self) -> IVec3 {
        self.min
    }

    pub fn max(&self) -> IVec3 {
        self.max
    }

    #[allow(dead_code)]
    pub fn size(&self) -> UVec3 {
        size(self.min, self.max)
    }

    pub fn is_in_bounds(&self, position: IVec3) -> bool {
        position.cmpge(self.min).all() && position.cmple(self.max).all()
    }

    pub fn get(&self, position: IVec3) -> Option<&T> {
        if !self.is_in_bounds(position) {
            return None;
        }

        let index = self.position_to_idx(position);
        self.data.get(index)
    }

    pub fn get_mut(&mut self, position: IVec3) -> Option<&mut T> {
        if !self.is_in_bounds(position) {
            return None;
        }

        let index = self.position_to_idx(position);
        self.data.get_mut(index)
    }

    pub fn clear(&mut self) {
        let capacity = capacity(self.min, self.max);
        self.data.clear();
        self.data.resize_with(capacity, T::default);
    }

    fn position_to_idx(&self, position: IVec3) -> usize {
        debug_assert!(self.is_in_bounds(position));

        let p = position - self.min;
        let size = size(self.min, self.max);
        let positions_per_layer = cast_usize!(size.x) * cast_usize!(size.y);
        let positions_per_row = cast_usize!(size.x);

        cast_usize!(p.z) * positions_per_layer
            + cast_usize!(p.y) * positions_per_row
            + cast_usize!(p.x)
    }
}

impl<T: Default, A: Allocator> Index<IVec3> for Grid<T, A> {
    type Output = T;

    fn index(&self, position: IVec3) -> &Self::Output {
        self.get(position).unwrap()
    }
}

impl<T: Default, A: Allocator> IndexMut<IVec3> for Grid<T, A> {
    fn index_mut(&mut self, position: IVec3) -> &mut Self::Output {
        self.get_mut(position).unwrap()
    }
}

fn size(min: IVec3, max: IVec3) -> UVec3 {
    debug_assert!(min.x <= max.x);
    debug_assert!(min.y <= max.y);
    debug_assert!(min.z <= max.z);

    let size = max - min + IVec3::ONE;
    size.as_uvec3()
}

fn capacity(min: IVec3, max: IVec3) -> usize {
    let size = size(min, max);
    cast_usize!(size.x) * cast_usize!(size.y) * cast_usize!(size.z)
}
