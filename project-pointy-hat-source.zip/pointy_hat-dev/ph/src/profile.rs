// TODO(yan): Make this macro a bit smarter, e.g. take filename and line. Maybe
// even make it a proc macro to instrument functions.

macro_rules! profile_scope {
    ($name:expr) => {
        #[cfg(feature = "ph_profile")]
        let _span = tracy_client::span!($name);
    };
}
