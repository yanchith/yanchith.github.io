use core::alloc::Allocator;
use core::borrow::Borrow;
use core::convert::AsRef;
use core::fmt;
use core::ops::{BitOr, BitOrAssign, Deref};

use arrayvec::ArrayString;
use lfg_cereal::{self as cereal, Deserialize, Serialize};
use lfg_common::{const_hash_fnv1a, hash_fnv1a};

// This is a list of all generated assets to be used for asset ID collision
// check. Because we create asset IDs from file paths, we make up some synthetic
// file paths for these.

pub const PATH_IMPLICIT_LEVELSET: &str = "<common>/implicit_levelset.ph_levelset";
pub const PATH_MISSING_TEX: &str = "<common>/missing_tex.png";
pub const PATH_EDITOR_WHITE_TEX: &str = "<editor>/white_tex.png";
pub const PATH_EDITOR_FONT_ATLAS_TEX: &str = "<editor>/font_atlas_tex.png";
pub const PATH_GAME_FONT_ATLAS_TEX: &str = "<game>/font_atlas_tex.png";
pub const PATH_MISSING_VOLUME: &str = "<common>/missing_volume.xraw";

pub const NAME_IMPLICIT_LEVELSET: &str = "$implicit_levelset";
pub const NAME_MISSING_TEX: &str = "$missing_tex";
pub const NAME_EDITOR_WHITE_TEX: &str = "$editor_white_tex";
pub const NAME_EDITOR_FONT_ATLAS_TEX: &str = "$editor_font_atlas_tex";
pub const NAME_GAME_FONT_ATLAS_TEX: &str = "$game_font_atlas_tex";
pub const NAME_MISSING_VOLUME: &str = "$missing_volume";

pub const ID_IMPLICIT_LEVELSET: AssetId = AssetId::const_new(PATH_IMPLICIT_LEVELSET);
pub const ID_MISSING_TEX: AssetId = AssetId::const_new(PATH_MISSING_TEX);
pub const ID_EDITOR_WHITE_TEX: AssetId = AssetId::const_new(PATH_EDITOR_WHITE_TEX);
pub const ID_EDITOR_FONT_ATLAS_TEX: AssetId = AssetId::const_new(PATH_EDITOR_FONT_ATLAS_TEX);
pub const ID_GAME_FONT_ATLAS_TEX: AssetId = AssetId::const_new(PATH_GAME_FONT_ATLAS_TEX);
pub const ID_MISSING_VOLUME: AssetId = AssetId::const_new(PATH_MISSING_VOLUME);

pub static GENERATED_ASSETS: &[(AssetId, AssetType, &str, &str)] = &[
    (
        ID_IMPLICIT_LEVELSET,
        AssetType::Levelset,
        NAME_IMPLICIT_LEVELSET,
        PATH_IMPLICIT_LEVELSET,
    ),
    (
        ID_MISSING_TEX,
        AssetType::Texture,
        NAME_MISSING_TEX,
        PATH_MISSING_TEX,
    ),
    (
        ID_EDITOR_WHITE_TEX,
        AssetType::Texture,
        NAME_EDITOR_WHITE_TEX,
        PATH_EDITOR_WHITE_TEX,
    ),
    (
        ID_EDITOR_FONT_ATLAS_TEX,
        AssetType::Texture,
        NAME_EDITOR_FONT_ATLAS_TEX,
        PATH_EDITOR_FONT_ATLAS_TEX,
    ),
    (
        ID_GAME_FONT_ATLAS_TEX,
        AssetType::Texture,
        NAME_GAME_FONT_ATLAS_TEX,
        PATH_GAME_FONT_ATLAS_TEX,
    ),
    (
        ID_MISSING_VOLUME,
        AssetType::Volume,
        NAME_MISSING_VOLUME,
        PATH_MISSING_VOLUME,
    ),
];

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AssetReloadFlags(u32);

impl AssetReloadFlags {
    pub const WORLD: Self = Self(0x01);
    pub const LEVELSETS: Self = Self(0x02);
    pub const TEXTURES: Self = Self(0x04);
    pub const VOLUMES: Self = Self(0x08);
    // TODO(yan): SHADERS

    pub const NONE: Self = Self(0);
    pub const ALL: Self = Self::WORLD | Self::LEVELSETS | Self::TEXTURES | Self::VOLUMES;

    #[allow(dead_code)]
    pub fn bits(&self) -> u32 {
        self.0
    }

    #[allow(dead_code)]
    pub fn from_bits_truncate(bits: u32) -> Self {
        Self(Self::ALL.0 & bits)
    }

    pub fn intersects(&self, other: Self) -> bool {
        self.0 & other.0 != 0
    }
}

impl const BitOr for AssetReloadFlags {
    type Output = Self;

    fn bitor(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl BitOrAssign for AssetReloadFlags {
    fn bitor_assign(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

impl fmt::Display for AssetReloadFlags {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        let mut first = true;

        for (flag, text) in [
            (Self::WORLD, "WORLD"),
            (Self::LEVELSETS, "LEVELSETS"),
            (Self::TEXTURES, "TEXTURES"),
            (Self::VOLUMES, "VOLUMES"),
        ] {
            if self.intersects(flag) {
                if !first {
                    f.write_str(" | ")?;
                }

                f.write_str(text)?;

                first = false;
            }
        }

        if first {
            f.write_str("NONE")?;
        }

        Ok(())
    }
}

// TODO(yan): Consider type-safe wrappers around AssetId, such as:
//
// pub struct LevelId(AssetId);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AssetId(u64);

impl AssetId {
    pub fn new(path: &str) -> Self {
        let hash = hash_fnv1a(path.as_bytes());
        Self(hash)
    }

    pub const fn const_new(path: &str) -> Self {
        let hash = const_hash_fnv1a(path.as_bytes());
        Self(hash)
    }

    pub const fn from_raw(raw: u64) -> Self {
        Self(raw)
    }

    pub const fn into_raw(self) -> u64 {
        self.0
    }
}

impl fmt::Display for AssetId {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "0x{:016x}", self.0)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum AssetType {
    Level,
    Levelset,
    Texture,
    Volume,
    // TODO(yan): Shader
}

impl fmt::Display for AssetType {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Self::Level => f.write_str("Level"),
            Self::Levelset => f.write_str("Levelset"),
            Self::Texture => f.write_str("Texture"),
            Self::Volume => f.write_str("Volume"),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct AssetName(ArrayString<{ Self::CAP }>);

impl AssetName {
    pub const CAP: usize = 32;

    pub fn new(str: &str) -> Self {
        // TODO(yan): This is a meh moment waiting to happen. Don't have a
        // panicking constructor for asset name at all. Instead we should
        // probably truncate and the using code *should* be checking for
        // truncation, or even better, collisions.
        let buffer: ArrayString<{ Self::CAP }> =
            ArrayString::from(str).expect("Asset name is too long");
        Self(buffer)
    }

    #[allow(dead_code)]
    pub fn from_arraystring(arraystring: ArrayString<{ Self::CAP }>) -> Self {
        Self(arraystring)
    }

    #[allow(dead_code)]
    pub fn from_ascii(ascii: &[u8; Self::CAP]) -> Self {
        assert!(ascii.is_ascii(), "Asset name is not ascii");
        let buffer: ArrayString<{ Self::CAP }> =
            ArrayString::from_byte_string(ascii).expect("Asset name is too long");
        Self(buffer)
    }
}

impl Borrow<str> for AssetName {
    fn borrow(&self) -> &str {
        self.0.borrow()
    }
}

impl AsRef<str> for AssetName {
    fn as_ref(&self) -> &str {
        self.0.as_ref()
    }
}

impl Deref for AssetName {
    type Target = str;

    fn deref(&self) -> &str {
        self.0.deref()
    }
}

impl fmt::Display for AssetName {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}", self.0)
    }
}

impl Serialize for AssetName {
    fn serialize<A: Allocator>(&self, f: &mut cereal::Formatter<A>) {
        self.0.serialize(f);
    }
}

impl<A: Allocator + Clone> Deserialize<A> for AssetName {
    fn deserialize<NA: Allocator + Clone>(
        node: &cereal::Node<NA>,
        allocator: A,
    ) -> Result<AssetName, cereal::DeserializeError> {
        let buffer = ArrayString::<{ Self::CAP }>::deserialize(node, allocator)?;
        Ok(Self(buffer))
    }
}

// TODO(yan): Experiment with something like the AssetPath struct below, so we
// don't have to reconstruct paths by hand. The type can also be small enough to
// be copyable.
//
// #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
// pub struct AssetPath {
//     ty: AssetType,
//     name: AssetName,
// }
