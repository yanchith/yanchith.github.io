use alloc::vec::Vec;
use core::cmp::Ordering;
use core::fmt;
use core::ops::{BitAnd, BitAndAssign, BitOr, BitOrAssign};
use core::time::Duration;

use arrayvec::ArrayVec;
use lfg_alloc::Linear;
use lfg_math::{cmp_f32, color_u32, ivec2, ivec3, IRect, IVec2, IVec3};

use crate::animation::Vec3LinearInterpolation;
use crate::asset::{self, AssetId};
use crate::grid::Grid;
use crate::history::{History, HistoryChange, HistoryError};
use crate::idmap::{Id, IdMap};

pub const POSITION_INTERPOLATION_DURATION_MOVE: Duration = Duration::from_millis(66);
pub const POSITION_INTERPOLATION_DURATION_FALL_BASE: Duration = Duration::from_millis(33);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Action {
    // Wait is also implicitly ran once, when the level starts, so all the
    // systems can initialize properly.
    Wait,
    Move { bearing: Bearing },
    Turn { turn: Turn },
    Interact,
    SwitchCharacter,
}

// Our game space is right-handed, Z-up. Bearing is defined on the XY plane.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Bearing {
    North,
    South,
    East,
    West,
}

impl Bearing {
    /// Finds [`Bearing`] from a directional vector. Succeeds, if there is a
    /// dominant axis-aligned direction present in the vector.
    pub fn try_from_ivec2(direction: IVec2) -> Option<Bearing> {
        let xabs = i32::abs(direction.x);
        let yabs = i32::abs(direction.y);

        match (direction.x, direction.y) {
            (_, y) if y > 0 && y > xabs => Some(Self::North),
            (_, y) if y < 0 && y < -xabs => Some(Self::South),
            (x, _) if x > 0 && x > yabs => Some(Self::East),
            (x, _) if x < 0 && x < -yabs => Some(Self::West),
            _ => None,
        }
    }

    /// Finds [`Bearing`] from a directional vector. Succeeds, if there is a
    /// dominant axis-aligned direction present in the vector. Ignores Z.
    pub fn try_from_ivec3(direction: IVec3) -> Option<Bearing> {
        Self::try_from_ivec2(direction.truncate())
    }

    /// Like [`Self::try_from_ivec2`], but only succeeds if other components
    /// of the vector are zero.
    pub fn try_from_ivec2_strict(direction: IVec2) -> Option<Bearing> {
        match (direction.x, direction.y) {
            (0, y) if y > 0 => Some(Self::North),
            (0, y) if y < 0 => Some(Self::South),
            (x, 0) if x > 0 => Some(Self::East),
            (x, 0) if x < 0 => Some(Self::West),
            _ => None,
        }
    }

    /// Like [`Self::try_from_ivec3`], but only succeeds if other components
    /// of the vector are zero. Ignores Z.
    pub fn try_from_ivec3_strict(direction: IVec3) -> Option<Bearing> {
        Self::try_from_ivec2_strict(direction.truncate())
    }

    pub fn with_turn(&self, turn: Turn) -> Self {
        match (self, turn) {
            (Self::North, Turn::Left) => Self::West,
            (Self::North, Turn::Right) => Self::East,
            (Self::South, Turn::Left) => Self::East,
            (Self::South, Turn::Right) => Self::West,
            (Self::East, Turn::Left) => Self::North,
            (Self::East, Turn::Right) => Self::South,
            (Self::West, Turn::Left) => Self::South,
            (Self::West, Turn::Right) => Self::North,
        }
    }

    #[allow(dead_code)]
    pub fn opposite(&self) -> Self {
        match self {
            Self::North => Self::South,
            Self::South => Self::North,
            Self::East => Self::West,
            Self::West => Self::East,
        }
    }

    pub fn turn_count_between(&self, other: Self) -> u8 {
        match (self, other) {
            (Self::North, Self::North) => 0,
            (Self::North, Self::South) => 2,
            (Self::North, Self::East) => 1,
            (Self::North, Self::West) => 1,
            (Self::South, Self::North) => 2,
            (Self::South, Self::South) => 0,
            (Self::South, Self::East) => 1,
            (Self::South, Self::West) => 1,
            (Self::East, Self::North) => 1,
            (Self::East, Self::South) => 1,
            (Self::East, Self::East) => 0,
            (Self::East, Self::West) => 2,
            (Self::West, Self::North) => 1,
            (Self::West, Self::South) => 1,
            (Self::West, Self::East) => 2,
            (Self::West, Self::West) => 0,
        }
    }
}

impl From<Bearing> for i32 {
    fn from(bearing: Bearing) -> i32 {
        bearing as i32
    }
}

#[derive(Debug)]
pub struct BearingFromI32Error;

impl TryFrom<i32> for Bearing {
    type Error = BearingFromI32Error;

    fn try_from(index: i32) -> Result<Self, Self::Error> {
        match index {
            0 => Ok(Bearing::North),
            1 => Ok(Bearing::South),
            2 => Ok(Bearing::East),
            3 => Ok(Bearing::West),
            _ => Err(BearingFromI32Error),
        }
    }
}

impl From<Bearing> for IVec2 {
    fn from(bearing: Bearing) -> Self {
        match bearing {
            Bearing::North => ivec2(0, 1),
            Bearing::South => ivec2(0, -1),
            Bearing::East => ivec2(1, 0),
            Bearing::West => ivec2(-1, 0),
        }
    }
}

impl From<Bearing> for IVec3 {
    fn from(bearing: Bearing) -> Self {
        match bearing {
            Bearing::North => ivec3(0, 1, 0),
            Bearing::South => ivec3(0, -1, 0),
            Bearing::East => ivec3(1, 0, 0),
            Bearing::West => ivec3(-1, 0, 0),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Turn {
    Left,
    Right,
}

// This is actually Option<Bearing>, but for some reason,
//
//  impl From<Option<Bearing>> for IVec2
//
// is not legal even under the new relaxed coherence rules, so we defined our
// own type.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Movement {
    None,
    Bearing(Bearing),
}

#[derive(Debug)]
pub struct BearingFromMovementError;

impl From<Bearing> for Movement {
    fn from(bearing: Bearing) -> Self {
        Self::Bearing(bearing)
    }
}

impl From<Movement> for IVec3 {
    fn from(movement: Movement) -> Self {
        match movement {
            Movement::None => IVec3::ZERO,
            Movement::Bearing(bearing) => IVec3::from(bearing),
        }
    }
}

impl From<Movement> for IVec2 {
    fn from(movement: Movement) -> Self {
        match movement {
            Movement::None => IVec2::ZERO,
            Movement::Bearing(bearing) => IVec2::from(bearing),
        }
    }
}

impl TryFrom<Movement> for Bearing {
    type Error = BearingFromMovementError;

    fn try_from(movement: Movement) -> Result<Self, Self::Error> {
        match movement {
            Movement::None => Err(BearingFromMovementError),
            Movement::Bearing(bearing) => Ok(bearing),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct DeathCauses(u32);

impl DeathCauses {
    pub const DROWNED: Self = Self(0x01);
    pub const DROPPED: Self = Self(0x02);
    pub const SWORDED: Self = Self(0x04);
    pub const ARROWED: Self = Self(0x08);

    pub const NONE: Self = Self(0);
    pub const ALL: Self = Self::DROWNED | Self::DROPPED | Self::SWORDED | Self::ARROWED;

    #[allow(dead_code)]
    pub fn bits(&self) -> u32 {
        self.0
    }

    #[allow(dead_code)]
    pub fn from_bits_truncate(bits: u32) -> Self {
        Self(Self::ALL.0 & bits)
    }

    #[allow(dead_code)]
    pub fn intersects(&self, other: Self) -> bool {
        self.0 & other.0 != 0
    }
}

impl const BitOr for DeathCauses {
    type Output = Self;

    fn bitor(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl BitOrAssign for DeathCauses {
    fn bitor_assign(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Item {
    Key,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum UnaryBooleanOp {
    Identity,
    Not,
}

// TODO(yan): @Derive Generate enum dropdown interop associated functions:
// values(), names(), from_index() and index(). This could be the beginning of
// our #[derive(UiDesc, Ui)].
impl UnaryBooleanOp {
    pub const fn values() -> &'static [UnaryBooleanOp] {
        &[Self::Identity, Self::Not]
    }

    pub const fn names() -> &'static [&'static str] {
        &["Identity", "Not"]
    }

    pub const fn from_index(index: usize) -> Self {
        Self::values()[index]
    }

    pub const fn index(&self) -> usize {
        match self {
            Self::Identity => 0,
            Self::Not => 1,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum BinaryBooleanOp {
    And,
    Or,
    Xor,
}

// TODO(yan): @Derive Generate enum dropdown interop associated functions:
// values(), names(), from_index() and index(). This could be the beginning of
// our #[derive(UiDesc, Ui)].
impl BinaryBooleanOp {
    pub const fn values() -> &'static [BinaryBooleanOp] {
        &[Self::And, Self::Or, Self::Xor]
    }

    pub const fn names() -> &'static [&'static str] {
        &["And", "Or", "Xor"]
    }

    pub const fn from_index(index: usize) -> Self {
        Self::values()[index]
    }

    pub const fn index(&self) -> usize {
        match self {
            Self::And => 0,
            Self::Or => 1,
            Self::Xor => 2,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Support {
    Unknown,
    Innate,
    Levitate,
    LevelBounds,
    Entity(Id),
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct StatusEffects {
    // Zero means the effect is not present. Nonzero numbers mean number of
    // turns until the status effect disappears.
    pub levitate: u8,
}

impl StatusEffects {
    pub const NONE: Self = Self { levitate: 0 };
}

// TODO(yan): Replace with animation system. For each animation have an
// animation id for querying a range into the animation frames stored in the
// animation system.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Animation {
    pub texture_id: AssetId,
    pub frame: IRect,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct VolumeAnimationDirections(u8);

impl VolumeAnimationDirections {
    pub const OUTWARD: Self = Self(0x01);
    pub const INWARD: Self = Self(0x02);

    #[allow(dead_code)]
    pub const NONE: Self = Self(0);
    pub const ALL: Self = Self::OUTWARD | Self::INWARD;

    pub fn bits(&self) -> u8 {
        self.0
    }

    pub fn from_bits_truncate(bits: u8) -> Self {
        Self(Self::ALL.0 & bits)
    }

    pub fn intersects(&self, other: Self) -> bool {
        self.0 & other.0 != 0
    }
}

impl const BitOr for VolumeAnimationDirections {
    type Output = Self;

    fn bitor(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl BitOrAssign for VolumeAnimationDirections {
    fn bitor_assign(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct VolumeAnimation {
    // Animations not rendered if None. This can be used to achieve drawing
    // floor-only, etc. If an animation is missing, it should be
    // Some(missing_anim), instead of None here.
    pub top: Option<Animation>,
    pub top_directions: VolumeAnimationDirections,
    pub top_offset: f32,
    pub sides: Option<Animation>,
    pub sides_directions: VolumeAnimationDirections,
    pub sides_offset: f32,
    pub bottom: Option<Animation>,
    pub bottom_directions: VolumeAnimationDirections,
    pub bottom_offset: f32,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum RunningAnimations {
    Prop(Animation),
    Volume(VolumeAnimation),
}

// TODO(yan): @Entitypocalypse Adding a new entity type currently results in a
// large amount of work (search for tag @AddEntity and @AddEntity @Derive). Some
// of it is gameplay related and likely necessary, and some just seems
// tedious. To improve the situation, we could:
//
// 1) Aim to automate whatever we can - deriving EntityTypes (EntityTypeFlags)
//    from EntityType, deriving editor UI based on the entity definition, ...
//
// 2) Consider removing some of the abstractions we currenly have. We have
//    Entity, EntityInit, and EntityInitSer. Do we really need all of these? Can
//    we e.g. automatically generate the flattened/serializable structs from the
//    engine structs, as well as the flattening and reviving code?
//
// 3) Could we automatically generate a subset of migrations similarly how
//    Thekla does it in Sokoban?

// TODO(yan): Consider not storing this in entity, but instead deriving it from
// entity data. This way we can still have an entity type (and entity type
// flags), but only one source of truth.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum EntityType {
    Wizard,
    Exit,
    Water,
    Ground,
    Tree,
    WoodenCrate,
    IronCrate,
    Key,
    KeyGate,
    TranspositionStone,
    SummoningStone,
    FamiliarCat,
    SkellyWarrior,
    SkellyArcher,
    PressurePlate,
    PressurePlateGate,
}

impl EntityType {
    pub const fn to_entity_types(self) -> EntityTypes {
        // Note: @AddEntity @Derive
        match self {
            Self::Wizard => EntityTypes::WIZARD,
            Self::Exit => EntityTypes::EXIT,
            Self::Water => EntityTypes::WATER,
            Self::Ground => EntityTypes::GROUND,
            Self::Tree => EntityTypes::TREE,
            Self::WoodenCrate => EntityTypes::WOODEN_CRATE,
            Self::IronCrate => EntityTypes::IRON_CRATE,
            Self::Key => EntityTypes::KEY,
            Self::KeyGate => EntityTypes::KEY_GATE,
            Self::TranspositionStone => EntityTypes::TRANSPOSITION_STONE,
            Self::SummoningStone => EntityTypes::SUMMONING_STONE,
            Self::FamiliarCat => EntityTypes::FAMILIAR_CAT,
            Self::SkellyWarrior => EntityTypes::SKELLY_WARRIOR,
            Self::SkellyArcher => EntityTypes::SKELLY_ARCHER,
            Self::PressurePlate => EntityTypes::PRESSURE_PLATE,
            Self::PressurePlateGate => EntityTypes::PRESSURE_PLATE_GATE,
        }
    }
}

// TODO(yan): @Derive Generate enum dropdown interop associated functions:
// values(), names(), from_index() and index(). This could be the beginning of
// our #[derive(UiDesc, Ui)].
impl EntityType {
    pub const fn values() -> &'static [EntityType] {
        // Note: @AddEntity @Derive
        &[
            Self::Wizard,
            Self::Exit,
            Self::Water,
            Self::Ground,
            Self::Tree,
            Self::WoodenCrate,
            Self::IronCrate,
            Self::Key,
            Self::KeyGate,
            Self::TranspositionStone,
            Self::SummoningStone,
            Self::FamiliarCat,
            Self::SkellyWarrior,
            Self::SkellyArcher,
            Self::PressurePlate,
            Self::PressurePlateGate,
        ]
    }

    pub const fn names() -> &'static [&'static str] {
        // Note: @AddEntity @Derive
        &[
            "Wizard",
            "Exit",
            "Water",
            "Ground",
            "Tree",
            "WoodenCrate",
            "IronCrate",
            "Key",
            "KeyGate",
            "TranspositionStone",
            "SummoningStone",
            "FamiliarCat",
            "SkellyWarrior",
            "SkellyArcher",
            "PressurePlate",
            "PressurePlateGate",
        ]
    }

    pub const fn from_index(index: usize) -> Self {
        Self::values()[index]
    }

    pub const fn index(&self) -> usize {
        match self {
            Self::Wizard => 0,
            Self::Exit => 1,
            Self::Water => 2,
            Self::Ground => 3,
            Self::Tree => 4,
            Self::WoodenCrate => 5,
            Self::IronCrate => 6,
            Self::Key => 7,
            Self::KeyGate => 8,
            Self::TranspositionStone => 9,
            Self::SummoningStone => 10,
            Self::FamiliarCat => 11,
            Self::SkellyWarrior => 12,
            Self::SkellyArcher => 13,
            Self::PressurePlate => 14,
            Self::PressurePlateGate => 15,
        }
    }
}

impl fmt::Display for EntityType {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str(Self::names()[self.index()])
    }
}

// TODO(yan): Majority of this init data is animations and it might be a lot of
// data that's the same for every entity of this type, bloating the level
// assets. Think about introducing entity prototypes that would define the init
// data and each entity could choose to override the prototype or inherit from
// it. In runtime, this would still get blown out for now.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum EntityDataInit {
    Wizard(WizardEntityDataInit),
    Exit(ExitEntityDataInit),
    Water(WaterEntityDataInit),
    Ground(GroundEntityDataInit),
    Tree(TreeEntityDataInit),
    WoodenCrate(WoodenCrateEntityDataInit),
    IronCrate(IronCrateEntityDataInit),
    Key(KeyEntityDataInit),
    KeyGate(KeyGateEntityDataInit),
    TranspositionStone(TranspositionStoneEntityDataInit),
    SummoningStone(SummoningStoneEntityDataInit),
    FamiliarCat(FamiliarCatEntityDataInit),
    SkellyWarrior(SkellyWarriorEntityDataInit),
    SkellyArcher(SkellyArcherEntityDataInit),
    PressurePlate(PressurePlateEntityDataInit),
    PressurePlateGate(PressurePlateGateEntityDataInit),
}

impl EntityDataInit {
    pub fn from_entity_init(entity_init: &EntityInit) -> &Self {
        // Note: @AddEntity @Derive
        match (entity_init.ty, &entity_init.data) {
            (EntityType::Wizard, EntityDataInit::Wizard(_)) => &entity_init.data,
            (EntityType::Exit, EntityDataInit::Exit(_)) => &entity_init.data,
            (EntityType::Water, EntityDataInit::Water(_)) => &entity_init.data,
            (EntityType::Ground, EntityDataInit::Ground(_)) => &entity_init.data,
            (EntityType::Tree, EntityDataInit::Tree(_)) => &entity_init.data,
            (EntityType::WoodenCrate, EntityDataInit::WoodenCrate(_)) => &entity_init.data,
            (EntityType::IronCrate, EntityDataInit::IronCrate(_)) => &entity_init.data,
            (EntityType::Key, EntityDataInit::Key(_)) => &entity_init.data,
            (EntityType::KeyGate, EntityDataInit::KeyGate(_)) => &entity_init.data,
            (EntityType::TranspositionStone, EntityDataInit::TranspositionStone(_)) => {
                &entity_init.data
            }
            (EntityType::SummoningStone, EntityDataInit::SummoningStone(_)) => &entity_init.data,
            (EntityType::FamiliarCat, EntityDataInit::FamiliarCat(_)) => &entity_init.data,
            (EntityType::SkellyWarrior, EntityDataInit::SkellyWarrior(_)) => &entity_init.data,
            (EntityType::SkellyArcher, EntityDataInit::SkellyArcher(_)) => &entity_init.data,
            (EntityType::PressurePlate, EntityDataInit::PressurePlate(_)) => &entity_init.data,
            (EntityType::PressurePlateGate, EntityDataInit::PressurePlateGate(_)) => {
                &entity_init.data
            }
            // TODO(yan): Consider not panicking and returning default data instead.
            _ => panic!("Unmatched entity type and data"),
        }
    }

    pub fn from_entity_init_mut(entity_init: &mut EntityInit) -> &mut Self {
        // Note: @AddEntity @Derive
        match (entity_init.ty, &entity_init.data) {
            (EntityType::Wizard, EntityDataInit::Wizard(_)) => &mut entity_init.data,
            (EntityType::Exit, EntityDataInit::Exit(_)) => &mut entity_init.data,
            (EntityType::Water, EntityDataInit::Water(_)) => &mut entity_init.data,
            (EntityType::Ground, EntityDataInit::Ground(_)) => &mut entity_init.data,
            (EntityType::Tree, EntityDataInit::Tree(_)) => &mut entity_init.data,
            (EntityType::WoodenCrate, EntityDataInit::WoodenCrate(_)) => &mut entity_init.data,
            (EntityType::IronCrate, EntityDataInit::IronCrate(_)) => &mut entity_init.data,
            (EntityType::Key, EntityDataInit::Key(_)) => &mut entity_init.data,
            (EntityType::KeyGate, EntityDataInit::KeyGate(_)) => &mut entity_init.data,
            (EntityType::TranspositionStone, EntityDataInit::TranspositionStone(_)) => {
                &mut entity_init.data
            }
            (EntityType::SummoningStone, EntityDataInit::SummoningStone(_)) => {
                &mut entity_init.data
            }
            (EntityType::FamiliarCat, EntityDataInit::FamiliarCat(_)) => &mut entity_init.data,
            (EntityType::SkellyWarrior, EntityDataInit::SkellyWarrior(_)) => &mut entity_init.data,
            (EntityType::SkellyArcher, EntityDataInit::SkellyArcher(_)) => &mut entity_init.data,
            (EntityType::PressurePlate, EntityDataInit::PressurePlate(_)) => &mut entity_init.data,
            (EntityType::PressurePlateGate, EntityDataInit::PressurePlateGate(_)) => {
                &mut entity_init.data
            }
            // TODO(yan): Consider not panicking and returning default data instead.
            _ => panic!("Unmatched entity type and data"),
        }
    }

    pub fn default_for_entity_ty(entity_ty: EntityType) -> Self {
        // Note: @AddEntity @Derive
        match entity_ty {
            EntityType::Wizard => Self::Wizard(WizardEntityDataInit {
                anim_front: None,
                anim_back: None,
                anim_left: None,
                anim_right: None,
            }),
            EntityType::Exit => Self::Exit(ExitEntityDataInit { anim: None }),
            EntityType::Water => Self::Water(WaterEntityDataInit { anim: None }),
            EntityType::Ground => Self::Ground(GroundEntityDataInit { anim: None }),
            EntityType::Tree => Self::Tree(TreeEntityDataInit { anim: None }),
            EntityType::WoodenCrate => Self::WoodenCrate(WoodenCrateEntityDataInit { anim: None }),
            EntityType::IronCrate => Self::IronCrate(IronCrateEntityDataInit { anim: None }),
            EntityType::Key => Self::Key(KeyEntityDataInit { anim: None }),
            EntityType::KeyGate => Self::KeyGate(KeyGateEntityDataInit {
                open: false,
                anim: None,
                anim_open: None,
            }),
            EntityType::TranspositionStone => {
                Self::TranspositionStone(TranspositionStoneEntityDataInit {
                    anim: None,
                    anim_active: None,
                })
            }
            EntityType::SummoningStone => Self::SummoningStone(SummoningStoneEntityDataInit {
                anim: None,
                anim_active: None,
            }),
            EntityType::FamiliarCat => Self::FamiliarCat(FamiliarCatEntityDataInit {
                anim_front: None,
                anim_back: None,
                anim_left: None,
                anim_right: None,
            }),
            EntityType::SkellyWarrior => Self::SkellyWarrior(SkellyWarriorEntityDataInit {
                anim_front: None,
                anim_back: None,
                anim_left: None,
                anim_right: None,
                anim_aggro_front: None,
                anim_aggro_back: None,
                anim_aggro_left: None,
                anim_aggro_right: None,
            }),
            EntityType::SkellyArcher => Self::SkellyArcher(SkellyArcherEntityDataInit {
                anim_front: None,
                anim_back: None,
                anim_left: None,
                anim_right: None,
                anim_aggro_front: None,
                anim_aggro_back: None,
                anim_aggro_left: None,
                anim_aggro_right: None,
            }),
            EntityType::PressurePlate => Self::PressurePlate(PressurePlateEntityDataInit {
                anim: None,
                anim_pressed: None,
            }),
            EntityType::PressurePlateGate => {
                Self::PressurePlateGate(PressurePlateGateEntityDataInit {
                    anim: None,
                    anim_open: None,
                    open_if_active: [None; 4],
                    open_if_active_op: BinaryBooleanOp::And,
                })
            }
        }
    }
}

// TODO(yan): Consider having something like this struct:
//
// pub struct EntityAnimations {
//     Prop(Animation),
//     OrientedProp {
//         front: Animation,
//         back: Animation,
//         left: Animation,
//         right: Animation,
//     },
//     Volume(VolumeAnimation),
// }
//
// This way we could edit everything in the editor. An entity could still have
// multiple of these for each state (and state transition) like it does
// now. Another advantage is cutting boilerplate in serialization, migration,
// etc.
//
// The disadvantage is that some parts of rendering are not configurable from
// editor, and we'd have to make them so or accept that rendering behaves
// differently for some entity types because that's how it is hardcoded in the
// engine. At the moment, this is merging (not drawing walls between) entities
// of the same type. Only WATER and GROUND are merged, and they both have
// specific rules in code to do that which might not be worth changing to be
// configurable.

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WizardEntityDataInit {
    pub anim_front: Option<Animation>,
    pub anim_back: Option<Animation>,
    pub anim_left: Option<Animation>,
    pub anim_right: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ExitEntityDataInit {
    pub anim: Option<VolumeAnimation>,
    // TODO(yan): Add anim_active.
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WaterEntityDataInit {
    pub anim: Option<VolumeAnimation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct GroundEntityDataInit {
    pub anim: Option<VolumeAnimation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TreeEntityDataInit {
    pub anim: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WoodenCrateEntityDataInit {
    pub anim: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct IronCrateEntityDataInit {
    pub anim: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct KeyEntityDataInit {
    pub anim: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct KeyGateEntityDataInit {
    pub open: bool,
    pub anim: Option<VolumeAnimation>,
    pub anim_open: Option<VolumeAnimation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TranspositionStoneEntityDataInit {
    pub anim: Option<Animation>,
    // TODO(yan): Get rid of anim_active from all the stones, because it they
    // are a major pain in our asset/animation system. Instead highlight them
    // via an animated HSV/HSL to test out how that looks when we program it.
    pub anim_active: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SummoningStoneEntityDataInit {
    pub anim: Option<Animation>,
    pub anim_active: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FamiliarCatEntityDataInit {
    pub anim_front: Option<Animation>,
    pub anim_back: Option<Animation>,
    pub anim_left: Option<Animation>,
    pub anim_right: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SkellyWarriorEntityDataInit {
    pub anim_front: Option<Animation>,
    pub anim_back: Option<Animation>,
    pub anim_left: Option<Animation>,
    pub anim_right: Option<Animation>,
    pub anim_aggro_front: Option<Animation>,
    pub anim_aggro_back: Option<Animation>,
    pub anim_aggro_left: Option<Animation>,
    pub anim_aggro_right: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SkellyArcherEntityDataInit {
    pub anim_front: Option<Animation>,
    pub anim_back: Option<Animation>,
    pub anim_left: Option<Animation>,
    pub anim_right: Option<Animation>,
    pub anim_aggro_front: Option<Animation>,
    pub anim_aggro_back: Option<Animation>,
    pub anim_aggro_left: Option<Animation>,
    pub anim_aggro_right: Option<Animation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PressurePlateEntityDataInit {
    pub anim: Option<VolumeAnimation>,
    pub anim_pressed: Option<VolumeAnimation>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PressurePlateGateEntityDataInit {
    pub anim: Option<VolumeAnimation>,
    pub anim_open: Option<VolumeAnimation>,
    pub open_if_active: [Option<(UnaryBooleanOp, Id)>; 4],
    pub open_if_active_op: BinaryBooleanOp,
}

// TODO(yan): Consider introducing prototypes. Currently animations (but soon
// maybe other things) are the same across all entities of the same type. We
// currently solve this with copying all the things from a source entity to all
// other entities in all other levels. What we could have instead is an entity
// prototype asset (e.g. wizard.ph_proto). Each entity would have an asset ID of
// its prototype and take its data from there. Should we allow multiple
// prototypes per entity type? Not doing this allows us to not store the
// prototype ID on the entity, and we'd only need this if we want multiple
// initial configurations of an entity's data (not counting transient data).
//
// TODO(yan): Consider merging this with Entity (and entity data init with
// entity data). Transient data (runtime and derived only, not persistent
// between frames), could be inside a substruct (e.g. EntityTransient or
// SkellyWarrior[EntityData]Transient). These would not be serialized (either
// omitted during flattening, or simply skipped by the serialization system, if
// we decide to get rid of flattening too).
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct EntityInit {
    // TODO(yan): Store Id here, so that entities can refer to themselves. Might
    // also need to update IdMap with functionality to insert trusted data,
    // where the user provides the generational indices, or at least the index
    // part of the generational index.
    pub ty: EntityType,
    pub data: EntityDataInit,

    pub position: IVec3,
    pub bearing: Bearing,

    pub volume_idle: AssetId,
}

// TODO(yan): EntityData currently copies all fields from
// EntityDataInit. Consider storing EntityDataInit in the entity and EntityData
// being an extension of EntityDataInit and only having runtime/transient
// fields.
#[derive(Debug, Clone, Copy, PartialEq)]
pub enum EntityData {
    Wizard(WizardEntityData),
    Exit(ExitEntityData),
    Water(WaterEntityData),
    Ground(GroundEntityData),
    Tree(TreeEntityData),
    WoodenCrate(WoodenCrateEntityData),
    IronCrate(IronCrateEntityData),
    Key(KeyEntityData),
    KeyGate(KeyGateEntityData),
    TranspositionStone(TranspositionStoneEntityData),
    SummoningStone(SummoningStoneEntityData),
    FamiliarCat(FamiliarCatEntityData),
    SkellyWarrior(SkellyWarriorEntityData),
    SkellyArcher(SkellyArcherEntityData),
    PressurePlate(PressurePlateEntityData),
    PressurePlateGate(PressurePlateGateEntityData),
}

impl EntityData {
    pub fn unwrap_wizard(&self) -> &WizardEntityData {
        match self {
            Self::Wizard(data) => data,
            _ => panic!(),
        }
    }

    pub fn unwrap_wizard_mut(&mut self) -> &mut WizardEntityData {
        match self {
            Self::Wizard(data) => data,
            _ => panic!(),
        }
    }

    pub fn unwrap_gate(&self) -> &KeyGateEntityData {
        match self {
            Self::KeyGate(data) => data,
            _ => panic!(),
        }
    }

    pub fn unwrap_skelly_warrior_mut(&mut self) -> &mut SkellyWarriorEntityData {
        match self {
            Self::SkellyWarrior(data) => data,
            _ => panic!(),
        }
    }

    pub fn unwrap_skelly_archer_mut(&mut self) -> &mut SkellyArcherEntityData {
        match self {
            Self::SkellyArcher(data) => data,
            _ => panic!(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WizardEntityData {
    //
    // Init data
    //
    pub anim_front: Animation,
    pub anim_back: Animation,
    pub anim_left: Animation,
    pub anim_right: Animation,
    //
    // Runtime data
    //
    pub controlled: bool,
    pub inventory: [Option<Item>; 6],
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct ExitEntityData {
    //
    // Init data
    //
    pub anim: VolumeAnimation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WaterEntityData {
    //
    // Init data
    //
    pub anim: VolumeAnimation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct GroundEntityData {
    //
    // Init data
    //
    pub anim: VolumeAnimation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TreeEntityData {
    //
    // Init data
    //
    pub anim: Animation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WoodenCrateEntityData {
    //
    // Init data
    //
    pub anim: Animation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct IronCrateEntityData {
    //
    // Init data
    //
    pub anim: Animation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct KeyEntityData {
    //
    // Init data
    //
    pub anim: Animation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct KeyGateEntityData {
    //
    // Init data
    //
    pub open: bool,
    pub anim: VolumeAnimation,
    pub anim_open: VolumeAnimation,
    //
    // Runtime data
    //
    // N/A
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct TranspositionStoneEntityData {
    //
    // Init data
    //
    pub anim: Animation,
    pub anim_active: Animation,
    //
    // Runtime data
    //
    pub active: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SummoningStoneEntityData {
    //
    // Init data
    //
    pub anim: Animation,
    pub anim_active: Animation,
    //
    // Runtime data
    //
    pub active: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct FamiliarCatEntityData {
    //
    // Init data
    //
    pub anim_front: Animation,
    pub anim_back: Animation,
    pub anim_left: Animation,
    pub anim_right: Animation,
    //
    // Runtime data
    //
    pub controlled: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SkellyWarriorEntityData {
    //
    // Init data
    //
    pub anim_front: Animation,
    pub anim_back: Animation,
    pub anim_left: Animation,
    pub anim_right: Animation,
    pub anim_aggro_front: Animation,
    pub anim_aggro_back: Animation,
    pub anim_aggro_left: Animation,
    pub anim_aggro_right: Animation,
    //
    // Runtime data
    //
    pub aggro_id: Option<Id>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct SkellyArcherEntityData {
    //
    // Init data
    //
    pub anim_front: Animation,
    pub anim_back: Animation,
    pub anim_left: Animation,
    pub anim_right: Animation,
    pub anim_aggro_front: Animation,
    pub anim_aggro_back: Animation,
    pub anim_aggro_left: Animation,
    pub anim_aggro_right: Animation,
    //
    // Runtime data
    //
    pub aggro_id: Option<Id>,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PressurePlateEntityData {
    //
    // Init data
    //
    pub anim: VolumeAnimation,
    pub anim_pressed: VolumeAnimation,
    //
    // Runtime data
    //
    pub pressed: bool,
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct PressurePlateGateEntityData {
    //
    // Init data
    //
    pub anim: VolumeAnimation,
    pub anim_open: VolumeAnimation,
    pub open_if_active: [Option<(UnaryBooleanOp, Id)>; 4],
    pub open_if_active_op: BinaryBooleanOp,
    //
    // Runtime data
    //
    pub open: bool,
}

// TODO(yan): Make a #[flags] proc macro that rewrites a repr(int) enum into
// a flags struct like we now write manually, similar to C# Flags attribute.
//
// Enum variants become pub associated constants, and the enum itself becomes a
// newtype struct around the int type.
//
// #[flags] would have an optional parameter to determine, whether the original
// enum should be preserved also, and if so, what should the name of the
// generated type be: #[flags(u32, name("EntityTypes"))] or #[flags(u32, "EntityTypes")].
//
// Example
//
// #[flags(i64)] <- Generates (and/or validates?) #[repr(i64)] for the enum.
// pub enum EntityTypes {
//     Wizard   = 0x01, <- Literal variants are validated by the macro so they don't overlap
//     Exit     = 0x02,
//     Key      = 0x04,
//     KeyGate     = 0x08,
//     Familiar = 0x10,
//
//     AllControllable = Wizard | Familiar, <- Do we want composite variants?
//                                             They don't make sense in the enum, only the flags.
//                                             Maybe we could have #[flags::skip]
//
//     ... EntityTypes::All and EntityTypes::None get generated
// }
//
// ... impls for bits/from_bits_truncate/intersects get generated.
//
// ... impls for bit operations get generated.
//
// ... impls for Debug (and optionally Display) get generated.
//
// Crates like enum-flags and flagset already try to do something similar. Are they good enough?

#[derive(Clone, Copy, PartialEq, Eq, Hash, Default)]
pub struct EntityTypes(u32);

impl EntityTypes {
    // Note: @AddEntity @Derive
    pub const WIZARD: Self = Self(1 << 0);
    pub const MANA_POTION: Self = Self(1 << 1);
    pub const EXIT: Self = Self(1 << 2);
    pub const WATER: Self = Self(1 << 3);
    pub const GROUND: Self = Self(1 << 4);
    pub const TREE: Self = Self(1 << 5);
    pub const WOODEN_CRATE: Self = Self(1 << 6);
    pub const IRON_CRATE: Self = Self(1 << 7);
    pub const KEY: Self = Self(1 << 8);
    pub const KEY_GATE: Self = Self(1 << 9);
    pub const TRANSPOSITION_STONE: Self = Self(1 << 10);
    pub const SUMMONING_STONE: Self = Self(1 << 11);
    pub const FAMILIAR_CAT: Self = Self(1 << 12);
    pub const SKELLY_WARRIOR: Self = Self(1 << 13);
    pub const SKELLY_ARCHER: Self = Self(1 << 14);
    pub const PRESSURE_PLATE: Self = Self(1 << 15);
    pub const PRESSURE_PLATE_GATE: Self = Self(1 << 16);

    pub const NONE: Self = Self(0);
    // Note: @AddEntity @Derive
    pub const ALL: Self = Self::WIZARD
        | Self::MANA_POTION
        | Self::EXIT
        | Self::WATER
        | Self::GROUND
        | Self::TREE
        | Self::WOODEN_CRATE
        | Self::IRON_CRATE
        | Self::KEY
        | Self::KEY_GATE
        | Self::TRANSPOSITION_STONE
        | Self::SUMMONING_STONE
        | Self::FAMILIAR_CAT
        | Self::SKELLY_WARRIOR
        | Self::SKELLY_ARCHER
        | Self::PRESSURE_PLATE
        | Self::PRESSURE_PLATE_GATE;

    #[allow(dead_code)]
    pub fn bits(&self) -> u32 {
        self.0
    }

    #[allow(dead_code)]
    pub fn from_bits_truncate(bits: u32) -> Self {
        Self(Self::ALL.0 & bits)
    }

    pub fn intersects(&self, other: Self) -> bool {
        self.0 & other.0 != 0
    }

    pub const fn values() -> &'static [EntityTypes] {
        // Note: @AddEntity @Derive
        &[
            Self::WIZARD,
            Self::EXIT,
            Self::WATER,
            Self::GROUND,
            Self::TREE,
            Self::WOODEN_CRATE,
            Self::IRON_CRATE,
            Self::KEY,
            Self::KEY_GATE,
            Self::TRANSPOSITION_STONE,
            Self::SUMMONING_STONE,
            Self::FAMILIAR_CAT,
            Self::SKELLY_WARRIOR,
            Self::SKELLY_ARCHER,
            Self::PRESSURE_PLATE,
            Self::PRESSURE_PLATE_GATE,
        ]
    }

    // TODO(yan): Consider removing this in favor of display impl? We already
    // have EntityType::values.
    pub const fn names() -> &'static [&'static str] {
        // Note: @AddEntity @Derive
        &[
            "WIZARD",
            "EXIT",
            "WATER",
            "GROUND",
            "TREE",
            "WOODEN_CRATE",
            "IRON_CRATE",
            "KEY",
            "KEY_GATE",
            "TRANSPOSITION_STONE",
            "SUMMONING_STONE",
            "FAMILIAR_CAT",
            "SKELLY_WARRIOR",
            "SKELLY_ARCHER",
            "PRESSURE_PLATE",
            "PRESSURE_PLATE_GATE",
        ]
    }
}

impl const BitOr for EntityTypes {
    type Output = Self;

    fn bitor(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl const BitOrAssign for EntityTypes {
    fn bitor_assign(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

impl const BitAnd for EntityTypes {
    type Output = Self;

    fn bitand(self, other: Self) -> Self {
        Self(self.0 & other.0)
    }
}

impl const BitAndAssign for EntityTypes {
    fn bitand_assign(&mut self, other: Self) {
        self.0 &= other.0;
    }
}

impl fmt::Debug for EntityTypes {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        let mut first = true;

        f.write_str("EntityTypes(")?;
        for (value, name) in Self::values().iter().zip(Self::names().iter()) {
            if self.intersects(*value) {
                if !first {
                    f.write_str("|")?;
                }
                f.write_str(name)?;
                first = false;
            }
        }
        f.write_str(")")?;

        Ok(())
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Entity {
    pub id: Id,

    //
    // Init data
    //
    pub ty: EntityType,
    pub data: EntityData,

    // TODO(yan): @Speed @Memory Is IVec too large for our usecase? Do we want
    // 16bit ivec (v2i16 or v3i16) instead? It seems we could vectorize it too.
    pub position: IVec3,
    pub bearing: Bearing,

    pub volume_idle: AssetId,

    //
    // Runtime data
    //
    pub movement: Movement,
    pub support: Support,
    pub supports_id: Option<Id>,

    pub status_effects: StatusEffects,
    pub death_causes: DeathCauses,

    //
    // Animation data
    //
    pub position_interpolation: Option<Vec3LinearInterpolation>,

    //
    // Rendering data
    //
    pub color_mul: u32,
    pub running_anims: RunningAnimations,
}

pub fn create_entity(
    entities: &mut IdMap<Entity, &Linear>,
    entity_init: &EntityInit,
    missing_anim: Animation,
) -> Id {
    fn create_entity_data(entity_init: &EntityInit, missing_anim: Animation) -> EntityData {
        // Note: @AddEntity @Derive
        match EntityDataInit::from_entity_init(entity_init) {
            EntityDataInit::Wizard(data) => EntityData::Wizard(WizardEntityData {
                anim_front: data.anim_front.unwrap_or(missing_anim),
                anim_back: data.anim_back.unwrap_or(missing_anim),
                anim_left: data.anim_left.unwrap_or(missing_anim),
                anim_right: data.anim_right.unwrap_or(missing_anim),

                controlled: false,
                inventory: [None; 6],
            }),
            EntityDataInit::Exit(data) => EntityData::Exit(ExitEntityData {
                anim: data
                    .anim
                    .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
            }),
            EntityDataInit::Water(data) => EntityData::Water(WaterEntityData {
                anim: data
                    .anim
                    .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
            }),
            EntityDataInit::Ground(data) => EntityData::Ground(GroundEntityData {
                anim: data
                    .anim
                    .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
            }),
            EntityDataInit::Tree(data) => EntityData::Tree(TreeEntityData {
                anim: data.anim.unwrap_or(missing_anim),
            }),
            EntityDataInit::WoodenCrate(data) => EntityData::WoodenCrate(WoodenCrateEntityData {
                anim: data.anim.unwrap_or(missing_anim),
            }),
            EntityDataInit::IronCrate(data) => EntityData::IronCrate(IronCrateEntityData {
                anim: data.anim.unwrap_or(missing_anim),
            }),
            EntityDataInit::Key(data) => EntityData::Key(KeyEntityData {
                anim: data.anim.unwrap_or(missing_anim),
            }),
            EntityDataInit::KeyGate(data) => EntityData::KeyGate(KeyGateEntityData {
                open: data.open,
                anim: data
                    .anim
                    .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
                anim_open: data
                    .anim_open
                    .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
            }),
            EntityDataInit::TranspositionStone(data) => {
                EntityData::TranspositionStone(TranspositionStoneEntityData {
                    anim: data.anim.unwrap_or(missing_anim),
                    anim_active: data.anim_active.unwrap_or(missing_anim),

                    active: false,
                })
            }
            EntityDataInit::SummoningStone(data) => {
                EntityData::SummoningStone(SummoningStoneEntityData {
                    anim: data.anim.unwrap_or(missing_anim),
                    anim_active: data.anim_active.unwrap_or(missing_anim),

                    active: false,
                })
            }
            EntityDataInit::FamiliarCat(data) => EntityData::FamiliarCat(FamiliarCatEntityData {
                anim_front: data.anim_front.unwrap_or(missing_anim),
                anim_back: data.anim_back.unwrap_or(missing_anim),
                anim_left: data.anim_left.unwrap_or(missing_anim),
                anim_right: data.anim_right.unwrap_or(missing_anim),

                controlled: false,
            }),
            EntityDataInit::SkellyWarrior(data) => {
                EntityData::SkellyWarrior(SkellyWarriorEntityData {
                    anim_front: data.anim_front.unwrap_or(missing_anim),
                    anim_back: data.anim_back.unwrap_or(missing_anim),
                    anim_left: data.anim_left.unwrap_or(missing_anim),
                    anim_right: data.anim_right.unwrap_or(missing_anim),
                    anim_aggro_front: data.anim_aggro_front.unwrap_or(missing_anim),
                    anim_aggro_back: data.anim_aggro_back.unwrap_or(missing_anim),
                    anim_aggro_left: data.anim_aggro_left.unwrap_or(missing_anim),
                    anim_aggro_right: data.anim_aggro_right.unwrap_or(missing_anim),

                    aggro_id: None,
                })
            }
            EntityDataInit::SkellyArcher(data) => {
                EntityData::SkellyArcher(SkellyArcherEntityData {
                    anim_front: data.anim_front.unwrap_or(missing_anim),
                    anim_back: data.anim_back.unwrap_or(missing_anim),
                    anim_left: data.anim_left.unwrap_or(missing_anim),
                    anim_right: data.anim_right.unwrap_or(missing_anim),
                    anim_aggro_front: data.anim_aggro_front.unwrap_or(missing_anim),
                    anim_aggro_back: data.anim_aggro_back.unwrap_or(missing_anim),
                    anim_aggro_left: data.anim_aggro_left.unwrap_or(missing_anim),
                    anim_aggro_right: data.anim_aggro_right.unwrap_or(missing_anim),

                    aggro_id: None,
                })
            }
            EntityDataInit::PressurePlate(data) => {
                EntityData::PressurePlate(PressurePlateEntityData {
                    anim: data
                        .anim
                        .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),

                    anim_pressed: data
                        .anim_pressed
                        .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),

                    pressed: false,
                })
            }
            EntityDataInit::PressurePlateGate(data) => {
                EntityData::PressurePlateGate(PressurePlateGateEntityData {
                    anim: data
                        .anim
                        .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
                    anim_open: data
                        .anim_open
                        .unwrap_or_else(|| create_missing_volume_anim(missing_anim)),
                    open_if_active: data.open_if_active,
                    open_if_active_op: data.open_if_active_op,

                    open: false,
                })
            }
        }
    }

    let data = create_entity_data(entity_init, missing_anim);
    let running_anims = get_entity_initial_running_anims(entity_init, missing_anim);

    entities.insert_with(|id| Entity {
        id,
        ty: entity_init.ty,
        data,

        position: entity_init.position,
        bearing: entity_init.bearing,

        volume_idle: entity_init.volume_idle,

        movement: Movement::None,
        support: Support::Unknown,
        supports_id: None,

        status_effects: StatusEffects::NONE,
        death_causes: DeathCauses::NONE,

        position_interpolation: None,

        color_mul: 0xffffffff,
        running_anims,
    })
}

pub fn get_entity_initial_running_anims(
    entity_init: &EntityInit,
    missing: Animation,
) -> RunningAnimations {
    let missing_vol = create_missing_volume_anim(missing);
    // Note: @AddEntity
    match &entity_init.data {
        EntityDataInit::Wizard(data) => RunningAnimations::Prop(match entity_init.bearing {
            Bearing::North => data.anim_back.unwrap_or(missing),
            Bearing::South => data.anim_front.unwrap_or(missing),
            Bearing::East => data.anim_right.unwrap_or(missing),
            Bearing::West => data.anim_left.unwrap_or(missing),
        }),
        EntityDataInit::Exit(data) => RunningAnimations::Volume(data.anim.unwrap_or(missing_vol)),
        EntityDataInit::Water(data) => RunningAnimations::Volume(data.anim.unwrap_or(missing_vol)),
        EntityDataInit::Ground(data) => RunningAnimations::Volume(data.anim.unwrap_or(missing_vol)),
        EntityDataInit::Tree(data) => RunningAnimations::Prop(data.anim.unwrap_or(missing)),
        EntityDataInit::WoodenCrate(data) => RunningAnimations::Prop(data.anim.unwrap_or(missing)),
        EntityDataInit::IronCrate(data) => RunningAnimations::Prop(data.anim.unwrap_or(missing)),
        EntityDataInit::Key(data) => RunningAnimations::Prop(data.anim.unwrap_or(missing)),
        EntityDataInit::KeyGate(data) => {
            RunningAnimations::Volume(data.anim.unwrap_or(missing_vol))
        }
        EntityDataInit::TranspositionStone(data) => {
            RunningAnimations::Prop(data.anim.unwrap_or(missing))
        }
        EntityDataInit::SummoningStone(data) => {
            RunningAnimations::Prop(data.anim.unwrap_or(missing))
        }
        EntityDataInit::FamiliarCat(data) => RunningAnimations::Prop(match entity_init.bearing {
            Bearing::North => data.anim_back.unwrap_or(missing),
            Bearing::South => data.anim_front.unwrap_or(missing),
            Bearing::East => data.anim_right.unwrap_or(missing),
            Bearing::West => data.anim_left.unwrap_or(missing),
        }),
        EntityDataInit::SkellyWarrior(data) => RunningAnimations::Prop(match entity_init.bearing {
            Bearing::North => data.anim_back.unwrap_or(missing),
            Bearing::South => data.anim_front.unwrap_or(missing),
            Bearing::East => data.anim_right.unwrap_or(missing),
            Bearing::West => data.anim_left.unwrap_or(missing),
        }),
        EntityDataInit::SkellyArcher(data) => RunningAnimations::Prop(match entity_init.bearing {
            Bearing::North => data.anim_back.unwrap_or(missing),
            Bearing::South => data.anim_front.unwrap_or(missing),
            Bearing::East => data.anim_right.unwrap_or(missing),
            Bearing::West => data.anim_left.unwrap_or(missing),
        }),
        EntityDataInit::PressurePlate(data) => {
            RunningAnimations::Volume(data.anim.unwrap_or(missing_vol))
        }
        EntityDataInit::PressurePlateGate(data) => {
            RunningAnimations::Volume(data.anim.unwrap_or(missing_vol))
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum LevelStateTransition {
    None,
    Failure,
    Success,
}

#[derive(Debug)]
pub struct Level {
    // TODO(yan): @Speed @Memory What happens, if we give out the temporary
    // allocator to two Vecs, and they start growing in an alternating fashion?
    // If it were just one Vec, it could just grow the memory. Sooo, we'll have
    // to audit this one day and set some reasonalble capacities OR give out
    // multiple allocators from multiple arenas to different collections.
    pub wizard_id: Option<Id>,
    pub history: History<Entity, &'static Linear>,
    pub entities: IdMap<Entity, &'static Linear>,
    pub entities_init: Vec<EntityInit, &'static Linear>,
}

// TODO(yan): @Correctness This currently always just runs the action, but what
// if the action was not valid to choose in the first place? Where do we place
// the validation logic? We currently validate in the interaction layer, because
// we also want to show feedback why something is not possible, but that makes
// the logic spread out. We absolutely must keep the feedback, so every
// validation layer will have to provide enough feedback to the interaction
// layer to run animations.
pub fn simulate(
    temp_allocator: &Linear,
    action: Action,
    level: &mut Level,
    record_history: bool,
) -> LevelStateTransition {
    let entities_prev = {
        let mut entities_prev = IdMap::new_in(temp_allocator);
        entities_prev.clone_from(&level.entities);
        entities_prev
    };

    let (mut controlled_entity_id, mut controlled_entity_is_wizard) = {
        let controlled_entity_id = find_or_set_controlled_entity(&mut level.entities);
        if let Some(id) = controlled_entity_id {
            (id, level.entities[id].ty == EntityType::Wizard)
        } else {
            return LevelStateTransition::None;
        }
    };

    run_status_effects_system(&mut level.entities);

    // TODO(yan): If multiple runes are in range, let the player pick
    // (e.g. with tab-cycling) and store the picked rune on the player
    // entity. For now we just pick the closest one (and randomly, if
    // distance is the same).
    let closest_stone_id = run_stone_activation_system(
        temp_allocator,
        &mut level.entities,
        if controlled_entity_is_wizard {
            Some(controlled_entity_id)
        } else {
            None
        },
    );

    #[allow(unused_mut)]
    let mut additional_movement_records: ArrayVec<MovementRecord, 8> = ArrayVec::new();
    let mut movement_traces: Vec<MovementTrace, _> = Vec::new_in(temp_allocator);
    match action {
        Action::Wait => (),

        Action::Move { bearing } => {
            let controlled_entity = &level.entities[controlled_entity_id];
            let controlled_entity_ty = controlled_entity.ty;

            // TODO(yan): @Cleanup The cat familiar has unique movement that our
            // movement system can't manage. Instead of going through the
            // system, we just hardcode the cat's movement here.
            //
            // This is not very good. The cat ignores some interactions with
            // other systems this way. Fortunately none of the interactions are
            // in the game yet, so we got away with it can add the cat to the
            // game before we have a full, continuous-in-time transaction
            // system.
            //
            // One interaction is worked around here: because the cat can
            // sometimes move multiple tiles per action, but doesn't actually
            // teleport, we need to let the aggro system know the path it
            // took. The aggro system uses that path to change bearings of
            // skellies, or potentially even change the outcome of the move
            // completely: e.g. if the cat jumped in front of a skelly archer,
            // the archer would shoot it midair, and the cat would be staggered
            // (and killed) and not make it into its intended, supported
            // destination. Because it would end up midair and thus not
            // supported, the support system would kick in and make the cat
            // corpse fall down.
            if controlled_entity_ty == EntityType::FamiliarCat {
                let entity_grid = build_entity_grid(temp_allocator, &level.entities);

                // There's 4 (maybe later 5?) cases of cat movement.
                //
                // 1) Regular movement: the cat is not blocked and the
                //    destination tile is statically supported.
                //
                // 2) Jump up movement: the cat is blocked, but the entity
                //    blocking it can statically support it. The cat jumps up.
                //
                // 3) Jump across movement: the destination tile of regular
                //    movement can not statically support the cat, but the next
                //    one in that direction can. The cat jumps across.
                //
                // 4) Jump down movement: the destination tile of regular
                //    movement can not statically support the cat and there is
                //    nothing to jump across to, but there is support one tile
                //    down below the destination tile. The cat jumps down.
                //
                // We could also have jump down across, which would take
                // precedence over 4).
                let position = controlled_entity.position;
                let search_direction = IVec3::from(bearing);
                let search_position = position + search_direction;
                if entity_grid.is_in_bounds(search_position) {
                    let mut move_is_blocked = false;
                    for &(entity_id, entity_ty) in &entity_grid[search_position] {
                        if entity_weight(entity_ty) > 0 {
                            if entity_ty == EntityType::KeyGate {
                                if !level.entities[entity_id].data.unwrap_gate().open {
                                    move_is_blocked = true;
                                }
                            } else {
                                move_is_blocked = true;
                            }
                        }
                    }

                    if move_is_blocked {
                        // Potential case 2. Let's see if we can jump on top of this.
                        let search_up_position = search_position + IVec3::Z;

                        let mut jump_up_is_blocked = false;
                        // TODO(yan): @LevelTopologies If up is out of bounds,
                        // there's nothing there, and we could go there. This is
                        // an exception from other level bounds checking (down
                        // supports entities, and sides don't allow passage). we
                        // could disallow this and always put an invisible
                        // entity in the level that would allow this. Will have
                        // to to revisit this once we add wrapping levels.
                        if entity_grid.is_in_bounds(search_up_position) {
                            for &(entity_id, entity_ty) in &entity_grid[search_up_position] {
                                if entity_weight(entity_ty) > 0 {
                                    if entity_ty == EntityType::KeyGate {
                                        if !level.entities[entity_id].data.unwrap_gate().open {
                                            jump_up_is_blocked = true;
                                        }
                                    } else {
                                        jump_up_is_blocked = true;
                                    }
                                }
                            }
                        }

                        if jump_up_is_blocked {
                            let controlled_entity = &mut level.entities[controlled_entity_id];
                            controlled_entity.bearing = bearing;
                            // TODO(yan): Feedback.
                        } else {
                            // TODO(yan): The blocker might not be able to
                            // dynamically support us. if that happens, we
                            // should do breaking logic. There *shouldn't* be
                            // anything like this in the game as of Aug 8th
                            // 2022.
                            let mut jump_up_is_supported = false;
                            for &(entity_id, entity_ty) in &entity_grid[search_position] {
                                if entity_supports_tys(entity_ty)
                                    .intersects(EntityTypes::FAMILIAR_CAT)
                                {
                                    if entity_ty == EntityType::KeyGate {
                                        if !level.entities[entity_id].data.unwrap_gate().open {
                                            jump_up_is_supported = true;
                                        }
                                    } else {
                                        jump_up_is_supported = true;
                                    }
                                }
                            }

                            if jump_up_is_supported {
                                // Case 2!
                                let controlled_entity = &mut level.entities[controlled_entity_id];

                                movement_traces.push(MovementTrace {
                                    entity_id: controlled_entity.id,
                                    entity_ty: EntityType::FamiliarCat,
                                    position: controlled_entity.position + IVec3::Z,
                                });

                                controlled_entity.position = search_up_position;
                                controlled_entity.bearing = bearing;
                            } else {
                                log::error!("Cat found an unblocked but unsupported jump up");
                            }
                        }
                    } else {
                        // Potential case 1, 3 or 4.
                        let search_down_position = search_position - IVec3::Z;
                        let mut move_is_supported = !entity_grid.is_in_bounds(search_down_position);

                        if !move_is_supported {
                            for &(entity_id, entity_ty) in &entity_grid[search_down_position] {
                                if entity_supports_tys(entity_ty)
                                    .intersects(EntityTypes::FAMILIAR_CAT)
                                {
                                    if entity_ty == EntityType::KeyGate {
                                        if !level.entities[entity_id].data.unwrap_gate().open {
                                            move_is_supported = true;
                                        }
                                    } else {
                                        move_is_supported = true;
                                    }
                                }
                            }
                        }

                        if move_is_supported {
                            // Case 1! Go through regular movement system.
                            let controlled_entity = &mut level.entities[controlled_entity_id];
                            controlled_entity.movement = Movement::from(bearing);
                            controlled_entity.bearing = bearing;
                        } else {
                            // Potential case 3 or 4.
                            let search_across_position = search_position + search_direction;

                            let mut jump_across_blocked =
                                !entity_grid.is_in_bounds(search_across_position);

                            if !jump_across_blocked {
                                for &(entity_id, entity_ty) in &entity_grid[search_across_position]
                                {
                                    if entity_weight(entity_ty) > 0 {
                                        if entity_ty == EntityType::KeyGate {
                                            if !level.entities[entity_id].data.unwrap_gate().open {
                                                jump_across_blocked = true;
                                            }
                                        } else {
                                            jump_across_blocked = true;
                                        }
                                    }
                                }
                            }

                            let search_across_down_position = search_across_position - IVec3::Z;
                            let mut jump_across_supported =
                                !entity_grid.is_in_bounds(search_across_down_position);

                            if !jump_across_supported {
                                for &(entity_id, entity_ty) in
                                    &entity_grid[search_across_down_position]
                                {
                                    if entity_supports_tys(entity_ty)
                                        .intersects(EntityTypes::FAMILIAR_CAT)
                                    {
                                        if entity_ty == EntityType::KeyGate {
                                            if !level.entities[entity_id].data.unwrap_gate().open {
                                                jump_across_supported = true;
                                            }
                                        } else {
                                            jump_across_supported = true;
                                        }
                                    }
                                }
                            }

                            if !jump_across_blocked && jump_across_supported {
                                // Case 3!
                                let controlled_entity = &mut level.entities[controlled_entity_id];

                                movement_traces.push(MovementTrace {
                                    entity_id: controlled_entity_id,
                                    entity_ty: EntityType::FamiliarCat,
                                    position: search_position,
                                });

                                controlled_entity.position = search_across_position;
                                controlled_entity.bearing = bearing;
                            } else {
                                // TODO(yan): @Gameplay Try if jump down-across
                                // is available before defaulting to the
                                // movement system.
                                let controlled_entity = &mut level.entities[controlled_entity_id];
                                controlled_entity.movement = Movement::from(bearing);
                                controlled_entity.bearing = bearing;
                            }
                        }
                    }
                } else {
                    // Blocked by level bounds, Go through regular movement system.
                    let controlled_entity = &mut level.entities[controlled_entity_id];
                    controlled_entity.movement = Movement::from(bearing);
                    controlled_entity.bearing = bearing;
                }
            } else {
                let controlled_entity = &mut level.entities[controlled_entity_id];
                controlled_entity.movement = Movement::from(bearing);
                controlled_entity.bearing = bearing;
            }
        }

        // TODO(yan): @Gameplay Can we get rid of this and just turn by moving,
        // and have a way of casting a spell directionally, or perhaps care less
        // about our orientation when casting spells?
        Action::Turn { turn } => {
            let controlled_entity = &mut level.entities[controlled_entity_id];
            controlled_entity.bearing = controlled_entity.bearing.with_turn(turn);
        }

        Action::Interact => {
            if level.entities[controlled_entity_id].ty == EntityType::Wizard {
                let entity_grid = build_entity_grid(temp_allocator, &level.entities);

                let wizard_entity_id = controlled_entity_id;
                let wizard_entity = &mut level.entities[wizard_entity_id];
                let wizard_entity_position = wizard_entity.position;
                let wizard_entity_bearing = wizard_entity.bearing;

                if let Some(stone_id) = closest_stone_id {
                    let stone = &level.entities[stone_id];
                    match stone.ty {
                        EntityType::TranspositionStone => {
                            let search_step = IVec3::from(wizard_entity_bearing);

                            let mut search_distance = 1;
                            let mut target: Option<(Id, IVec3)> = None;
                            'outer_transposition: loop {
                                let search_position =
                                    wizard_entity_position + search_step * search_distance;

                                if !entity_grid.is_in_bounds(search_position) {
                                    break;
                                }

                                for &(entity_id, entity_ty) in &entity_grid[search_position] {
                                    if entity_target_of_transposition(entity_ty) {
                                        target = Some((entity_id, search_position));
                                        break 'outer_transposition;
                                    }
                                }

                                for &(entity_id, _) in &entity_grid[search_position] {
                                    if entity_blocks_transposition(&level.entities[entity_id]) {
                                        break 'outer_transposition;
                                    }
                                }

                                search_distance += 1;
                            }

                            if let Some((target_id, target_position)) = target {
                                // TODO(yan): Feedback.
                                level.entities[target_id].position = wizard_entity_position;
                                level.entities[wizard_entity_id].position = target_position;
                            }
                        }
                        EntityType::SummoningStone => {
                            // Find first unblocked tile with same elevation that
                            // can support our summon.
                            let search_step = IVec3::from(wizard_entity_bearing);

                            let mut search_distance = 1;
                            let mut target: Option<IVec3> = None;

                            // TODO(yan): @Cleanup This is more complicated than
                            // it needs to be. It basically just chekcs the 4
                            // adjacent tiles to the summoner, but it looks like
                            // it checks infinitely, like transposition does.
                            'outer_summoning: loop {
                                let search_position =
                                    wizard_entity_position + search_step * search_distance;

                                if !entity_grid.is_in_bounds(search_position) {
                                    break;
                                }

                                for &(entity_id, _) in &entity_grid[search_position] {
                                    if entity_blocks_summoning(&level.entities[entity_id]) {
                                        break 'outer_summoning;
                                    }
                                }

                                let down_position = search_position - IVec3::Z;

                                if entity_grid.is_in_bounds(down_position) {
                                    let mut supported = false;
                                    for (_, down_entity_ty) in &entity_grid[down_position] {
                                        if entity_supports_tys(*down_entity_ty)
                                            .intersects(EntityTypes::FAMILIAR_CAT)
                                        {
                                            supported = true;
                                            break;
                                        }
                                    }

                                    if supported {
                                        target = Some(search_position);
                                    }

                                    break;
                                }

                                search_distance += 1;
                            }

                            if let Some(target_position) = target {
                                // If a familiar already exists somewhere in the
                                // level, teleport it back where we would spawn
                                // it. Otherwise, spawn a familiar.
                                if let Some((_, familiar)) = level
                                    .entities
                                    .iter_mut()
                                    .find(|(_, entity)| entity.ty == EntityType::FamiliarCat)
                                {
                                    familiar.position = target_position;
                                } else {
                                    // TODO(yan): Feedback.
                                    //
                                    // TODO(yan): @Cleanup @Hack This hardcodes an
                                    // asset. We really need a prototype system.
                                    static ANIM_FRONT: Animation = Animation {
                                        texture_id: AssetId::from_raw(0x7c393b8592d90ed7),
                                        frame: IRect::const_new(80, 224, 16, 16),
                                    };
                                    static ANIM_BACK: Animation = Animation {
                                        texture_id: AssetId::from_raw(0x7c393b8592d90ed7),
                                        frame: IRect::const_new(96, 224, 16, 16),
                                    };
                                    static ANIM_LEFT: Animation = Animation {
                                        texture_id: AssetId::from_raw(0x7c393b8592d90ed7),
                                        frame: IRect::const_new(112, 224, 16, 16),
                                    };
                                    static ANIM_RIGHT: Animation = Animation {
                                        texture_id: AssetId::from_raw(0x7c393b8592d90ed7),
                                        frame: IRect::const_new(64, 224, 16, 16),
                                    };

                                    level.entities.insert_with(|id| Entity {
                                        id,

                                        ty: EntityType::FamiliarCat,
                                        data: EntityData::FamiliarCat(FamiliarCatEntityData {
                                            anim_front: ANIM_FRONT,
                                            anim_back: ANIM_BACK,
                                            anim_left: ANIM_LEFT,
                                            anim_right: ANIM_RIGHT,

                                            controlled: false,
                                        }),

                                        position: target_position,
                                        bearing: Bearing::South,

                                        volume_idle: asset::ID_MISSING_VOLUME,

                                        movement: Movement::None,
                                        support: Support::Unknown,
                                        supports_id: None,

                                        status_effects: StatusEffects::NONE,
                                        death_causes: DeathCauses::NONE,

                                        position_interpolation: None,

                                        color_mul: 0xffffffff,
                                        running_anims: RunningAnimations::Prop(ANIM_FRONT),
                                    });
                                }
                            }
                        }
                        _ => unreachable!(),
                        // TODO(yan): Do we want to bring back levitate as a runestone?
                        /*
                        Spell::Levitate => {
                            const RANGE_MAX: u16 = 1;
                            const ENTITIES_TARGET: EntityTypes = entities_targets_of_levitate();
                            const ENTITIES_BLOCKING: EntityTypes = entities_blocking_levitate();

                            let search_step = IVec3::from(player_entity_bearing);

                            // TODO(yan): Replace this search with line-of-sight
                            // mechanic - only allowing to select viable targets.
                            let mut target: Option<Id> = None;
                            'outer_levitate: for search_distance in 1..=RANGE_MAX {
                                let search_position =
                                    player_entity_position + search_step * i32::from(search_distance);

                                if !entity_grid.is_in_bounds(search_position) {
                                    break;
                                }

                                for &(entity_id, entity_ty) in &entity_grid[search_position] {
                                    if ENTITIES_TARGET.intersects(entity_ty.to_entity_types()) {
                                        target = Some(entity_id);
                                        break 'outer_levitate;
                                    }

                                    if ENTITIES_BLOCKING.intersects(entity_ty.to_entity_types()) {
                                        break 'outer_levitate;
                                    }
                                }
                            }

                            if let Some(target_id) = target {
                                level.entities[target_id].status_effects.levitate = 5;
                            }
                        }
                        */

                        // TODO(yan): Do we want to bring back force push as a runestone?
                        /*
                        Spell::ForcePush => {
                            const ENTITIES_TARGET: EntityTypes = EntityTypes::WIZARD
                                | EntityTypes::WOODEN_CRATE
                                | EntityTypes::IRON_CRATE;

                            let search_position =
                                player_entity_position + IVec3::from(player_entity_bearing);

                            for &(entity_id, entity_ty) in &entity_grid[search_position] {
                                if entity_ty.to_entity_types().intersects(ENTITIES_TARGET) {
                                    additional_movement_records.push(MovementRecord {
                                        entity_id,
                                        position: search_position,
                                        bearing: player_entity_bearing,
                                        // TODO(yan): @Correctness Is this right?
                                        // Won't this collide with something?
                                        priority: entity_movement_priority(player_entity.ty) - 1,
                                        strength: 10,
                                    });
                                }
                            }
                        }
                        */
                    }
                } else {
                    // TODO(yan): Feedback.
                }
            }
        }

        Action::SwitchCharacter => {
            let mut controllable_entity_ids = Vec::with_capacity_in(8, temp_allocator);
            let mut curr_idx: Option<usize> = None;
            for (entity_id, entity) in &level.entities {
                match entity.data {
                    EntityData::Wizard(data) => {
                        if data.controlled {
                            curr_idx = Some(controllable_entity_ids.len());
                        }
                        controllable_entity_ids.push(entity_id);
                    }
                    EntityData::FamiliarCat(data) => {
                        if data.controlled {
                            curr_idx = Some(controllable_entity_ids.len());
                        }
                        controllable_entity_ids.push(entity_id);
                    }
                    _ => (),
                }
            }

            if let Some(&last_id) = controllable_entity_ids.last() {
                if last_id == controlled_entity_id {
                    // The last entity is active. This potentially means there
                    // is just the one active entity. If the IDs are the same,
                    // there is just the one entity and we do
                    // nothing. Otherwise, we switch from the last entity to the
                    // first one (wrapping).

                    let first_id = controllable_entity_ids.first().copied().unwrap();
                    if first_id != last_id {
                        set_controlled_entity(&mut level.entities, last_id, false);
                        set_controlled_entity(&mut level.entities, first_id, true);
                        controlled_entity_id = first_id;
                        controlled_entity_is_wizard =
                            level.entities[first_id].ty == EntityType::Wizard;
                    }
                } else {
                    // There's more than one entity and the active one is not
                    // the last one. Deacticate the active entity and activate
                    // the next.

                    let curr_idx = curr_idx.unwrap();
                    debug_assert!(controllable_entity_ids.len() >= 2);
                    debug_assert!(controllable_entity_ids.len() > curr_idx + 1);

                    let curr_id = controllable_entity_ids[curr_idx];
                    let next_id = controllable_entity_ids[curr_idx + 1];

                    set_controlled_entity(&mut level.entities, curr_id, false);
                    set_controlled_entity(&mut level.entities, next_id, true);
                    controlled_entity_id = next_id;
                    controlled_entity_is_wizard = level.entities[next_id].ty == EntityType::Wizard;
                }
            }
        }
    }

    let mut level_state_transition = LevelStateTransition::None;

    run_aggro_intercept_system(temp_allocator, &mut level.entities);
    run_movement_system(
        temp_allocator,
        &mut level.entities,
        &additional_movement_records,
    );

    //
    // Item pick-up system
    //
    {
        let entity_grid = build_entity_grid(temp_allocator, &level.entities);
        let controlled_entity_position = level.entities[controlled_entity_id].position;
        for &(entity_id, entity_ty) in &entity_grid[controlled_entity_position] {
            match entity_ty {
                EntityType::Key => {
                    // Our controlled entity can be pretty much anyone, but at
                    // the moment only wizards have inventories, so we if this
                    // not a wizard, we find the first wizard and place the item
                    // in his inventory.
                    //
                    // TODO(yan): Maybe we do want an (implicit?) inventory
                    // entity (see above).
                    let inventory = if let EntityData::Wizard(data) =
                        &mut level.entities[controlled_entity_id].data
                    {
                        Some(&mut data.inventory)
                    } else {
                        level.entities.iter_mut().find_map(|(_, entity)| {
                            if let EntityData::Wizard(data) = &mut entity.data {
                                Some(&mut data.inventory)
                            } else {
                                None
                            }
                        })
                    };

                    let picked_up = if let Some(inventory) = inventory {
                        if let Some(empty_slot) = inventory.iter().position(|&slot| slot == None) {
                            // TODO(yan): Feedback.
                            inventory[empty_slot] = Some(Item::Key);
                            true
                        } else {
                            // TODO(yan): Feedback.
                            false
                        }
                    } else {
                        false
                    };

                    if picked_up {
                        // TODO(yan): Feedback.
                        level.entities.remove(entity_id);
                    }
                }
                _ => (),
            }
        }
    }

    //
    // KeyGate unlock system
    //
    {
        // XXX: Experiment changing the current KeyGate mechanic to:
        //
        // - keys are not lost on use
        // - there are multiple key types (e.g. RGB)
        // - keys are used explicitly with interact button
        // - keys can be used to close the gate, not just open it (also if
        //   standing inside to be lifted, maybee?)
        //
        // Variation: Key is inserted in the gate for opening (and thus lost),
        // but retrieved from the gate when closing.
        //
        // Variation: Split KeyGate functionality into KeyGate and KeyLock,
        // having possibly M:N relationship between KeyLocks and KeyGates, like
        // we'll likely have for PressurePlates and PressurePlateGates.

        let controlled_entity_has_key = match &level.entities[controlled_entity_id].data {
            EntityData::Wizard(data) => data.inventory.contains(&Some(Item::Key)),
            _ => false,
        };

        if controlled_entity_has_key {
            let position = level.entities[controlled_entity_id].position;

            let mut unlocked = false;
            for (_, entity) in &mut level.entities {
                if entity.position == position {
                    match &mut entity.data {
                        EntityData::KeyGate(data) => {
                            if !data.open {
                                data.open = true;
                                unlocked = true;
                                break;
                            }
                        }
                        _ => (),
                    }
                }
            }

            if unlocked {
                let entity = &mut level.entities[controlled_entity_id];
                let data = entity.data.unwrap_wizard_mut();
                let inventory = &mut data.inventory;

                if let Some(idx) = inventory.iter().position(|&slot| slot == Some(Item::Key)) {
                    inventory[idx] = None;
                }
            }
        }
    }

    run_support_system(temp_allocator, &mut level.entities, &mut movement_traces);
    run_aggro_system(temp_allocator, &mut level.entities, &movement_traces);
    // TODO(yan): @Cleanup We run this again to set the active values on stones
    // for rendering, because the situation might have changed by player
    // actions. Maybe there is a cleaner way?
    run_stone_activation_system(
        temp_allocator,
        &mut level.entities,
        if controlled_entity_is_wizard {
            Some(controlled_entity_id)
        } else {
            None
        },
    );

    // TODO(yan): @Cleanup This code is very temporary. It started out as a
    // copypaste and simplification of entity_initial_running_anims, but it will
    // likely evolve separately, depending on the how we eventually do
    // animations, animation transitions, etc.
    for (_, entity) in level.entities.iter_mut() {
        // Note: @AddEntity
        entity.running_anims = match &entity.data {
            EntityData::Wizard(data) => RunningAnimations::Prop(match entity.bearing {
                Bearing::North => data.anim_back,
                Bearing::South => data.anim_front,
                Bearing::East => data.anim_right,
                Bearing::West => data.anim_left,
            }),
            EntityData::Exit(data) => RunningAnimations::Volume(data.anim),
            EntityData::Water(data) => RunningAnimations::Volume(data.anim),
            EntityData::Ground(data) => RunningAnimations::Volume(data.anim),
            EntityData::Tree(data) => RunningAnimations::Prop(data.anim),
            EntityData::WoodenCrate(data) => RunningAnimations::Prop(data.anim),
            EntityData::IronCrate(data) => RunningAnimations::Prop(data.anim),
            EntityData::Key(data) => RunningAnimations::Prop(data.anim),
            EntityData::KeyGate(data) => {
                if data.open {
                    RunningAnimations::Volume(data.anim_open)
                } else {
                    RunningAnimations::Volume(data.anim)
                }
            }
            EntityData::TranspositionStone(data) => {
                if data.active {
                    RunningAnimations::Prop(data.anim_active)
                } else {
                    RunningAnimations::Prop(data.anim)
                }
            }
            EntityData::SummoningStone(data) => {
                if data.active {
                    RunningAnimations::Prop(data.anim_active)
                } else {
                    RunningAnimations::Prop(data.anim)
                }
            }
            EntityData::FamiliarCat(data) => RunningAnimations::Prop(match entity.bearing {
                Bearing::North => data.anim_back,
                Bearing::South => data.anim_front,
                Bearing::East => data.anim_right,
                Bearing::West => data.anim_left,
            }),
            EntityData::SkellyWarrior(data) => {
                RunningAnimations::Prop(match (entity.bearing, data.aggro_id) {
                    (Bearing::North, Some(_)) => data.anim_aggro_back,
                    (Bearing::North, None) => data.anim_back,
                    (Bearing::South, Some(_)) => data.anim_aggro_front,
                    (Bearing::South, None) => data.anim_front,
                    (Bearing::East, Some(_)) => data.anim_aggro_right,
                    (Bearing::East, None) => data.anim_right,
                    (Bearing::West, Some(_)) => data.anim_aggro_left,
                    (Bearing::West, None) => data.anim_left,
                })
            }
            EntityData::SkellyArcher(data) => {
                RunningAnimations::Prop(match (entity.bearing, data.aggro_id) {
                    (Bearing::North, Some(_)) => data.anim_aggro_back,
                    (Bearing::North, None) => data.anim_back,
                    (Bearing::South, Some(_)) => data.anim_aggro_front,
                    (Bearing::South, None) => data.anim_front,
                    (Bearing::East, Some(_)) => data.anim_aggro_right,
                    (Bearing::East, None) => data.anim_right,
                    (Bearing::West, Some(_)) => data.anim_aggro_left,
                    (Bearing::West, None) => data.anim_left,
                })
            }
            EntityData::PressurePlate(data) => {
                if data.pressed {
                    RunningAnimations::Volume(data.anim_pressed)
                } else {
                    RunningAnimations::Volume(data.anim)
                }
            }
            EntityData::PressurePlateGate(data) => {
                if data.open {
                    RunningAnimations::Volume(data.anim_open)
                } else {
                    RunningAnimations::Volume(data.anim)
                }
            }
        };
    }

    {
        let entity_grid = build_entity_grid(temp_allocator, &level.entities);
        for (_, entity) in level.entities.iter_mut() {
            for &(_, other_entity_ty) in &entity_grid[entity.position] {
                if entity_can_drown(entity.ty) && other_entity_ty == EntityType::Water {
                    entity.death_causes |= DeathCauses::DROWNED;
                    break;
                }
            }
        }

        let mut entities_to_remove: Vec<Id, _> = Vec::new_in(temp_allocator);
        for (entity_id, entity) in &level.entities {
            if entity.death_causes != DeathCauses::NONE {
                log::info!("Entity {entity_id} died of {:?}", entity.death_causes);
                entities_to_remove.push(entity_id);
            }
        }

        for entity_id in entities_to_remove {
            let entity = level.entities.remove(entity_id).unwrap();
            if entity.ty == EntityType::Wizard {
                level_state_transition = LevelStateTransition::Failure;
            }
        }

        // Simulation might have caused the controlled entity to be removed from
        // the level. If this happened, we need to pick another controlled
        // entity.
        let _ = find_or_set_controlled_entity(&mut level.entities);

        for (_, entity) in &mut level.entities {
            let color_mul = match entity.data {
                EntityData::Wizard(data) => {
                    if data.controlled {
                        0xffffffff
                    } else {
                        color_u32([60, 60, 60, 255])
                    }
                }
                EntityData::FamiliarCat(data) => {
                    if data.controlled {
                        0xffffffff
                    } else {
                        color_u32([60, 60, 60, 255])
                    }
                }
                _ => 0xffffffff,
            };

            entity.color_mul = color_mul;
        }

        for (_, entity) in &level.entities {
            if entity.ty == EntityType::Wizard {
                for &(_, entity_ty) in &entity_grid[entity.position] {
                    if entity_ty == EntityType::Exit {
                        level_state_transition = LevelStateTransition::Success;
                    }
                }
            }
        }
    }

    if record_history {
        match level
            .history
            .push_transaction(temp_allocator, &level.entities, &entities_prev)
        {
            Ok((pushed_count, forgot_count, hosed_count)) => {
                log::debug!(
                    "History transaction pushed/forgot/hosed {}/{}/{} changes",
                    pushed_count,
                    forgot_count,
                    hosed_count,
                );
            }
            Err(HistoryError::OutOfMemory { needed, have }) => {
                // TODO(yan): Make this error louder by showing it on screen.
                log::error!(
                    "History too small for {} changes (have enough for {}), clearing...",
                    needed,
                    have,
                );
            }
        }
    }

    level_state_transition
}

pub fn rewind(_temp_allocator: &Linear, level: &mut Level) -> bool {
    // The transaction items are ordered such that deletions go first to prevent
    // conflicts in the idmap.
    if let Some(transaction) = level.history.pop_transaction() {
        log::debug!("Rewinding {} changes", transaction.len());
        for change in transaction {
            match change {
                HistoryChange::Insert { id, value } => {
                    debug_assert!(id == value.id);
                    debug_assert!(!level.entities.contains_idx(id.idx()));
                    level.entities.insert_at_vacant_entry(id, value);
                }
                HistoryChange::Delete { id, .. } => {
                    // This deletion increases the IdMap's generation, but that
                    // shouldn't be a problem, because we insert old entities
                    // under their original IDs, and there can be no dangling
                    // references to entities that do not exist yet.
                    debug_assert!(level.entities.contains(id));
                    level.entities.remove(id);
                }
            }
        }

        true
    } else {
        // TODO(yan): Feedback.
        log::debug!("Nothing to rewind, history empty");

        false
    }
}

pub fn build_level_bounds(entities: &IdMap<Entity, &Linear>) -> (IVec3, IVec3) {
    if entities.is_empty() {
        (IVec3::ZERO, IVec3::ZERO)
    } else {
        let mut min = ivec3(i32::MAX, i32::MAX, i32::MAX);
        let mut max = ivec3(i32::MIN, i32::MIN, i32::MIN);

        for (_, entity) in entities {
            if min.x > entity.position.x {
                min.x = entity.position.x;
            }
            if min.y > entity.position.y {
                min.y = entity.position.y;
            }
            if min.z > entity.position.z {
                min.z = entity.position.z;
            }

            if max.x < entity.position.x {
                max.x = entity.position.x;
            }
            if max.y < entity.position.y {
                max.y = entity.position.y;
            }
            if max.z < entity.position.z {
                max.z = entity.position.z;
            }
        }

        (min, max)
    }
}

// TODO(yan): Find better design for what a grid cell is. Currently it is any 4
// entities and we crash if we exceed 4. One possibility would be explicit
// slots, something like:
//
// struct GridSlot {
//     floor: Option<(Id, EntityTy)>,
//     volume: Option<(Id, EntityTy)>,
//     aura: Option<(Id, EntityTy),
// }
//
// ... you get the idea.
pub fn build_entity_grid<'a>(
    temp_allocator: &'a Linear,
    entities: &IdMap<Entity, &Linear>,
) -> Grid<ArrayVec<(Id, EntityType), 4>, &'a Linear> {
    let (min, max) = build_level_bounds(entities);

    let mut entity_grid: Grid<ArrayVec<(Id, EntityType), 4>, _> =
        Grid::with_aabb_in(min, max, temp_allocator);

    for (entity_id, entity) in entities {
        let grid_cell = &mut entity_grid[entity.position];
        grid_cell.push((entity_id, entity.ty));
    }

    entity_grid
}

// TODO(yan): @Cleanup This only exists to guarantee we rebuild the entity grid
// within the same memory (e.g. when we build the grid in each iteration of a
// loop and we can't guarantee the previous memory would be reclaimed). It has a
// downside that the AABB the original grid was constructed must still be valid!
fn rebuild_entity_grid(
    entity_grid: &mut Grid<ArrayVec<(Id, EntityType), 4>, &Linear>,
    entities: &IdMap<Entity, &Linear>,
) {
    entity_grid.clear();
    for (entity_id, entity) in entities {
        let grid_cell = &mut entity_grid[entity.position];
        grid_cell.push((entity_id, entity.ty));
    }
}

// Note: This currently only represents single-tile moves (we use Bearing
// instead of IVec2/3). Not sure if we'll ever want multi-tile moves (we
// already have blitz events), but if we did, we would want a better
// collision system that would take simultaneous entity movement into
// consideration.
//
// If two records have same priority, they can be executed in any order
// (Vec::sort_unstable_by).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
struct MovementRecord {
    entity_id: Id,
    position: IVec3,
    bearing: Bearing,
    priority: i16,
    strength: u8,
}

struct MovementTrace {
    entity_id: Id,
    entity_ty: EntityType,
    position: IVec3,
}

// TODO(yan): Move to a real-time system with transactions, similar to what
// Thekla Soko does.
//
// This is a monstrous undertaking. Ideally it would not be much harder than:
//
// - gameplay::simulate is modified to run per-frame, only optionally receiving
//   player input.
//
// - There is a complete state copy lying around all the time, so we can do
//   History::push_transaction when we receive input.
//
// - Some systems (e.g. item pickup, gate unlock, aggro, more?) run per frame,
//   but their responses might not (read on).
//
// - Some updates to entities are resolved instantenously in gameplay state, and
//   animated over time in audio and visuals. We need an animation system and a
//   sound system for this.
//
// - Some update to entities (e.g. falling, shooting projectiles) can *not* be
//   resolved instantenously. Instead, they register a transaction with a couple
//   of timestamps. Let's take falling as an example:
//
//   Once the support system finds out an entity is unsupported, the entity
//   enters a falling state. I this state, it checks whether a falling
//   transaction exists for itself. If it doesn't, it creates one (to fall one
//   tile). The transaction has a couple important points in time. The commit
//   time (around halfway through the transaction) is when the transaction can
//   no longer be cancelled and the changes it brings are merged back into the
//   gamplay state. The finish time is when the transaction is officially marked
//   as done and its animations (and sounds?) have finished playing. The support
//   system then checks the entity's falling state once per frame, so eventually
//   the entity stops falling, and thus stops checking whether it should create
//   a falling transaction to fall another tile down.
//
//   Transactions can be cancelled, if they didn't reach their commit time
//   yet. This happens when the original state the transaction would be touching
//   (or observing) has meanwhile changed, e.g. because another transaction
//   commited before and touched the same data. If this happens, we need to
//   figure out what's next. We can either rely on the systems registering new
//   transactions based on newly observed game state (would be great if this
//   would work), or we need to adjudicate there and then. If nothing else, we
//   need to do something about the animations and sounds already playing from
//   the cancelled transaction. Possibly we need to adjudicate for some
//   cancelled transactions, and can discard the rest, knowing that the systems
//   will attempt to redo them.
fn run_movement_system(
    temp_allocator: &Linear,
    entities: &mut IdMap<Entity, &Linear>,
    additional_movement_records: &[MovementRecord],
) {
    // Movement system moves entities with entity.movement != Movement::None. It
    // does this by generating first generating a list of records of all the
    // things that need moving, sorting this list based on movement_priority (a
    // sort of initiative), and finally executing the movements.
    //
    // Moving can have interactions with other entities. A moving entity can be
    // blocked, it can push another entity, it can continue moving involuntarily
    // if is standing on ice or levitating, etc.
    //
    // Pushing and being blocked is determined by the strength score of the
    // movement record. Each entity we attempt to push subtracts from the
    // strength score of our movement record. If we find a free spot before
    // loosing all strength, we manage to push. Otherwise, we are blocked
    // instead.
    //
    // When we push an entity, we loose our movement (even if we normally
    // wouldn't, like if we were on ice). This is to preserve energy through
    // perfectly inelastic collisions (Newton's Cradle).
    //
    // Sometimes we want to execute a movement with different properties than
    // those that would come from entity configuration or fields. This is done
    // with additional_movement_records, where we can provide our own values.
    //
    // TODO(yan): @LevelTopologies Moving something through level boundary
    // currently always blocks, but we will likely want wrapping levels and
    // level boundaries that remove entities instead in the future.

    let mut movement_records: Vec<MovementRecord, _> = Vec::new_in(temp_allocator);
    for (entity_id, entity) in entities.iter() {
        if let Ok(bearing) = Bearing::try_from(entity.movement) {
            // TODO(yan): Determine strenght based on whether the movement was
            // voluntary and originating from a supported position. An
            // ice-sliding wizard doesn't really have the same pushing strength
            // of a wizard standing firmly on solid ground.
            let strength = entity_strength(entity.ty).unwrap_or(0);

            movement_records.push(MovementRecord {
                entity_id,
                position: entity.position,
                bearing,
                priority: entity_movement_priority(entity.ty),
                strength,
            });
        }
    }

    movement_records.extend(additional_movement_records);

    // Sort slowest to quickest, we are going to use movement_records as a
    // stack. We'll be popping from the back and, and, in case of
    // support-triggered-pushes, also pushing to the back.
    movement_records.sort_unstable_by(|left, right| left.priority.cmp(&right.priority).reverse());
    while let Some(record) = movement_records.pop() {
        let has_key = match &entities[record.entity_id].data {
            EntityData::Wizard(data) => data.inventory.contains(&Some(Item::Key)),
            _ => false,
        };

        // Grid built inside the loop, because it needs to be reuilt everytime
        // something changes.
        let entity_grid = build_entity_grid(temp_allocator, entities);
        let mut push_records: ArrayVec<(Id, Bearing), 64> = ArrayVec::new();

        let mut search_distance = 1;
        let mut remaining_strength = record.strength;
        let can_move = loop {
            let position = record.position + IVec3::from(record.bearing) * search_distance;

            // TODO(yan): @LevelTopologies Other kinds of level boundary, e.g. wrapping.
            let mut blocked = !entity_grid.is_in_bounds(position);
            let mut found_occupied = false;
            if !blocked {
                for &(entity_id, entity_ty) in &entity_grid[position] {
                    let entity_weight = entity_weight(entity_ty);
                    if entity_weight > 0 {
                        if entity_ty == EntityType::KeyGate {
                            if entities[entity_id].data.unwrap_gate().open {
                                continue;
                            }

                            // If we are right next to the gate and have a key,
                            // allow the move as though it was unlocked.
                            if has_key && search_distance == 1 {
                                continue;
                            }
                        }

                        found_occupied = true;

                        if remaining_strength >= entity_weight {
                            remaining_strength -= entity_weight;

                            push_records.push((entity_id, record.bearing));
                        } else {
                            remaining_strength = 0;
                            blocked = true;
                        }
                    }
                }
            }

            if blocked {
                break false;
            }

            if !found_occupied {
                break true;
            }

            search_distance += 1;
        };

        if can_move {
            let entity = &mut entities[record.entity_id];
            entity.position_interpolation = Some(Vec3LinearInterpolation::new(
                entity.position.as_vec3(),
                entity.position.as_vec3() + IVec3::from(record.bearing).as_vec3(),
                POSITION_INTERPOLATION_DURATION_MOVE.as_secs_f32(),
            ));
            entity.position += IVec3::from(record.bearing);

            if !push_records.is_empty() {
                entity.movement = Movement::None;
            }

            if entity.support != Support::Levitate {
                entity.movement = Movement::None;
            }

            // If we support an entity, push a movement record for it so we can
            // process it directly after. If it supports any entities, a record
            // for those will be pushed once they are processed.
            if let Some(supports_id) = entity.supports_id {
                let supported = &entities[supports_id];
                movement_records.push(MovementRecord {
                    entity_id: supports_id,
                    position: supported.position,
                    bearing: record.bearing,
                    // Note: Not used. The stack is already sorted at this point.
                    priority: 0,
                    // TODO(yan): Re-evaluate the weight and strength of
                    // entities. What exactly does each of the mean? We are
                    // using weight here, because this entity didn't initiate
                    // anything.
                    strength: entity_weight(supported.ty),
                });
            }

            for (entity_id, bearing) in push_records {
                let entity = &mut entities[entity_id];
                entity.position_interpolation = Some(Vec3LinearInterpolation::new(
                    entity.position.as_vec3(),
                    entity.position.as_vec3() + IVec3::from(record.bearing).as_vec3(),
                    POSITION_INTERPOLATION_DURATION_MOVE.as_secs_f32(),
                ));
                entity.position += IVec3::from(bearing);

                if entity.support == Support::Levitate {
                    entity.movement = Movement::from(bearing);
                }

                // If we support an entity, push a movement record for it so we can
                // process it directly after. If it supports any entities, a record
                // for those will be pushed once they are processed.
                if let Some(supports_id) = entity.supports_id {
                    let supported = &entities[supports_id];
                    movement_records.push(MovementRecord {
                        entity_id: supports_id,
                        position: supported.position,
                        bearing: record.bearing,
                        // Note: Not used. The stack is already sorted at this point.
                        priority: 0,
                        // TODO(yan): Re-evaluate the weight and strength of
                        // entities. What exactly does each of the mean? We are
                        // using weight here, because this entity didn't initiate
                        // anything.
                        strength: entity_weight(supported.ty),
                    });
                }
            }
        } else {
            // TODO(yan): Blocked feedback.
            entities[record.entity_id].movement = Movement::None;
        }
    }
}

// TODO(yan): Split the support system into a *static* support system and a
// *dynamic* support system. The current (Aug 8th 2022) version is basically the
// static support system (with the exception of gates - more on this later).
//
// The static support system answers, whether the entity can potentially support
// us, (e.g. does that look like solid ground we can step on?) but can give us
// false positives (the ground is cracked and we fall through, if we step on
// it).
//
// Alloewed movement of player-controlled entities is determined by the static
// system. The system will allow the entity to move somewhere, if it can be
// statically supported there.
//
// The dynamic support system answers, whether an entity can really support
// another entity (e.g. does this character have enough strength to carry one
// another character, or crate, or whatever?). If not, the supporting entity is
// usually broken or killed, and the supported entity falls.
//
// Gates are a slight exception. They are conceptually part of the static
// support system, but it actually has to look at the "open" property to see if
// the gate is up and ready to support things. If it is, it should be able to
// support an infinite amount of entities, because it doesn't have strength
// defined.
fn run_support_system(
    temp_allocator: &Linear,
    entities: &mut IdMap<Entity, &Linear>,
    movement_traces: &mut Vec<MovementTrace, &Linear>,
) {
    // XXX: Gates should lift entities when closing

    let mut entity_grid = build_entity_grid(temp_allocator, entities);

    let grid_min = entity_grid.min();
    let grid_max = entity_grid.max();
    let mut support_grid: Grid<EntityTypes, _> =
        Grid::with_aabb_in(grid_min, grid_max, temp_allocator);

    for (_, entity) in entities.iter_mut() {
        entity.support = Support::Unknown;
        entity.supports_id = None;
    }

    //
    // Ground support pass
    //
    // Ground provides unconditional support to tiles above it, and requires no
    // support itself, allowing us to create flying islands as much as we want.
    //

    for z in grid_min.z..=grid_max.z {
        for y in grid_min.y..=grid_max.y {
            for x in grid_min.x..=grid_max.x {
                let position = ivec3(x, y, z);

                let mut has_ground = false;
                for &(_, entity_ty) in &entity_grid[position] {
                    if entity_ty == EntityType::Ground {
                        has_ground = true;
                    }
                }

                if has_ground {
                    support_grid[position] = EntityTypes::ALL;
                }
            }
        }
    }

    //
    // Water support pass
    //
    // Water provides unconditional support to buoyant entities, and - like
    // ground - requires no support itself, allowing us to create flying lakes,
    // rivers, etc.
    //
    // TODO(yan): Actually define some floaters. Also note that while classical
    // support supports the tile above the supporting entity, buoyant support
    // only supports entities occupying the same volume. How do we want to do
    // this? Perhaps we should make a secondary support_grid for buoyancy.
    //
    // const BUOYANT_ENTITY_TYPES: EntityTypes = EntityTypes::NONE;
    //

    //
    // Misc supporting entities pass
    //
    // Misc supporting entities are supported by ground as well as themselves
    // upwards. They do not support water, nor are they currently supported by
    // it, but this will likely change in the future (e.g. lilypads, bubbles,
    // etc).
    //

    // TODO(yan): @Cleanup This should be derived from somewhere more
    // global. Adding more entity types is error prone, if you forget to add
    // them here.

    // Note: @AddEntity
    const MISC_SUPPORTER: EntityTypes = EntityTypes::WIZARD
        | EntityTypes::TREE
        | EntityTypes::WOODEN_CRATE
        | EntityTypes::IRON_CRATE
        | EntityTypes::KEY_GATE
        | EntityTypes::TRANSPOSITION_STONE
        | EntityTypes::SUMMONING_STONE
        | EntityTypes::FAMILIAR_CAT
        | EntityTypes::SKELLY_WARRIOR
        | EntityTypes::SKELLY_ARCHER
        | EntityTypes::PRESSURE_PLATE_GATE;

    // Note: @AddEntity
    const MISC_SUPPORTEE: EntityTypes =
        MISC_SUPPORTER | EntityTypes::MANA_POTION | EntityTypes::KEY | EntityTypes::PRESSURE_PLATE;

    for z in grid_min.z..=grid_max.z {
        for y in grid_min.y..=grid_max.y {
            for x in grid_min.x..=grid_max.x {
                let position = ivec3(x, y, z);

                let mut has_misc_supporter = false;
                for &(entity_id, entity_ty) in &entity_grid[position] {
                    if entity_ty.to_entity_types().intersects(MISC_SUPPORTER) {
                        if entity_ty == EntityType::KeyGate {
                            if !entities[entity_id].data.unwrap_gate().open {
                                has_misc_supporter = true;
                            }
                        } else {
                            has_misc_supporter = true;
                        }
                    }
                }

                let has_support_for_misc_supporter =
                    z == grid_min.z || support_grid[position - IVec3::Z].intersects(MISC_SUPPORTER);

                // MISC_SUPPORTER provides support to MISC_SUPPORTEE, if it has
                // support itself.
                if has_support_for_misc_supporter && has_misc_supporter {
                    support_grid[position] |= MISC_SUPPORTEE;
                }
            }
        }
    }

    //
    // Apply gravity
    //

    let mut entity_grid_dirty = false;
    // Note: Starting from the bottom Z level here isn't just a convention - If
    // an entity falls, it may still be able to support entities above it after
    // it gains support. For this to happen, it must fall before things above it
    // do.
    for z in (grid_min.z + 1)..=grid_max.z {
        for y in grid_min.y..=grid_max.y {
            for x in grid_min.x..=grid_max.x {
                if entity_grid_dirty {
                    rebuild_entity_grid(&mut entity_grid, entities);
                    entity_grid_dirty = false;
                }

                let position = ivec3(x, y, z);

                for &(entity_id, entity_ty) in &entity_grid[position] {
                    let entity = &entities[entity_id];

                    if !entity_needs_support(entity_ty) {
                        let entity = &mut entities[entity_id];
                        entity.support = Support::Innate;

                        continue;
                    }

                    // TODO(yan): Shouldn't things that levitate support things
                    // too? Do we have to merge the misc support pass with the
                    // gravity pass for that to work?
                    if entity.status_effects.levitate > 0 {
                        let entity = &mut entities[entity_id];
                        entity.support = Support::Levitate;

                        continue;
                    }

                    let down_position = position - IVec3::Z;

                    let entity_tys = entity_ty.to_entity_types();
                    if entity_tys.intersects(support_grid[down_position]) {
                        let mut support_id: Option<Id> = None;
                        for &(id, ty) in &entity_grid[down_position] {
                            if entity_supports_tys(ty).intersects(entity_tys) {
                                support_id = Some(id);
                                break;
                            }
                        }

                        let support_id = support_id.unwrap();
                        match entities.get2_mut(entity_id, support_id) {
                            (Some(entity), Some(support)) => {
                                entity.support = Support::Entity(support_id);
                                support.supports_id = Some(entity_id);
                            }
                            _ => unreachable!(),
                        }

                        continue;
                    }

                    log::debug!(
                        "Entity {} ({:?}) starts fall at {}",
                        entity.id,
                        entity.ty,
                        entity.position,
                    );

                    let mut found_support: Option<(IVec3, Option<Id>)> = None;
                    for support_z in (0..z - 1).rev() {
                        let support_position = ivec3(x, y, support_z);

                        if entity_tys.intersects(support_grid[support_position]) {
                            let new_position = support_position + IVec3::Z;

                            let mut support_entity_id: Option<Id> = None;
                            for &(support_id, support_ty) in &entity_grid[support_position] {
                                if entity_supports_tys(support_ty).intersects(entity_tys) {
                                    support_entity_id = Some(support_id);
                                    break;
                                }
                            }

                            debug_assert!(support_entity_id.is_some());
                            found_support = Some((new_position, support_entity_id));

                            break;
                        }
                    }

                    let (mut new_position, support_entity_id) =
                        found_support.unwrap_or_else(|| (ivec3(x, y, 0), None));

                    log::info!(
                        "Entity {} ({:?}) fell from {} to {}",
                        entity.id,
                        entity.ty,
                        entity.position,
                        new_position,
                    );

                    // Every fall (even if we just fall one tile) is potentially
                    // a move over multiple tiles (because we likely got to an
                    // unsupported position by moving or teleporting). Later
                    // systems will only observe entities on tiles where the
                    // fall finishes, so we trace the entire path of the fall
                    // for them to study.
                    for fall_z in new_position.z..=entity.position.z {
                        movement_traces.push(MovementTrace {
                            entity_id: entity.id,
                            entity_ty: entity.ty,
                            position: ivec3(entity.position.x, entity.position.y, fall_z),
                        });
                    }

                    let fall_distance = entity.position.z - new_position.z;
                    debug_assert!(fall_distance > 0);

                    if fall_distance > 1 {
                        if let Some(support_entity_id) = support_entity_id {
                            let support_entity = &mut entities[support_entity_id];
                            match support_entity.ty {
                                EntityType::SkellyWarrior | EntityType::SkellyArcher => {
                                    log::debug!(
                                        "Drop-killing entity {support_entity_id}({}) at {}",
                                        support_entity.ty,
                                        support_entity.position,
                                    );

                                    support_entity.death_causes |= DeathCauses::DROPPED;

                                    // TODO(yan): @Correctness This is only ok
                                    // to do if there is not other supporter
                                    // here. If there can be only one physical
                                    // entity here (which is 99% what we have),
                                    // it works out.
                                    new_position -= IVec3::Z;
                                }
                                _ => (),
                            }
                        }
                    }

                    // TODO(yan): Emit animation command for the fall.
                    let entity = &mut entities[entity_id];
                    entity.position_interpolation = Some(Vec3LinearInterpolation::new(
                        entity.position.as_vec3(),
                        new_position.as_vec3(),
                        POSITION_INTERPOLATION_DURATION_FALL_BASE.as_secs_f32()
                            * fall_distance as f32,
                    ));

                    entity.position = new_position;
                    entity.support = match support_entity_id {
                        Some(support_entity_id) => Support::Entity(support_entity_id),
                        None => Support::LevelBounds,
                    };
                    if let Some(support_entity_id) = support_entity_id {
                        entities[support_entity_id].supports_id = Some(entity_id);
                    }

                    // TODO(yan): If we fall through water, we should stop
                    // falling once we are in water (Archimedes!) Important
                    // once we have water breathing and can levitate blocks of
                    // water.

                    // By falling down and changing our position, we update have
                    // to update both the entity grid and the support grid such
                    // that entities above us fall on our heads, instead of at
                    // our feet.
                    entity_grid_dirty = true;

                    // The support grid can be updated incrementally -
                    // because the MISC entity wasn't supported, it did not
                    // previously write to the support grid, and will only do so
                    // now, when it finds support.
                    if entity_tys.intersects(MISC_SUPPORTER) {
                        log::debug!("Support grid update at {new_position}");
                        support_grid[new_position] |= MISC_SUPPORTEE;
                    }
                }
            }
        }
    }
}

fn run_aggro_system(
    temp_allocator: &Linear,
    entities: &mut IdMap<Entity, &Linear>,
    movement_traces: &[MovementTrace],
) {
    struct AggroRecord {
        provoked_id: Id,
        provoker_id: Id,
        attack: bool,
        intercept_bearing: Bearing,
    }

    let entity_grid = build_entity_grid(temp_allocator, entities);
    let mut entities_to_kill: ArrayVec<(Id, DeathCauses), 32> = ArrayVec::new();
    let mut aggro_records: Vec<AggroRecord, _> = Vec::new_in(temp_allocator);

    for (entity_id, entity) in entities.iter() {
        // We do not clear existing aggro here, because the intercept system
        // both clears and potentially sets it.

        let aggro_tiles = match entity.ty {
            EntityType::SkellyWarrior => {
                // Warriors threaten and aggro on their neighboring tiles in
                // cardinal directions and, in addition, aggro on any tile that
                // can move into a threatened tile. Diagonal corner tiles are
                // checked in aggro intercept system.
                //
                // For multiple targets, score each provoking entity based on:
                //
                // - Whether it can be directly attacked
                //
                // - Distance between us and the provoker
                //
                // - Amount of turning required to make us face the provoker
                let mut aggro_tiles: Vec<(i32, i32, Bearing, bool, bool), &Linear> =
                    Vec::new_in(temp_allocator);

                aggro_tiles.push((
                    entity.position.x - 1,
                    entity.position.y,
                    Bearing::West,
                    true,
                    true,
                ));
                aggro_tiles.push((
                    entity.position.x - 2,
                    entity.position.y,
                    Bearing::West,
                    false,
                    false,
                ));
                aggro_tiles.push((
                    entity.position.x + 1,
                    entity.position.y,
                    Bearing::East,
                    true,
                    true,
                ));
                aggro_tiles.push((
                    entity.position.x + 2,
                    entity.position.y,
                    Bearing::East,
                    false,
                    false,
                ));
                aggro_tiles.push((
                    entity.position.x,
                    entity.position.y - 1,
                    Bearing::North,
                    true,
                    true,
                ));
                aggro_tiles.push((
                    entity.position.x,
                    entity.position.y - 2,
                    Bearing::North,
                    false,
                    false,
                ));
                aggro_tiles.push((
                    entity.position.x,
                    entity.position.y + 1,
                    Bearing::South,
                    true,
                    true,
                ));
                aggro_tiles.push((
                    entity.position.x,
                    entity.position.y + 2,
                    Bearing::South,
                    false,
                    false,
                ));

                Some(aggro_tiles)
            }
            EntityType::SkellyArcher => {
                // Archers threaten and aggro on any tile in any distance in the
                // cardinal directions (like rooks in chess) and, in addition,
                // aggro on any tile from which it is possible to move into a
                // threatened tile. Diagonal corner tiles are checked in aggro
                // intercept system.
                //
                // Same as for warriors, in case of multiple targets, score each
                // provoking entity based on:
                //
                // - Whether it can be directly attacked
                //
                // - Distance between us and the provoker
                //
                // - Amount of turning required to make us face the provoker
                let mut aggro_tiles: Vec<(i32, i32, Bearing, bool, bool), &Linear> =
                    Vec::new_in(temp_allocator);

                let grid_min = entity_grid.min();
                let grid_max = entity_grid.max();

                aggro_tiles.push((
                    entity.position.x - 1,
                    entity.position.y,
                    Bearing::West,
                    true,
                    true,
                ));

                for x in (grid_min.x..(entity.position.x - 1)).rev() {
                    aggro_tiles.push((x, entity.position.y, Bearing::West, true, false));
                    aggro_tiles.push((x, entity.position.y - 1, Bearing::West, false, false));
                    aggro_tiles.push((x, entity.position.y + 1, Bearing::West, false, false));
                }

                aggro_tiles.push((
                    entity.position.x + 1,
                    entity.position.y,
                    Bearing::East,
                    true,
                    true,
                ));

                for x in (entity.position.x + 2)..=grid_max.x {
                    aggro_tiles.push((x, entity.position.y, Bearing::East, true, false));
                    aggro_tiles.push((x, entity.position.y - 1, Bearing::East, false, false));
                    aggro_tiles.push((x, entity.position.y + 1, Bearing::East, false, false));
                }

                aggro_tiles.push((
                    entity.position.x,
                    entity.position.y - 1,
                    Bearing::South,
                    true,
                    true,
                ));

                for y in (grid_min.y..(entity.position.y - 1)).rev() {
                    aggro_tiles.push((entity.position.x, y, Bearing::South, true, false));
                    aggro_tiles.push((entity.position.x - 1, y, Bearing::South, false, false));
                    aggro_tiles.push((entity.position.x + 1, y, Bearing::South, false, false));
                }

                aggro_tiles.push((
                    entity.position.x,
                    entity.position.y + 1,
                    Bearing::North,
                    true,
                    true,
                ));

                for y in (entity.position.y + 2)..=grid_max.y {
                    aggro_tiles.push((entity.position.x, y, Bearing::North, true, false));
                    aggro_tiles.push((entity.position.x - 1, y, Bearing::North, false, false));
                    aggro_tiles.push((entity.position.x + 1, y, Bearing::North, false, false));
                }

                Some(aggro_tiles)
            }
            _ => None,
        };

        if let Some(aggro_tiles) = aggro_tiles {
            // Preserve aggro from intercept system.

            let aggro_id = match entity.data {
                EntityData::SkellyWarrior(data) => data.aggro_id,
                EntityData::SkellyArcher(data) => data.aggro_id,
                _ => unreachable!(),
            };

            if let Some(aggro_id) = aggro_id {
                aggro_records.push(AggroRecord {
                    provoked_id: entity_id,
                    provoker_id: aggro_id,
                    attack: false,
                    intercept_bearing: entity.bearing,
                })
            }

            let mut blocked = false;
            for (x, y, bearing, attack, reset_blocked) in aggro_tiles {
                if reset_blocked {
                    blocked = false;
                }

                let position = ivec3(x, y, entity.position.z);
                if entity_grid.is_in_bounds(position) {
                    let grid_cell = &entity_grid[position];
                    for &(id, ty) in grid_cell {
                        if !blocked {
                            if entity_attracts_aggro(ty) {
                                aggro_records.push(AggroRecord {
                                    provoked_id: entity_id,
                                    provoker_id: id,
                                    attack,
                                    intercept_bearing: bearing,
                                });
                            }
                        }

                        // We only aggro if there is possibility of attack,
                        // so only entities standing in the attacking/center
                        // lane can block us.
                        if attack && entity_blocks_arrows(&entities[id]) {
                            blocked = true;
                        }
                    }

                    if !blocked {
                        for movement_trace in movement_traces {
                            if movement_trace.position == position {
                                if entity_attracts_aggro(movement_trace.entity_ty) {
                                    aggro_records.push(AggroRecord {
                                        provoked_id: entity_id,
                                        provoker_id: movement_trace.entity_id,
                                        attack,
                                        intercept_bearing: bearing,
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    for aggro_records_by_provoked in
        aggro_records.group_by_mut(|l, r| l.provoked_id == r.provoked_id)
    {
        aggro_records_by_provoked.sort_unstable_by(|l, r| {
            let attack_cmp = l.attack.cmp(&r.attack).reverse();
            if attack_cmp != Ordering::Equal {
                return attack_cmp;
            }

            debug_assert!(l.provoked_id == r.provoked_id);
            let entity = &entities[l.provoked_id];
            let l_entity = &entities[l.provoker_id];
            let r_entity = &entities[r.provoker_id];
            let l_position = l_entity.position;
            let r_position = r_entity.position;

            let l_distance = entity
                .position
                .as_vec3()
                .distance_squared(l_position.as_vec3());
            let r_distance = entity
                .position
                .as_vec3()
                .distance_squared(r_position.as_vec3());

            let distance_cmp = cmp_f32(l_distance, r_distance);
            if distance_cmp != Ordering::Equal {
                return distance_cmp;
            }

            let l_bearing = l_entity.bearing;
            let r_bearing = r_entity.bearing;

            let l_turn_count = l_bearing.turn_count_between(l.intercept_bearing);
            let r_turn_count = r_bearing.turn_count_between(r.intercept_bearing);

            l_turn_count.cmp(&r_turn_count)
        });

        if let Some(aggro) = aggro_records_by_provoked.first() {
            let provoker_position = entities[aggro.provoker_id].position;
            let provoked = &mut entities[aggro.provoked_id];
            if let Some(bearing) = Bearing::try_from_ivec3(provoker_position - provoked.position) {
                provoked.bearing = bearing;
            }

            match &mut provoked.data {
                EntityData::SkellyWarrior(data) => {
                    data.aggro_id = Some(aggro.provoker_id);
                    if aggro.attack {
                        entities_to_kill.push((aggro.provoker_id, DeathCauses::SWORDED));
                    }
                }
                EntityData::SkellyArcher(data) => {
                    data.aggro_id = Some(aggro.provoker_id);
                    if aggro.attack {
                        entities_to_kill.push((aggro.provoker_id, DeathCauses::ARROWED));
                    }
                }
                _ => unreachable!(),
            }
        }
    }

    // Because we are not really super careful with movement traces, it is
    // possible the same entity will appear here multiple times, so anything we
    // do to entities here should be idempotent.
    //
    // TODO(yan): We should be more careful with movement traces, or move a
    // per-frame rule-evaluation system where we don't have this problem, but we
    // have more complicated ones.
    for (entity_id, death_causes) in entities_to_kill {
        let entity = &mut entities[entity_id];
        entity.death_causes |= death_causes;
    }
}

fn run_aggro_intercept_system(temp_allocator: &Linear, entities: &mut IdMap<Entity, &Linear>) {
    struct Intercept {
        provoker: Id,
        provoked: Id,
    }

    let entity_grid = build_entity_grid(temp_allocator, entities);
    let mut intercepts: ArrayVec<Intercept, 32> = ArrayVec::new();

    for (entity_id, entity) in entities.iter_mut() {
        match entity.ty {
            EntityType::SkellyWarrior | EntityType::SkellyArcher => {
                match entity.ty {
                    EntityType::SkellyWarrior => {
                        let data = entity.data.unwrap_skelly_warrior_mut();
                        data.aggro_id = None;
                    }
                    EntityType::SkellyArcher => {
                        let data = entity.data.unwrap_skelly_archer_mut();
                        data.aggro_id = None;
                    }
                    _ => unreachable!(),
                }

                for (x, y) in [
                    // Because the aggro intercept runs before movement, these
                    // are the positions from which it is possible to move into
                    // the position which triggers the intercept aggro.
                    (-2, -1),
                    (-1, -2),
                    (-2, 1),
                    (-1, 2),
                    (2, -1),
                    (1, -2),
                    (2, 1),
                    (1, 2),
                ] {
                    let position = entity.position + ivec3(x, y, 0);
                    if entity_grid.is_in_bounds(position) {
                        let grid_cell = &entity_grid[position];
                        for &(id, ty) in grid_cell {
                            if entity_attracts_aggro(ty) {
                                log::debug!("Intercept provoker {id} for {entity_id}");
                                intercepts.push(Intercept {
                                    provoker: id,
                                    provoked: entity_id,
                                });
                            }
                        }
                    }
                }
            }
            _ => (),
        }
    }

    for intercept in intercepts {
        let provoker = &entities[intercept.provoker];
        let provoker_position = provoker.position;
        let provoker_movement = provoker.movement;
        let provoker_dst = provoker_position + IVec3::from(provoker_movement);
        let provoker_dst_future = provoker_dst + IVec3::from(provoker_movement);

        // The entity can also aggro without moving, e.g. by falling,
        // teleporting, spawning, or whatever in that position. We could try
        // using its orientation to determine intercept bearing, but the
        // orientation maybe won't make sense, so we ignore it for now.
        //
        // TODO(yan): Do aggro intercept even for entities that suddenly
        // appear. Instead of turning to intercept, turn the aggroed entity so
        // to at least face generally towards the provoker.
        if provoker_position != provoker_dst {
            let provoked = &mut entities[intercept.provoked];
            if let Some(bearing) =
                Bearing::try_from_ivec3_strict(provoker_dst_future - provoked.position)
            {
                provoked.bearing = bearing;

                match provoked.ty {
                    EntityType::SkellyWarrior => {
                        let data = provoked.data.unwrap_skelly_warrior_mut();
                        data.aggro_id = Some(intercept.provoker);
                    }
                    EntityType::SkellyArcher => {
                        let data = provoked.data.unwrap_skelly_archer_mut();
                        data.aggro_id = Some(intercept.provoker);
                    }
                    _ => unreachable!(),
                }
            }
        }
    }
}

fn run_stone_activation_system(
    temp_allocator: &Linear,
    entities: &mut IdMap<Entity, &Linear>,
    wizard_entity_id: Option<Id>,
) -> Option<Id> {
    // TODO(yan): If multiple runes are in range, let the player pick
    // (e.g. with tab-cycling) and store the picked rune on the player
    // entity. For now we just pick the closest one (and randomly, if
    // distance is the same).

    let mut closest_stone_id_and_distance: Option<(Id, i32)> = None;

    if let Some(wizard_entity_id) = wizard_entity_id {
        let entity_grid = build_entity_grid(temp_allocator, entities);
        let wizard_entity_position = entities[wizard_entity_id].position;

        for x in -2..=2 {
            for y in -2..=2 {
                for z in -2..=2 {
                    let position = wizard_entity_position + ivec3(x, y, z);
                    if entity_grid.is_in_bounds(position) {
                        let grid_cell = &entity_grid[position];
                        for &(id, ty) in grid_cell {
                            let is_stone = match ty {
                                EntityType::TranspositionStone => true,
                                EntityType::SummoningStone => true,
                                _ => false,
                            };

                            if is_stone {
                                // Note: Manhattan distance
                                let distance = i32::abs(x) + i32::abs(y) + i32::abs(z);
                                if let Some((_, other_distance)) = closest_stone_id_and_distance {
                                    if distance < other_distance {
                                        closest_stone_id_and_distance = Some((id, distance));
                                    }
                                } else {
                                    closest_stone_id_and_distance = Some((id, distance));
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    for (_, entity) in entities.iter_mut() {
        match &mut entity.data {
            EntityData::TranspositionStone(data) => {
                data.active = false;
            }
            EntityData::SummoningStone(data) => {
                data.active = false;
            }
            _ => (),
        }
    }

    if let Some((closest_stone_id, _)) = closest_stone_id_and_distance {
        let entity = &mut entities[closest_stone_id];
        match &mut entity.data {
            EntityData::TranspositionStone(data) => {
                data.active = true;
            }
            EntityData::SummoningStone(data) => {
                data.active = true;
            }
            _ => unreachable!(),
        }
    }

    closest_stone_id_and_distance.map(|(id, _)| id)
}

fn run_status_effects_system(entities: &mut IdMap<Entity, &Linear>) {
    for (_, entity) in entities {
        entity.status_effects.levitate = entity.status_effects.levitate.saturating_sub(1);
    }
}

fn find_or_set_controlled_entity(entities: &mut IdMap<Entity, &Linear>) -> Option<Id> {
    let mut controlled_count = 0;

    let mut controlled_entity_id: Option<Id> = None;
    for (entity_id, entity) in entities.iter() {
        match entity.data {
            EntityData::Wizard(data) => {
                if data.controlled {
                    controlled_entity_id = Some(entity_id);
                    controlled_count += 1;
                }
            }
            EntityData::FamiliarCat(data) => {
                if data.controlled {
                    controlled_entity_id = Some(entity_id);
                    controlled_count += 1;
                }
            }
            _ => (),
        }
    }

    debug_assert!(controlled_count == 0 || controlled_count == 1);

    if controlled_count == 0 {
        for (entity_id, entity) in entities.iter_mut() {
            match &mut entity.data {
                EntityData::Wizard(data) => {
                    data.controlled = true;
                    controlled_entity_id = Some(entity_id);

                    break;
                }
                EntityData::FamiliarCat(data) => {
                    data.controlled = true;
                    controlled_entity_id = Some(entity_id);

                    break;
                }
                _ => (),
            }
        }
    }

    controlled_entity_id
}

fn set_controlled_entity(entities: &mut IdMap<Entity, &Linear>, id: Id, controlled: bool) {
    match &mut entities[id].data {
        EntityData::Wizard(data) => {
            data.controlled = controlled;
        }
        EntityData::FamiliarCat(data) => {
            data.controlled = controlled;
        }
        _ => unreachable!(),
    }
}

// TODO(yan): Consider unifying some of the concepts below. e.g. an entity can
// either be volume, or not, it can be small (not blocking spells) or not,
// etc. Maybe something like:
//
/*
pub enum EntityClass {
    Dynamic, <- Wizard, skellies, crates, stones, ...
    Static,  <- ground, water, trees, ...
    Marker,  <- exit
    Item,    <- key (maybe this is actually marker?)
}
*/

// TODO(yan): This should also become the part of the *dynamic* support
// system. Strength should also be the entity's carrying capacity, not just
// pushing strength. If an entity is breakable or can die, piling more things on
// its head than it can carry should break/kill the entity
// (DeathCauses::Crushed). This might need a revision of what strength is used
// for in the current movement system (Aug 8th 2022). If the returned strength
// is None, the entity doesn't participate in the dynamic support system (cannot
// be broken or killed by crushing), and its ability to support things is
// determined solely by the static support system.
const fn entity_strength(entity_ty: EntityType) -> Option<u8> {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => Some(1),
        EntityType::Exit => None,
        EntityType::Water => None,
        EntityType::Ground => None,
        EntityType::Tree => None,
        EntityType::WoodenCrate => Some(1),
        EntityType::IronCrate => Some(2),
        EntityType::Key => None,
        EntityType::KeyGate => None,
        EntityType::TranspositionStone => Some(1),
        EntityType::SummoningStone => Some(1),
        EntityType::FamiliarCat => Some(0),
        EntityType::SkellyWarrior => Some(0),
        EntityType::SkellyArcher => Some(0),
        EntityType::PressurePlate => None,
        EntityType::PressurePlateGate => None,
    }
}

const fn entity_needs_support(entity_ty: EntityType) -> bool {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => true,
        EntityType::Exit => false,
        EntityType::Water => false,
        EntityType::Ground => false,
        EntityType::Tree => true,
        EntityType::WoodenCrate => true,
        EntityType::IronCrate => true,
        EntityType::Key => true,
        EntityType::KeyGate => true,
        EntityType::TranspositionStone => true,
        EntityType::SummoningStone => true,
        EntityType::FamiliarCat => true,
        EntityType::SkellyWarrior => true,
        EntityType::SkellyArcher => true,
        EntityType::PressurePlate => true,
        EntityType::PressurePlateGate => true,
    }
}

const fn entity_supports_tys(entity_ty: EntityType) -> EntityTypes {
    // Note: @AddEntity
    const DYNAMIC: EntityTypes = EntityTypes::WIZARD
        | EntityTypes::TREE
        | EntityTypes::WOODEN_CRATE
        | EntityTypes::IRON_CRATE
        | EntityTypes::KEY
        | EntityTypes::KEY_GATE
        | EntityTypes::TRANSPOSITION_STONE
        | EntityTypes::SUMMONING_STONE
        | EntityTypes::FAMILIAR_CAT
        | EntityTypes::SKELLY_WARRIOR
        | EntityTypes::SKELLY_ARCHER
        | EntityTypes::KEY
        | EntityTypes::KEY_GATE;

    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => DYNAMIC,
        EntityType::Exit => EntityTypes::NONE,
        EntityType::Water => EntityTypes::NONE,
        EntityType::Ground => EntityTypes::ALL,
        EntityType::Tree => DYNAMIC,
        EntityType::WoodenCrate => DYNAMIC,
        EntityType::IronCrate => DYNAMIC,
        EntityType::Key => EntityTypes::NONE,
        EntityType::KeyGate => DYNAMIC,
        EntityType::TranspositionStone => DYNAMIC,
        EntityType::SummoningStone => DYNAMIC,
        EntityType::FamiliarCat => DYNAMIC,
        EntityType::SkellyWarrior => DYNAMIC,
        EntityType::SkellyArcher => DYNAMIC,
        EntityType::PressurePlate => EntityTypes::NONE,
        EntityType::PressurePlateGate => DYNAMIC,
    }
}

const fn entity_movement_priority(entity_ty: EntityType) -> i16 {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => 0,
        EntityType::Exit => i16::MAX,
        EntityType::Water => i16::MAX,
        EntityType::Ground => i16::MAX,
        EntityType::Tree => i16::MAX,
        EntityType::WoodenCrate => i16::MAX,
        EntityType::IronCrate => i16::MAX,
        EntityType::Key => i16::MAX,
        EntityType::KeyGate => i16::MAX,
        EntityType::TranspositionStone => i16::MAX,
        EntityType::SummoningStone => i16::MAX,
        EntityType::FamiliarCat => 0,
        EntityType::SkellyWarrior => i16::MAX,
        EntityType::SkellyArcher => i16::MAX,
        EntityType::PressurePlate => i16::MAX,
        EntityType::PressurePlateGate => i16::MAX,
    }
}

const fn entity_weight(entity_ty: EntityType) -> u8 {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => 1,
        EntityType::Exit => 0,
        EntityType::Water => 0,
        EntityType::Ground => u8::MAX,
        EntityType::Tree => u8::MAX,
        EntityType::WoodenCrate => 1,
        EntityType::IronCrate => 2,
        EntityType::Key => 0,
        EntityType::KeyGate => u8::MAX,
        EntityType::TranspositionStone => 1,
        EntityType::SummoningStone => 1,
        EntityType::FamiliarCat => 1,
        EntityType::SkellyWarrior => 1,
        EntityType::SkellyArcher => 1,
        EntityType::PressurePlate => 0,
        EntityType::PressurePlateGate => u8::MAX,
    }
}

const fn entity_can_drown(entity_ty: EntityType) -> bool {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => true,
        EntityType::Exit => false,
        EntityType::Water => false,
        EntityType::Ground => false,
        EntityType::Tree => false,
        EntityType::WoodenCrate => false,
        EntityType::IronCrate => false,
        EntityType::Key => false,
        EntityType::KeyGate => false,
        EntityType::TranspositionStone => false,
        EntityType::SummoningStone => false,
        EntityType::FamiliarCat => true,
        EntityType::SkellyWarrior => true,
        EntityType::SkellyArcher => true,
        EntityType::PressurePlate => false,
        EntityType::PressurePlateGate => false,
    }
}

const fn entity_attracts_aggro(entity_ty: EntityType) -> bool {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => true,
        EntityType::Exit => false,
        EntityType::Water => false,
        EntityType::Ground => false,
        EntityType::Tree => false,
        EntityType::WoodenCrate => false,
        EntityType::IronCrate => false,
        EntityType::Key => false,
        EntityType::KeyGate => false,
        EntityType::TranspositionStone => false,
        EntityType::SummoningStone => false,
        EntityType::FamiliarCat => true,
        EntityType::SkellyWarrior => false,
        EntityType::SkellyArcher => false,
        EntityType::PressurePlate => false,
        EntityType::PressurePlateGate => false,
    }
}

// XXX: Make a level for closed gates blocking arrows
const fn entity_blocks_arrows(entity: &Entity) -> bool {
    // Note: @AddEntity
    match &entity.data {
        EntityData::Wizard(_) => true,
        EntityData::Exit(_) => false,
        EntityData::Water(_) => true,
        EntityData::Ground(_) => true,
        EntityData::Tree(_) => true,
        EntityData::WoodenCrate(_) => true,
        EntityData::IronCrate(_) => true,
        EntityData::Key(_) => false,
        EntityData::KeyGate(data) => !data.open,
        EntityData::TranspositionStone(_) => true,
        EntityData::SummoningStone(_) => true,
        EntityData::FamiliarCat(_) => true,
        EntityData::SkellyWarrior(_) => true,
        EntityData::SkellyArcher(_) => true,
        EntityData::PressurePlate(_) => false,
        EntityData::PressurePlateGate(data) => !data.open,
    }
}

const fn entity_target_of_transposition(entity_ty: EntityType) -> bool {
    // Note: @AddEntity
    match entity_ty {
        EntityType::Wizard => true,
        EntityType::Exit => false,
        EntityType::Water => false,
        EntityType::Ground => false,
        EntityType::Tree => false,
        EntityType::WoodenCrate => true,
        EntityType::IronCrate => true,
        EntityType::Key => false,
        EntityType::KeyGate => false,
        EntityType::TranspositionStone => true,
        EntityType::SummoningStone => true,
        EntityType::FamiliarCat => true,
        EntityType::SkellyWarrior => true,
        EntityType::SkellyArcher => true,
        EntityType::PressurePlate => false,
        EntityType::PressurePlateGate => false,
    }
}

const fn entity_blocks_transposition(entity: &Entity) -> bool {
    // Note: @AddEntity
    match &entity.data {
        EntityData::Wizard(_) => true,
        EntityData::Exit(_) => false,
        EntityData::Water(_) => true,
        EntityData::Ground(_) => true,
        EntityData::Tree(_) => true,
        EntityData::WoodenCrate(_) => true,
        EntityData::IronCrate(_) => true,
        EntityData::Key(_) => false,
        EntityData::KeyGate(data) => !data.open,
        EntityData::TranspositionStone(_) => true,
        EntityData::SummoningStone(_) => true,
        EntityData::FamiliarCat(_) => true,
        EntityData::SkellyWarrior(_) => true,
        EntityData::SkellyArcher(_) => true,
        EntityData::PressurePlate(_) => false,
        EntityData::PressurePlateGate(data) => !data.open,
    }
}

const fn entity_blocks_summoning(entity: &Entity) -> bool {
    // Note: @AddEntity
    match &entity.data {
        EntityData::Wizard(_) => true,
        EntityData::Exit(_) => false,
        EntityData::Water(_) => true,
        EntityData::Ground(_) => true,
        EntityData::Tree(_) => true,
        EntityData::WoodenCrate(_) => true,
        EntityData::IronCrate(_) => true,
        EntityData::Key(_) => false,
        EntityData::KeyGate(data) => !data.open,
        EntityData::TranspositionStone(_) => true,
        EntityData::SummoningStone(_) => true,
        EntityData::FamiliarCat(_) => true,
        EntityData::SkellyWarrior(_) => true,
        EntityData::SkellyArcher(_) => true,
        // XXX: Write down that we want try a level for this!
        EntityData::PressurePlate(_) => false,
        EntityData::PressurePlateGate(data) => !data.open,
    }
}

fn create_missing_volume_anim(missing_anim: Animation) -> VolumeAnimation {
    VolumeAnimation {
        top: Some(missing_anim),
        top_directions: VolumeAnimationDirections::OUTWARD,
        top_offset: 0.0,
        sides: Some(missing_anim),
        sides_directions: VolumeAnimationDirections::OUTWARD,
        sides_offset: 0.0,
        bottom: Some(missing_anim),
        bottom_directions: VolumeAnimationDirections::OUTWARD,
        bottom_offset: 0.0,
    }
}
