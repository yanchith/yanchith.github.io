use alloc::vec::Vec;
use core::mem;

use hashbrown::hash_map::{DefaultHashBuilder, HashMap};
use lfg_alloc::Linear;
use lfg_common::static_assert;

use crate::asset::AssetId;
use crate::xraw::{
    self,
    XRawDataMut,
    XRawDataRef,
    XRawError,
    XRawHeader,
    XRAW_HEADER_ALIGN,
    XRAW_HEADER_SIZE,
};

#[derive(Debug)]
pub struct VolumeCatalog {
    catalog: HashMap<AssetId, usize, DefaultHashBuilder, &'static Linear>,
    // Note: u32 to maintain align4
    data: Vec<u32, &'static Linear>,
}

static_assert!(XRAW_HEADER_ALIGN == mem::align_of::<u32>());

impl VolumeCatalog {
    pub fn with_capacity_in(capacity: usize, allocator: &'static Linear) -> Self {
        Self {
            catalog: HashMap::with_capacity_in(capacity, allocator),
            data: Vec::with_capacity_in(capacity * 1024, allocator),
        }
    }

    pub fn insert(
        &mut self,
        volume_id: AssetId,
        header: &XRawHeader,
        data: XRawDataRef<'_>,
    ) -> Result<usize, XRawError> {
        let entry_byte_len = xraw::total_byte_len(header);
        let entry_byte_len_align = next_align4(entry_byte_len);
        debug_assert!(entry_byte_len_align % 4 == 0);

        let entry_u32_len = entry_byte_len_align / 4;

        let index = self.data.len();

        // Create space for the data we are going to fill in, including padding
        // so that the next entry is also aligned to 4. The padding is going to
        // be zeroed.

        self.data.resize(self.data.len() + entry_u32_len, 0);

        let slice = {
            let s: &mut [u8] = bytemuck::cast_slice_mut(&mut self.data[index..]);
            // Truncate to just byte_len - do not expose padding bytes for the
            // copying.
            &mut s[..entry_byte_len]
        };

        slice[..XRAW_HEADER_SIZE].copy_from_slice(bytemuck::bytes_of(header));

        let (voxel_bytes, color_bytes) = match data {
            XRawDataRef::VoxelIndexed8PaletteRgbaU8(voxels, colors) => {
                let voxel_bytes: &[u8] = voxels;
                let color_bytes: &[u8] = bytemuck::cast_slice(colors);

                (voxel_bytes, color_bytes)
            }
            XRawDataRef::VoxelIndexed16PaletteRgbaU8(voxels, colors) => {
                let voxel_bytes: &[u8] = bytemuck::cast_slice(voxels);
                let color_bytes: &[u8] = bytemuck::cast_slice(colors);

                (voxel_bytes, color_bytes)
            }
        };

        let voxel_byte_len = voxel_bytes.len();
        slice[XRAW_HEADER_SIZE..XRAW_HEADER_SIZE + voxel_byte_len].copy_from_slice(voxel_bytes);
        slice[XRAW_HEADER_SIZE + voxel_byte_len..].copy_from_slice(color_bytes);

        self.catalog.insert(volume_id, index);

        Ok(index)
    }

    // TODO(yan): Consider not copying the data from temporary storage into the
    // catalog, but rather just poking them directly here, with the ability to
    // roll back, if the data is invalid.
    pub fn insert_bytes(&mut self, volume_id: AssetId, bytes: &[u8]) -> Result<usize, XRawError> {
        let (header, _) = xraw::from_bytes(bytes)?;

        let entry_byte_len = xraw::total_byte_len(header);
        let entry_byte_len_align = next_align4(entry_byte_len);
        debug_assert!(entry_byte_len_align % 4 == 0);

        let entry_u32_len = entry_byte_len_align / 4;

        let index = self.data.len();

        // Create space for the data we are going to fill in, including padding
        // so that the next entry is also aligned to 4. The padding is going to
        // be zeroed.

        self.data.resize(self.data.len() + entry_u32_len, 0);

        let slice = {
            let s: &mut [u8] = bytemuck::cast_slice_mut(&mut self.data[index..]);
            // Truncate to just byte_len - do not expose padding bytes for the
            // copying.
            &mut s[..entry_byte_len]
        };

        slice.copy_from_slice(bytes);

        self.catalog.insert(volume_id, index);

        Ok(index)
    }

    pub fn get(&self, volume_id: AssetId) -> Option<(&XRawHeader, XRawDataRef<'_>)> {
        self.catalog
            .get(&volume_id)
            .map(|index| self.get_indexed(*index))
    }

    pub fn get_indexed(&self, index: usize) -> (&XRawHeader, XRawDataRef<'_>) {
        let bytes: &[u8] = bytemuck::cast_slice(&self.data[index..]);

        let header = xraw::header_from_bytes_unchecked(bytes);
        let data = xraw::data_from_bytes_header(&bytes[XRAW_HEADER_SIZE..], header).unwrap();

        (header, data)
    }

    pub fn get_indexed_mut(&mut self, index: usize) -> (&XRawHeader, XRawDataMut<'_>) {
        let bytes: &mut [u8] = bytemuck::cast_slice_mut(&mut self.data[index..]);

        let (header_bytes, data_bytes) = bytes.split_at_mut(XRAW_HEADER_SIZE);

        let header = xraw::header_from_bytes_unchecked(header_bytes);
        let data = xraw::data_from_bytes_header_mut(data_bytes, header).unwrap();

        (header, data)
    }
}

#[inline]
fn next_align4(n: usize) -> usize {
    const MASK: usize = 4 - 1;
    (n + MASK) & !MASK
}
