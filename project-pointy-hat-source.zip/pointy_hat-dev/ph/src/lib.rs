#![no_std]
// TODO(yan): So we are slowly painting ourselves into a nightly corner. Get rid
// of these once stabilized. Will they ever be? Do we care? At least do not add
// any nightlies that are not on the track to stable.
#![feature(allocator_api)]
#![feature(box_into_inner)]
#![feature(const_mut_refs)]
#![feature(const_num_from_num)]
#![feature(const_option)]
#![feature(const_trait_impl)]
#![feature(slice_group_by)]
// TODO(yan): See if we still need to allow these once we are done with the
// code. These are stylistic lints that that should improve readability, but
// following them blindly sometimes decreases it.
#![allow(clippy::collapsible_else_if)] // tag: style
#![allow(clippy::collapsible_if)] // tag: style
#![allow(clippy::comparison_chain)] // tag: style
#![allow(clippy::derive_partial_eq_without_eq)] // tag: style
#![allow(clippy::let_and_return)] // tag: style
#![allow(clippy::manual_map)] // tag: style
#![allow(clippy::match_like_matches_macro)] // tag: style
#![allow(clippy::single_match)] // tag: style

// IMPORTANT(yan):
//
// Going without liballoc in Rust would be a major dev pain and slowdown (no
// String, no Vec, no VecDeque, no BTreeMap). So we have liballoc (and
// hashbrown), but we should still treat memory allocation seriously! &'static
// [T] for unchanging memory and ArrayVec/ArrayString for cheap local
// allocations are friends. So is #![feature(allocator_api)] in conjunction with
// a temporary allocator. For longer-lived, seasonal data, consider Arena<T>.
//
// A tenative exception from this is the editor, which will (probably?) not be
// there for the final game.
extern crate alloc;

// Allow std if we are profiling so that tracy can send its thing.
#[cfg(feature = "ph_profile")]
extern crate std;

#[macro_use]
mod profile;

mod animation;
mod arena;
mod asset;
mod asset_catalog;
mod camera;
mod draw_list;
mod editor;
mod game;
mod gameplay;
mod grid;
mod history;
mod idmap;
mod input;
mod levelset_catalog;
mod time;
mod volume_catalog;
mod xraw;

// TODO(yan): @Speed @Memory Review if we use arenas and temporary allocators everywhere!

use alloc::vec::Vec;
use core::str;

use arrayvec::ArrayString;
use hashbrown::hash_map::{DefaultHashBuilder, Entry, HashMap};
use lfg_alloc::Linear;
use lfg_common::megabytes;
use ph_platform::{ColorBitDepth, ColorType, Platform};
use ph_renderer::{ColorSpace, Renderer, Sampler};

use crate::arena::Arena;
use crate::asset::{AssetId, AssetName, AssetReloadFlags, AssetType};
use crate::asset_catalog::{AssetCatalog, AssetManifestEntry, Texture, World};
use crate::editor::{Editor, EditorTransition};
use crate::game::{Game, GameTransition};
pub use crate::input::{Input, Key, KeyState, Mb};
use crate::levelset_catalog::{LevelsetCatalog, LevelsetEntry};
use crate::volume_catalog::VolumeCatalog;
use crate::xraw::{RgbaU8, XRawDataRef, XRawHeader, XRawTrimDirections};

enum Screen {
    Game,
    Editor,
    // TODO(yan): MainMenu
}

enum ScreenTransition {
    None,
    Game,
    GameWithLevel { level_id: AssetId },
    Editor,
    EditorWithLevel { level_id: AssetId },
}

pub struct PhState {
    temp_allocator: Linear,

    asset_catalog: Arena<AssetCatalog>,
    // TODO(yan): Add asset_reload_flags_queued once we thread asset loading so
    // that we don't load an asset multiple times.
    asset_reload_flags: AssetReloadFlags,

    screen: Screen,
    screen_transition: ScreenTransition,

    game: Game,
    editor: Editor,
}

pub fn init<P, R>(
    root_allocator: &mut Linear,
    platform: &P,
    renderer: &mut R,
    input: &Input,
) -> PhState
where
    P: Platform,
    R: Renderer,
{
    profile_scope!("ph::init");

    // This is a no_std compile check. Uncomment and compile this in isolation
    // to verify this crate isn't accidentally depending on std.
    //
    // let _ = f32::sin(1.0);

    log::info!("Initializing game state...");

    // TODO(yan): @Correctness. We currently never remove textures from the
    // renderer, so inserting our missing texture here is fine. If we ever start
    // removing textures from the renderer, we'll need to regenerate this.
    renderer.insert_texture_rgba8_unorm(
        asset::ID_MISSING_TEX.into_raw(),
        &[255, 0, 255, 255],
        1,
        1,
        ColorSpace::Linear,
        Sampler::Nearest,
    );

    let temp_allocator = root_allocator.split(megabytes(256)).unwrap();
    let asset_catalog = Arena::new(
        root_allocator.split(megabytes(128)).unwrap(),
        default_asset_catalog(),
    );

    let game = Game::new(root_allocator, &temp_allocator, platform, renderer, input);
    let editor = Editor::new(root_allocator, &temp_allocator, platform, renderer, input);

    PhState {
        temp_allocator,

        asset_catalog,
        asset_reload_flags: AssetReloadFlags::ALL,

        screen: Screen::Game,
        screen_transition: ScreenTransition::None,

        game,
        editor,
    }
}

pub fn update<P, R>(ph_state: &mut PhState, platform: &P, renderer: &mut R, input: &Input)
where
    P: Platform,
    R: Renderer,
{
    profile_scope!("ph::update");

    ph_state.temp_allocator.reset();

    // TODO(yan): Improve the asset bundle situation. If we are not in developer
    // mode, just load the asset bundle once and use it, or load the main chunk,
    // if it is split into chunks. If we are in developer mode, rebuild the
    // asset bundle or parts of it depending on the requested reload flags.
    //
    // TODO(yan): Also watch asset changes from OS and reload one by one?
    if ph_state.asset_reload_flags != AssetReloadFlags::NONE {
        log::info!("Reloading assets: {}", ph_state.asset_reload_flags);

        for (_, asset_ty, asset_name_str, asset_path_str) in asset::GENERATED_ASSETS {
            register_asset(
                asset_name_str,
                asset_path_str,
                *asset_ty,
                &mut ph_state.asset_catalog.manifest,
            );
        }

        if ph_state
            .asset_reload_flags
            .intersects(AssetReloadFlags::LEVELSETS)
        {
            // Create an implicit levelset containing all levels in our levels directory.
            match platform.list_files(&ph_state.temp_allocator, "./data/levels/", &["ph_level"]) {
                Ok(files) => {
                    let mut levelset_entries: Vec<LevelsetEntry, _> =
                        Vec::new_in(&ph_state.temp_allocator);

                    for f in files {
                        let file_path_str = str::from_utf8(&f.file_path).unwrap();
                        let (level_id, level_name) = register_asset(
                            str::from_utf8(&f.file_stem).unwrap(),
                            file_path_str,
                            AssetType::Level,
                            &mut ph_state.asset_catalog.manifest,
                        );

                        levelset_entries.push(LevelsetEntry {
                            level_id,
                            level_name,
                        });
                    }

                    ph_state.asset_catalog.levelsets_by_name.insert(
                        AssetName::new(asset::NAME_IMPLICIT_LEVELSET),
                        asset::ID_IMPLICIT_LEVELSET,
                    );
                    ph_state
                        .asset_catalog
                        .levelset_catalog
                        .insert(asset::ID_IMPLICIT_LEVELSET, &levelset_entries);
                }
                Err(err) => log::error!("Failed to list files in: ./data/levels/, error: {err}"),
            }

            match platform.list_files(
                &ph_state.temp_allocator,
                "./data/levelsets",
                &["ph_levelset"],
            ) {
                Ok(files) => {
                    for f in files {
                        let file_path_str = str::from_utf8(&f.file_path).unwrap();
                        let (levelset_id, levelset_name) = register_asset(
                            str::from_utf8(&f.file_stem).unwrap(),
                            file_path_str,
                            AssetType::Levelset,
                            &mut ph_state.asset_catalog.manifest,
                        );

                        match platform.read_file(&ph_state.temp_allocator, file_path_str) {
                            Ok(levelset_bytes) => match str::from_utf8(&levelset_bytes) {
                                Ok(levelset_str) => {
                                    let mut levelset_entries: Vec<LevelsetEntry, _> =
                                        Vec::new_in(&ph_state.temp_allocator);

                                    for line in levelset_str.lines() {
                                        // Skip comments
                                        if line.starts_with('#') {
                                            continue;
                                        }

                                        // Ignore empty lines
                                        if line.is_empty() {
                                            continue;
                                        }

                                        let line_trimmed = line.trim();

                                        let level_name = AssetName::new(line_trimmed);
                                        let mut level_path: ArrayString<256> =
                                            ArrayString::from("./data/levels/").unwrap();
                                        level_path.push_str(line_trimmed);
                                        level_path.push_str(".ph_level");
                                        let level_id = AssetId::new(&level_path);

                                        levelset_entries.push(LevelsetEntry {
                                            level_id,
                                            level_name,
                                        });
                                    }

                                    if levelset_entries.is_empty() {
                                        log::warn!("Levelset contains no levels");
                                    }

                                    ph_state
                                        .asset_catalog
                                        .levelsets_by_name
                                        .insert(levelset_name, levelset_id);
                                    ph_state
                                        .asset_catalog
                                        .levelset_catalog
                                        .insert(levelset_id, &levelset_entries);
                                }
                                Err(err) => log::error!(
                                    "Levelset file {file_path_str} contains invalid UTF8, error: \
                                     {err}"
                                ),
                            },
                            Err(err) => {
                                log::error!("Failed to read file: {file_path_str}, error: {err}");
                            }
                        }
                    }
                }
                Err(err) => log::error!("Failed to list files in: ./data/levelsets/, error: {err}"),
            }
        }

        if ph_state
            .asset_reload_flags
            .intersects(AssetReloadFlags::TEXTURES)
        {
            match platform.list_files(&ph_state.temp_allocator, "./data/images/", &["png"]) {
                Ok(files) => {
                    // TODO(yan): @Memory Do we want to clean unused textures
                    // from renderer memory after hot reloads?
                    for f in files {
                        let file_path_str = str::from_utf8(&f.file_path).unwrap();
                        let (texture_id, texture_name) = register_asset(
                            str::from_utf8(&f.file_stem).unwrap(),
                            file_path_str,
                            AssetType::Texture,
                            &mut ph_state.asset_catalog.manifest,
                        );

                        match platform.read_png(&ph_state.temp_allocator, file_path_str) {
                            Ok(image) => {
                                assert!(image.color_bit_depth == ColorBitDepth::D8);

                                let (image_data, image_width, image_height) = match image.color_type
                                {
                                    ColorType::Rgb => {
                                        log::debug!("Expanding RGB image to RGBA");

                                        let pixel_count =
                                            usize::from(image.width) * usize::from(image.height);

                                        assert!(image.data.len() % 3 == 0);
                                        assert!(image.data.len() / 3 == pixel_count);

                                        let rgba_len = image.data.len() / 3 * 4;
                                        let mut rgba = Vec::with_capacity_in(
                                            rgba_len,
                                            &ph_state.temp_allocator,
                                        );
                                        rgba.resize(rgba_len, 0);

                                        for i in 0..pixel_count {
                                            let rgb_index = i * 3;
                                            let rgba_index = i * 4;

                                            rgba[rgba_index] = image.data[rgb_index];
                                            rgba[rgba_index + 1] = image.data[rgb_index + 1];
                                            rgba[rgba_index + 2] = image.data[rgb_index + 2];
                                            rgba[rgba_index + 3] = 255;
                                        }

                                        (rgba, image.width, image.height)
                                    }
                                    ColorType::Rgba => (image.data, image.width, image.height),
                                };

                                // TODO(yan): Determine what kind of image this
                                // is based on asset tags (e.g. we need to know
                                // how to sample it, its color space,
                                // etc). Either we crawl the assets, or just
                                // load the asset tags before we load the
                                // assets, so we already have this knowledge at
                                // this point.
                                renderer.insert_texture_rgba8_unorm(
                                    texture_id.into_raw(),
                                    &image_data,
                                    image_width,
                                    image_height,
                                    ColorSpace::Srgb,
                                    Sampler::Nearest,
                                );

                                let texture = Texture {
                                    width: image_width,
                                    height: image_height,
                                };

                                ph_state
                                    .asset_catalog
                                    .textures_by_name
                                    .insert(texture_name, texture_id);
                                ph_state
                                    .asset_catalog
                                    .texture_catalog
                                    .insert(texture_id, texture);
                            }
                            Err(err) => {
                                log::error!(
                                    "Failed to read and decode image file: {file_path_str}, \
                                     error: {err}"
                                );
                            }
                        }
                    }
                }
                Err(err) => log::error!("Failed to list files in: ./data/images, error: {err}"),
            }
        }

        if ph_state
            .asset_reload_flags
            .intersects(AssetReloadFlags::VOLUMES)
        {
            match platform.list_files(&ph_state.temp_allocator, "./data/volumes/", &["xraw"]) {
                Ok(files) => {
                    for f in files {
                        let temp_scope = ph_state.temp_allocator.scope_checked();

                        let file_path_str = str::from_utf8(&f.file_path).unwrap();
                        let (volume_id, volume_name) = register_asset(
                            str::from_utf8(&f.file_stem).unwrap(),
                            file_path_str,
                            AssetType::Volume,
                            &mut ph_state.asset_catalog.manifest,
                        );

                        match platform.read_file_align4(&temp_scope, file_path_str) {
                            Ok(volume_bytes) => {
                                match ph_state
                                    .asset_catalog
                                    .volume_catalog
                                    .insert_bytes(volume_id, &volume_bytes)
                                {
                                    Ok(index) => {
                                        let (header, data_mut) = ph_state
                                            .asset_catalog
                                            .volume_catalog
                                            .get_indexed_mut(index);

                                        // TODO(yan): @AssetBuild Do not optimize assets
                                        // here, but make it an explicit asset loading
                                        // phase, or something..
                                        xraw::trim(
                                            &temp_scope,
                                            header,
                                            data_mut,
                                            XRawTrimDirections::TOP
                                                | XRawTrimDirections::LEFT
                                                | XRawTrimDirections::RIGHT
                                                | XRawTrimDirections::FRONT
                                                | XRawTrimDirections::BACK,
                                        )
                                        // Unwrap, because we just validated the data
                                        .unwrap();

                                        ph_state
                                            .asset_catalog
                                            .volumes_by_name
                                            .insert(volume_name, volume_id);
                                    }
                                    Err(err) => {
                                        log::error!(
                                            "Invalid XRAW volume file {file_path_str}. Error: \
                                             {err:?}"
                                        );
                                    }
                                }
                            }
                            Err(err) => {
                                log::error!("Failed to read file: {file_path_str}, error: {err}");
                            }
                        };

                        if !temp_scope.drop_and_report_can_restore() {
                            log::error!("Not reclaiming: temp allocator modified outside scope!");
                        }
                    }
                }
                Err(err) => log::error!("Failed to list files in: ./data/images, error: {err}"),
            }
        }

        if ph_state
            .asset_reload_flags
            .intersects(AssetReloadFlags::WORLD)
        {
            let file_path_str = "./data/main.ph_world";
            match platform.read_file(&ph_state.temp_allocator, "./data/main.ph_world") {
                Ok(world_bytes) => match str::from_utf8(&world_bytes) {
                    Ok(world_str) => {
                        let mut world_str_lines = world_str.lines();
                        if let Some(default_levelset_name_str) = world_str_lines.next() {
                            let default_levelset_name =
                                AssetName::new(default_levelset_name_str.trim());

                            if let Some(levelset_id) = ph_state
                                .asset_catalog
                                .levelsets_by_name
                                .get(&default_levelset_name)
                            {
                                ph_state.asset_catalog.world = World {
                                    default_levelset_id: *levelset_id,
                                };
                            } else {
                                log::warn!(
                                    "Levelsets do not contain the default levelset ({})",
                                    default_levelset_name,
                                );
                            }
                        }
                    }
                    Err(err) => log::error!(
                        "World file {file_path_str} contains invalid UTF8, error: {err}"
                    ),
                },
                Err(err) => {
                    log::error!("Failed to read file: {file_path_str}, error: {err}");
                }
            }
        }

        ph_state.asset_reload_flags = AssetReloadFlags::NONE;
    }

    match ph_state.screen_transition {
        ScreenTransition::None => (),
        ScreenTransition::Game => {
            ph_state.screen = Screen::Game;
            ph_state.screen_transition = ScreenTransition::None;
        }
        ScreenTransition::GameWithLevel { level_id } => {
            ph_state.game.open_level(&ph_state.asset_catalog, level_id);
            ph_state.screen = Screen::Game;
            ph_state.screen_transition = ScreenTransition::None;
        }
        ScreenTransition::Editor => {
            // TODO(yan): Add transition from game to editor that directly opens
            // the currently played level with Ctrl+F1
            ph_state.screen = Screen::Editor;
            ph_state.screen_transition = ScreenTransition::None;
        }
        ScreenTransition::EditorWithLevel { level_id } => {
            ph_state
                .editor
                .open_level(&ph_state.asset_catalog, level_id);
            ph_state.screen = Screen::Editor;
            ph_state.screen_transition = ScreenTransition::None;
        }
    }

    ph_state.asset_reload_flags = AssetReloadFlags::NONE;

    match ph_state.screen {
        Screen::Game => {
            let transition = ph_state.game.update(
                &ph_state.temp_allocator,
                platform,
                input,
                &ph_state.asset_catalog,
            );

            match transition {
                GameTransition::None => (),
                GameTransition::Editor => {
                    ph_state.screen_transition = ScreenTransition::Editor;
                }
                GameTransition::EditorWithLevel { level_id } => {
                    ph_state.screen_transition = ScreenTransition::EditorWithLevel { level_id };
                }
            }
        }
        Screen::Editor => {
            let transition = ph_state.editor.update(
                &ph_state.temp_allocator,
                platform,
                input,
                &ph_state.asset_catalog,
                &mut ph_state.asset_reload_flags,
            );

            match transition {
                EditorTransition::None => (),
                EditorTransition::Game => {
                    ph_state.screen_transition = ScreenTransition::Game;
                }
                EditorTransition::GameWithLevel { level_id } => {
                    ph_state.screen_transition = ScreenTransition::GameWithLevel { level_id };
                }
            }
        }
    }
}

pub fn render<R>(ph_state: &mut PhState, renderer: &mut R, input: &Input)
where
    R: Renderer,
{
    profile_scope!("ph::render");

    match ph_state.screen {
        Screen::Game => {
            ph_state.game.render(
                &ph_state.temp_allocator,
                renderer,
                input,
                &ph_state.asset_catalog,
            );
        }
        Screen::Editor => {
            ph_state.editor.render(
                &ph_state.temp_allocator,
                renderer,
                input,
                &ph_state.asset_catalog,
            );
        }
    }
}

fn register_asset(
    asset_name_str: &str,
    file_path: &str,
    asset_ty: AssetType,
    manifest: &mut HashMap<AssetId, AssetManifestEntry, DefaultHashBuilder, &Linear>,
) -> (AssetId, AssetName) {
    let asset_id = AssetId::new(file_path);
    let asset_name = AssetName::new(asset_name_str);

    log::debug!("Assigning asset id for path: {asset_id} ({asset_ty}) {file_path}");

    match manifest.entry(asset_id) {
        Entry::Occupied(mut entry) => {
            let manifest_entry = entry.get();
            if manifest_entry.ty != asset_ty {
                log::error!(
                    "Asset ID conflict: asset {} changed type from {} to {} in hot reload",
                    asset_id,
                    manifest_entry.ty,
                    asset_ty,
                );
            }
            if manifest_entry.name != asset_name {
                log::error!(
                    "Asset ID conflict: asset {} changed name from {} to {} in hot reload",
                    asset_id,
                    manifest_entry.name,
                    asset_name,
                );
            }

            entry.insert(AssetManifestEntry {
                ty: asset_ty,
                id: asset_id,
                name: asset_name,
            });
        }
        Entry::Vacant(entry) => {
            entry.insert(AssetManifestEntry {
                ty: asset_ty,
                id: asset_id,
                name: asset_name,
            });
        }
    }

    (asset_id, asset_name)
}

fn default_asset_catalog() -> impl Fn(&'static Linear) -> AssetCatalog {
    static MISSING_TEXTURE: Texture = Texture {
        width: 1,
        height: 1,
    };

    static MISSING_VOLUME_HEADER: XRawHeader = XRawHeader {
        magic: xraw::XRAW_MAGIC_NUMBER,
        color_type: xraw::XRAW_COLOR_TYPE_UINT,
        color_channel_count: xraw::XRAW_COLOR_CHANNEL_COUNT_RGBA,
        color_bits: xraw::XRAW_COLOR_BITS_8,
        index_bits: xraw::XRAW_INDEX_BITS_8,

        size_x: 1,
        size_y: 1,
        size_z: 1,

        palette_size: xraw::XRAW_PALETTE_COLOR_8,
    };

    static MISSING_VOLUME_VOXELS: &[u8] = &[1u8];
    static MISSING_VOLUME_COLORS: &[RgbaU8] =
        &[RgbaU8([255, 0, 255, 100]); xraw::XRAW_PALETTE_COLOR_8 as usize];

    static MISSING_VOLUME_DATA: XRawDataRef<'static> =
        XRawDataRef::VoxelIndexed8PaletteRgbaU8(MISSING_VOLUME_VOXELS, MISSING_VOLUME_COLORS);

    // TODO(yan): @Memory @Correctness Instead of sharing the same allocator and
    // suffering reallocations on failed grows, we should split the allocator
    // OR, preferably, have a collection that can gracefully handle growing with
    // bump-allocators, such as Slab from the_machinery, and base our own
    // collections (arrays, dictionaries, deques) on top of that and have
    // SlabArray (or just Slab), SlabTable, and SlabDeque.
    //
    // TODO(yan): @Memory @Correctness Do not set capacities and instead do the
    // above.
    const CAP_LEVELS: usize = 200;
    const CAP_LEVELSETS: usize = 50;
    const CAP_TEXTURES: usize = 100;
    const CAP_VOLUMES: usize = 100;
    const CAP_ALL: usize = CAP_LEVELS + CAP_LEVELSETS + CAP_TEXTURES + CAP_VOLUMES;

    move |allocator| {
        let mut textures_by_name = HashMap::with_capacity_in(CAP_TEXTURES, allocator);
        let mut texture_catalog = HashMap::with_capacity_in(CAP_TEXTURES, allocator);
        textures_by_name.insert(
            AssetName::new(asset::NAME_MISSING_TEX),
            asset::ID_MISSING_TEX,
        );
        texture_catalog.insert(asset::ID_MISSING_TEX, MISSING_TEXTURE);

        let mut volumes_by_name = HashMap::with_capacity_in(CAP_VOLUMES, allocator);
        let mut volume_catalog = VolumeCatalog::with_capacity_in(CAP_VOLUMES, allocator);
        volumes_by_name.insert(
            AssetName::new(asset::NAME_MISSING_VOLUME),
            asset::ID_MISSING_VOLUME,
        );
        volume_catalog
            .insert(
                asset::ID_MISSING_VOLUME,
                &MISSING_VOLUME_HEADER,
                MISSING_VOLUME_DATA,
            )
            .unwrap();

        let data = AssetCatalog {
            world: World {
                default_levelset_id: asset::ID_IMPLICIT_LEVELSET,
            },

            manifest: HashMap::with_capacity_in(CAP_ALL, allocator),

            levelsets_by_name: HashMap::with_capacity_in(CAP_LEVELSETS, allocator),
            textures_by_name,
            volumes_by_name,

            levelset_catalog: LevelsetCatalog::with_capacity_in(CAP_LEVELSETS, allocator),
            texture_catalog,
            volume_catalog,
        };

        data
    }
}
