use alloc::collections::vec_deque::{Drain, VecDeque};
use alloc::vec::Vec;
use core::alloc::Allocator;
use core::fmt;

use lfg_alloc::Linear;
use lfg_common::cast_u16;

use crate::idmap::{Entry, Id, IdMap};

// TODO(yan): @Memory Can we compress this stream? How do we design it such that
// it is better suited for compression?
//
// TODO(yan): Make sure we can serialize this, because we might want this to end
// up in a save file eventually, potentially compressed.
//
// TODO(yan): Fuzz History with property tests!

#[derive(Debug, Clone, Copy)]
pub enum HistoryChange<T: PartialEq + Copy> {
    Insert { id: Id, value: T },
    Delete { id: Id, value: T },
}

#[derive(Debug)]
pub enum HistoryError {
    OutOfMemory { needed: usize, have: usize },
}

#[derive(Debug)]
pub struct History<T: fmt::Debug + Copy + PartialEq, A: Allocator + Clone> {
    capacity: usize,
    changes: VecDeque<HistoryChange<T>, A>,
    change_counts: VecDeque<usize, A>,
    // Cursor from the end of change counts: 0 means last transaction would be
    // undone with History::move_transaction_cursor_back, 1 means second to
    // last, etc.
    change_counts_cursor: usize,
    // How many commulative changes are between cursor and end. If one
    // transaction was undone, this is the change count of that transaction.
    change_count_at_cursor: usize,
}

impl<T: fmt::Debug + Copy + PartialEq, A: Allocator + Clone> History<T, A> {
    pub fn new_in(allocator: A) -> Self {
        Self {
            capacity: 0,
            changes: VecDeque::new_in(allocator.clone()),
            change_counts: VecDeque::new_in(allocator),
            change_counts_cursor: 0,
            change_count_at_cursor: 0,
        }
    }

    pub fn with_capacity_in(capacity: usize, allocator: A) -> Self {
        Self {
            // Tracking capacity separately, because Vec and VecDeque capacity
            // can't be trusted.
            capacity,
            // By default we give enough capacity to trasactions such that every
            // change can be its own transaction, so neither Vec needs to grow,
            // ever.
            changes: VecDeque::with_capacity_in(capacity, allocator.clone()),
            change_counts: VecDeque::with_capacity_in(capacity, allocator),
            change_counts_cursor: 0,
            change_count_at_cursor: 0,
        }
    }

    /// Pushes a transaction with potentially multiple changes.
    ///
    /// If the transaction cursor is not at the end of the change stream, this
    /// hoses any transaction data between the cursor and the end and moves the
    /// cursor to the end.
    ///
    /// A transaction is only pushed if there is an actual difference between
    /// `src` and `dst`.
    ///
    /// The changeset is computed as a difference between `src` and `dst`
    /// [`IdMap`]s, respecting their internal slots.
    ///
    /// Also, because [`Self`] is designed to work with [`IdMap`]s, deletions to
    /// the same slot go before insertions, so that when the diff is applied,
    /// there's no conflict in the [`IdMap`].
    ///
    /// Memory usage of [`Self`] never grows. Instead the functionality
    /// gracefully degrades if it has insufficient memory.
    ///
    /// - If there is not enough space to push the current transaction, but
    ///   there would be if history were empty, oldest transactions are evicted
    ///   from the history until there's enough space to insert the new one.
    ///
    /// - If there is not enough space to push the current transaction even if
    ///   the history were empty, the transaction is not pushed and history is
    ///   cleared to prevent inconsistent behavior when popping transactions.
    pub fn push_transaction<SA: Allocator, DA: Allocator>(
        &mut self,
        temp_allocator: &Linear,
        src: &IdMap<T, SA>,
        dst: &IdMap<T, DA>,
    ) -> Result<(usize, usize, usize), HistoryError> {
        profile_scope!("History::push_transaction");

        let changes_capacity_orig = self.changes.capacity();
        let change_counts_capacity_orig = self.change_counts.capacity();

        // Hose all changes between cursor and end
        let hosed_count = self.change_count_at_cursor;

        while self.change_counts_cursor > 0 {
            let mut pop_count = self.change_counts.pop_back().unwrap();

            while pop_count > 0 {
                self.changes.pop_back().unwrap();
                self.change_count_at_cursor -= 1;

                pop_count -= 1;
            }

            self.change_counts_cursor -= 1;
        }

        debug_assert!(self.change_counts_cursor == 0);
        debug_assert!(self.change_count_at_cursor == 0);

        // This happens in 3 phases:
        //
        // 1) Compute the diff into, allocating into provided scratch space.
        //
        // 2) Perform maintenance and ensure there is enough space for the
        //    current diff.
        //
        // 3) Insert current diff.

        if src == dst {
            return Ok((0, 0, hosed_count));
        }

        let mut new_changes = Vec::new_in(temp_allocator);
        for (src_entry, dst_entry) in src.iter_entries().zip(dst.iter_entries()) {
            match (&src_entry, &dst_entry) {
                (&Entry::Vacant(_), &Entry::Vacant(_)) => (),
                (&Entry::Vacant(_), &Entry::Occupied(id, entity)) => {
                    new_changes.push(HistoryChange::Insert { id, value: *entity });
                }
                (&Entry::Occupied(id, entity), &Entry::Vacant(_)) => {
                    new_changes.push(HistoryChange::Delete { id, value: *entity });
                }
                (&Entry::Occupied(src_id, src_entity), &Entry::Occupied(dst_id, dst_entity)) => {
                    // These are organized such that the deletes to the same
                    // slot happen first, so we can use
                    // IdMap::insert_at_vacant_entry and have the entries become
                    // vacant first.
                    if src_entity != dst_entity {
                        new_changes.push(HistoryChange::Delete {
                            id: src_id,
                            value: *src_entity,
                        });
                        new_changes.push(HistoryChange::Insert {
                            id: dst_id,
                            value: *dst_entity,
                        });
                    }
                }
            }
        }

        if src.entry_len() > dst.entry_len() {
            let start = dst.entry_len();
            let end = src.entry_len();

            for i in start..end {
                if let Some(id) = src.get_id_at_idx(cast_u16!(i)) {
                    let entity = &src[id];
                    new_changes.push(HistoryChange::Delete { id, value: *entity });
                }
            }
        } else if dst.entry_len() > src.entry_len() {
            let start = src.entry_len();
            let end = dst.entry_len();

            for i in start..end {
                if let Some(id) = dst.get_id_at_idx(cast_u16!(i)) {
                    let entity = &dst[id];
                    new_changes.push(HistoryChange::Insert { id, value: *entity });
                }
            }
        }

        // History promises never to outgrow the memory it was given. If there
        // is not enough space, we pop transactions from the front to make
        // space.
        //
        // However, if there is not enough space to hold the current transaction
        // even if the history was entirely empty, we *gracefully* degrade by
        // hosing the history. This may seem extreme, but making the history
        // inconsistent by only remembering some transactions seems worse.
        if new_changes.len() > self.capacity {
            self.changes.clear();
            self.change_counts.clear();

            return Err(HistoryError::OutOfMemory {
                needed: new_changes.len(),
                have: self.capacity,
            });
        }

        let mut forgot_count = 0;
        while self.changes.len() + new_changes.len() > self.capacity {
            // The current transaction does not fit, but we know it would fit at
            // least if the history was empty. We try forgetting old
            // transactions until it there is enough space for the new one.

            debug_assert!(!self.changes.is_empty());
            debug_assert!(!self.change_counts.is_empty());

            let forget_change_count = self.change_counts.pop_front().unwrap();
            self.changes.drain(..forget_change_count);

            forgot_count += forget_change_count;
        }

        debug_assert!(self.changes.len() + new_changes.len() <= self.capacity);

        let change_count = new_changes.len();
        self.changes.extend(new_changes);
        self.change_counts.push_back(change_count);

        // Check we didn't accidentally resize despite our efforts.
        //
        // TODO(yan): @Bug The following happened while messing around in editor.
        //
        // thread 'main' panicked at 'assertion failed: self.change_counts.capacity() == capacity'
        // ph\src\history.rs:421:9
        //
        // UPDATE: This might be fixed now (could have been related to another
        // fixed bug), but I can't be sure.
        debug_assert!(self.changes.capacity() == changes_capacity_orig);
        debug_assert!(self.change_counts.capacity() == change_counts_capacity_orig);

        Ok((change_count, forgot_count, hosed_count))
    }

    pub fn pop_transaction(&mut self) -> Option<Drain<'_, HistoryChange<T>, A>> {
        // Popping with cursor not at the end would not make sense. Cursor
        // movement will only be called from editor, and popping will only be
        // done in gameplay.
        assert!(self.change_counts_cursor == 0);
        // Just a sanity check
        debug_assert!(self.change_count_at_cursor == 0);

        if let Some(change_count) = self.change_counts.pop_back() {
            let start = self.changes.len() - change_count;
            Some(self.changes.drain(start..))
        } else {
            debug_assert!(self.changes.is_empty());
            None
        }
    }

    pub fn move_transaction_cursor_back(&mut self) -> Option<&[HistoryChange<T>]> {
        if self.change_counts_cursor + 1 > self.change_counts.len() {
            debug_assert!(self.change_count_at_cursor == self.changes.len());
            None
        } else {
            let changes_len = self.changes.len();
            let change_counts_len = self.change_counts.len();

            let slice = self.changes.make_contiguous();

            let idx = change_counts_len - self.change_counts_cursor - 1;
            let change_count = self.change_counts.get(idx).unwrap();
            let start = changes_len - self.change_count_at_cursor - change_count;
            let end = changes_len - self.change_count_at_cursor;

            self.change_counts_cursor += 1;
            self.change_count_at_cursor += change_count;

            Some(&slice[start..end])
        }
    }

    pub fn move_transaction_cursor_forward(&mut self) -> Option<&[HistoryChange<T>]> {
        if self.change_counts_cursor == 0 {
            debug_assert!(self.change_count_at_cursor == 0);
            None
        } else {
            let changes_len = self.changes.len();
            let change_counts_len = self.change_counts.len();

            let slice = self.changes.make_contiguous();

            let idx = change_counts_len - self.change_counts_cursor;
            let change_count = self.change_counts.get(idx).unwrap();
            let start = changes_len - self.change_count_at_cursor;
            let end = changes_len - self.change_count_at_cursor + change_count;

            self.change_counts_cursor -= 1;
            self.change_count_at_cursor -= change_count;

            Some(&slice[start..end])
        }
    }
}

// Manual implementation of Clone necessary, because VecDeque::clone (and also
// probably Vec::clone) does not preserve capacity, only data and length, and we
// really need to know exact capacities, because we are asserting we never grow.
impl<T: fmt::Debug + Copy + PartialEq, A: Allocator + Clone> Clone for History<T, A> {
    fn clone(&self) -> Self {
        let capacity = self.capacity;
        let changes_allocator = self.changes.allocator().clone();
        let change_counts_allocator = self.change_counts.allocator().clone();
        let changes = VecDeque::with_capacity_in(capacity, changes_allocator);
        let change_counts = VecDeque::with_capacity_in(capacity, change_counts_allocator);

        Self {
            capacity,
            changes,
            change_counts,
            change_counts_cursor: self.change_counts_cursor,
            change_count_at_cursor: self.change_count_at_cursor,
        }
    }
}
