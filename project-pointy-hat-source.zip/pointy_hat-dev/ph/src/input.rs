use core::fmt;
use core::time::Duration;

use arrayvec::ArrayVec;
use lfg_math::{UVec2, Vec2};

#[derive(Debug)]
pub struct Input {
    pub dtime: Duration,

    pub window_scale_factor: f32,
    pub physical_window_size: UVec2,
    pub physical_cursor_position: Vec2,
    pub physical_scroll_delta: Vec2,
    // Note: Not inferred from cursor position, as this is FPS-like, and we want
    // to capture it even if cursor is not above our window.
    pub mouse_motion: Vec2,

    pub keys: ArrayVec<(Key, KeyState), 32>,
    pub mbs: ArrayVec<(Mb, KeyState), 32>,
    pub chars: ArrayVec<char, 32>,
}

#[rustfmt::skip]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Key {
    // TODO(yan): Gamepad.

    // Number keys.
    Num1, Num2, Num3, Num4, Num5, Num6, Num7, Num8, Num9, Num0,

    // Alpha keys.
    A, B, C, D, E, F, G, H, I, J, K, L, M, N, O, P, Q, R, S, T, U, V, W, X, Y, Z,

    // Punctuation.
    Grave, Equals, Minus, LBracket, RBracket, Backslash, Semicolon, Apostrophe, Comma, Period, Slash,

    // F keys.
    F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12,

    // Arrow keys.
    Up, Down, Left, Right,

    // Control characters.
    Backspace, Return, Space, Tab, Esc, Insert, Home, Delete, End, PageUp, PageDown,

    // Modifiers.
    Control, Alt, Shift,
}

impl fmt::Display for Key {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Num0 => "0".fmt(f),
            Self::Num1 => "1".fmt(f),
            Self::Num2 => "2".fmt(f),
            Self::Num3 => "3".fmt(f),
            Self::Num4 => "4".fmt(f),
            Self::Num5 => "5".fmt(f),
            Self::Num6 => "6".fmt(f),
            Self::Num7 => "7".fmt(f),
            Self::Num8 => "8".fmt(f),
            Self::Num9 => "9".fmt(f),

            Self::A => "a".fmt(f),
            Self::B => "b".fmt(f),
            Self::C => "c".fmt(f),
            Self::D => "d".fmt(f),
            Self::E => "e".fmt(f),
            Self::F => "f".fmt(f),
            Self::G => "g".fmt(f),
            Self::H => "h".fmt(f),
            Self::I => "i".fmt(f),
            Self::J => "j".fmt(f),
            Self::K => "k".fmt(f),
            Self::L => "l".fmt(f),
            Self::M => "m".fmt(f),
            Self::N => "n".fmt(f),
            Self::O => "o".fmt(f),
            Self::P => "p".fmt(f),
            Self::Q => "q".fmt(f),
            Self::R => "r".fmt(f),
            Self::S => "s".fmt(f),
            Self::T => "t".fmt(f),
            Self::U => "u".fmt(f),
            Self::V => "v".fmt(f),
            Self::W => "w".fmt(f),
            Self::X => "x".fmt(f),
            Self::Y => "y".fmt(f),
            Self::Z => "z".fmt(f),

            Self::Grave => "`".fmt(f),
            Self::Equals => "=".fmt(f),
            Self::Minus => "-".fmt(f),
            Self::LBracket => "[".fmt(f),
            Self::RBracket => "]".fmt(f),
            Self::Backslash => "\\".fmt(f),
            Self::Semicolon => ";".fmt(f),
            Self::Apostrophe => "'".fmt(f),
            Self::Comma => ",".fmt(f),
            Self::Period => ".".fmt(f),
            Self::Slash => "/".fmt(f),

            Self::F1 => "<f1>".fmt(f),
            Self::F2 => "<f2>".fmt(f),
            Self::F3 => "<f3>".fmt(f),
            Self::F4 => "<f4>".fmt(f),
            Self::F5 => "<f5>".fmt(f),
            Self::F6 => "<f6>".fmt(f),
            Self::F7 => "<f7>".fmt(f),
            Self::F8 => "<f8>".fmt(f),
            Self::F9 => "<f9>".fmt(f),
            Self::F10 => "<f10>".fmt(f),
            Self::F11 => "<f11>".fmt(f),
            Self::F12 => "<f12>".fmt(f),

            Self::Up => "<up>".fmt(f),
            Self::Down => "<down>".fmt(f),
            Self::Left => "<left>".fmt(f),
            Self::Right => "<right>".fmt(f),

            Self::Backspace => "<backspace>".fmt(f),
            Self::Return => "<return>".fmt(f),
            Self::Space => "<space>".fmt(f),
            Self::Tab => "<tab>".fmt(f),
            Self::Esc => "<esc>".fmt(f),
            Self::Insert => "<insert>".fmt(f),
            Self::Home => "<home>".fmt(f),
            Self::Delete => "<delete>".fmt(f),
            Self::End => "<end>".fmt(f),
            Self::PageUp => "<pgup>".fmt(f),
            Self::PageDown => "<pgdown>".fmt(f),

            Self::Control => "<ctrl>".fmt(f),
            Self::Alt => "<alt>".fmt(f),
            Self::Shift => "<shift>".fmt(f),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Mb {
    Left,
    Right,
    Middle,
}

impl fmt::Display for Mb {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Self::Left => "MB-Left".fmt(f),
            Self::Right => "MB-Right".fmt(f),
            Self::Middle => "MB-Middle".fmt(f),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum KeyState {
    Press,
    Release,
}

impl fmt::Display for KeyState {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Self::Press => "PRESS".fmt(f),
            Self::Release => "RELEASE".fmt(f),
        }
    }
}
