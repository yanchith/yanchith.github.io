//! This is heavily inspired by the
//! [generational-arena](https://docs.rs/generational-arena/) crate, but also
//! simplified - we removed some features and bugs, and may add others.

use alloc::vec::Vec;
use core::alloc::Allocator;
use core::fmt;
use core::iter;
use core::mem;
use core::num::NonZeroU16;
use core::ops::{Index, IndexMut};
use core::slice;
use core::str::FromStr;

use lfg_common::{cast_u16, static_assert};

// Starts at 1, because we construct NonZeroU16 from it.
const INITIAL_GEN: NonZeroU16 = NonZeroU16::new(1).unwrap();
const ONE_PAST_MAX_GEN: NonZeroU16 = NonZeroU16::new(u16::MAX).unwrap();

// TODO(yan): Fuzz IdMap with property tests!

// TODO(yan): @Correctness Id::gen might be too small and Id::idx too large. We
// could pack them together and rebalance the bits (would require fields not
// being pub), or increase both to 32-bit.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Id {
    idx: u16,
    // Nonzero, so that Id has a niche and Option<Id> has the same size as Id.
    gen: NonZeroU16,
}

static_assert!(mem::size_of::<Id>() == 4);
static_assert!(mem::size_of::<Option<Id>>() == 4);

impl Id {
    pub fn from_str(s: &str) -> Option<Self> {
        let separator_position = s.find('-')?;
        let idx = u16::from_str(&s[..separator_position]).ok()?;
        let gen_raw = u16::from_str(&s[separator_position + 1..]).ok()?;
        let gen = NonZeroU16::new(gen_raw)?;

        Some(Self { idx, gen })
    }

    pub fn from_idx_initial_gen(idx: u16) -> Self {
        Self {
            idx,
            gen: INITIAL_GEN,
        }
    }

    pub fn idx(&self) -> u16 {
        self.idx
    }
}

impl fmt::Display for Id {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{}-{}", self.idx, self.gen)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
enum Slot<T> {
    Free { freelist_next: Option<u16> },
    Item { gen: NonZeroU16, value: T },
}

// derive(Clone) is fine, becuase it only derives clone for allocators that are
// also Clone, like Global, but not Linear.
//
// derive(PartialEq) is omitted in favor of manual impl that does not include
// allocator comparisons in the result.
//
// derive(Debug) is omitted in favor of manual impl that only formats the data.
#[derive(Clone, Eq, Hash)]
pub struct IdMap<T, A: Allocator> {
    data: Vec<Slot<T>, A>,
    freelist_first: Option<u16>,
    len: u16,
    gen: NonZeroU16,
}

impl<T, A: Allocator> fmt::Debug for IdMap<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        f.write_str("[")?;

        for (i, slot) in self.data.iter().enumerate() {
            match slot {
                Slot::Free { .. } => write!(f, "{i}: ~X ")?,
                Slot::Item { gen, .. } => write!(f, "{i}: ~{gen} ")?,
            }
        }

        f.write_str("]")
    }
}

impl<T: PartialEq, SA: Allocator, OA: Allocator> PartialEq<IdMap<T, OA>> for IdMap<T, SA> {
    fn eq(&self, other: &IdMap<T, OA>) -> bool {
        self.data.as_slice() == other.data.as_slice()
            && self.freelist_first == other.freelist_first
            && self.len == other.len
            && self.gen == other.gen
    }
}

// IMPORTANT: Everything that removes an item from the generational array must
// increment its generation counter. Currently that's IdMap::remove and
// IdMap::clear. IdMap::clear_and_reset_gen is an exception and resets the
// generation to INITIAL_GEN.
//
// TODO(yan): Only increment gen when really needed. e.g. calling remove
// successively should only increment gen once, or clearing should only increase
// generation if the collection wasn't previously empty.

impl<T, A: Allocator> IdMap<T, A> {
    pub fn new_in(allocator: A) -> Self {
        Self {
            data: Vec::new_in(allocator),
            freelist_first: None,
            len: 0,
            gen: INITIAL_GEN,
        }
    }

    pub fn with_capacity_in(capacity: usize, allocator: A) -> Self {
        Self {
            data: Vec::with_capacity_in(capacity, allocator),
            freelist_first: None,
            len: 0,
            gen: INITIAL_GEN,
        }
    }

    // TODO(yan): Add two following constructors once we need to serialize IDs:
    //
    // - IdMap::with_ids_and_data_in(Iterator<Item=(Id, T), Allocator)
    // - IdMap::with_ids_by_key_in(Iterator<Item=T>, f: Fn(&T) -> Id, Allocator)

    /// Inserts value and returns the [`Id`] under which it was stored.
    pub fn insert(&mut self, value: T) -> Id {
        // Check we have enough room for next index (max is u16::MAX - 1).
        assert!(self.len < u16::MAX);

        let gen = self.gen;

        if let Some(idx) = self.freelist_first {
            debug_assert!(usize::from(self.len) < self.data.len());

            let slot = &mut self.data[usize::from(idx)];
            let freelist_next = match slot {
                Slot::Free { freelist_next } => *freelist_next,
                Slot::Item { .. } => unreachable!(),
            };

            *slot = Slot::Item { gen, value };

            self.freelist_first = freelist_next;
            self.len += 1;

            Id { idx, gen }
        } else {
            debug_assert!(usize::from(self.len) == self.data.len());
            let idx = self.len;

            self.data.push(Slot::Item { gen, value });
            self.len += 1;

            Id { idx, gen }
        }
    }

    /// Like insert, but runs the constructor function and passes the the [`Id`]
    /// to it, e.g. so it can be stored as part of the value.
    pub fn insert_with<F>(&mut self, constructor: F) -> Id
    where
        F: FnOnce(Id) -> T,
    {
        // Check we have enough room for next index (max is u16::MAX - 1).
        assert!(self.len < u16::MAX);

        let gen = self.gen;

        let idx = match self.freelist_first {
            Some(idx) => {
                debug_assert!(usize::from(self.len) < self.data.len());
                idx
            }
            None => {
                debug_assert!(usize::from(self.len) == self.data.len());
                self.len
            }
        };

        let id = Id { idx, gen };
        let value = constructor(id);

        self.insert(value)
    }

    // TODO(yan): @Speed This has to traverse the entire freelist to relink it,
    // which is maybe ok if we do it once per undo, but we definitely shouldn't
    // be doing it for every change in undo. Maybe add a batch API that hoses
    // the freelist and reconstructs it just once, afterwards?
    /// Inserts value under a specific [`Id`].
    ///
    /// # Panics
    ///
    /// Instead of growing, this panics if the index part of the id is out of
    /// bounds.
    ///
    /// Also panics if the slot is not vacant.
    pub fn insert_at_vacant_entry(&mut self, id: Id, value: T) {
        let idx = usize::from(id.idx);

        // The ID must have been a previously valid ID, and since IdMap doesn't
        // shrink, this means the index part of the ID is in bounds.
        assert!(idx < self.data.len());

        // Only populate free slots with this.
        assert!(!self.contains_idx(id.idx));

        self.data[idx] = Slot::Item { gen: id.gen, value };
        self.len += 1;

        self.fixup_freelist();
    }

    /// Checks whether this contains an entry with this [`Id`].
    pub fn contains(&self, id: Id) -> bool {
        match self.data.get(usize::from(id.idx)) {
            Some(Slot::Item { gen, .. }) if *gen == id.gen => true,
            _ => false,
        }
    }

    /// Checks whether this contains an entry with this index, ignoring
    /// generation.
    pub fn contains_idx(&self, idx: u16) -> bool {
        match self.data.get(usize::from(idx)) {
            Some(Slot::Item { .. }) => true,
            _ => false,
        }
    }

    pub fn get(&self, id: Id) -> Option<&T> {
        match self.data.get(usize::from(id.idx)) {
            Some(Slot::Item { gen, value }) if *gen == id.gen => Some(value),
            _ => None,
        }
    }

    pub fn get_mut(&mut self, id: Id) -> Option<&mut T> {
        match self.data.get_mut(usize::from(id.idx)) {
            Some(Slot::Item { gen, value }) if *gen == id.gen => Some(value),
            _ => None,
        }
    }

    pub fn get2_mut(&mut self, id1: Id, id2: Id) -> (Option<&mut T>, Option<&mut T>) {
        if id1.idx == id2.idx {
            assert!(id1.gen != id2.gen);
            if id1.gen > id2.gen {
                return (self.get_mut(id1), None);
            } else {
                return (None, self.get_mut(id2));
            }
        }

        let (id_low, id_high) = if id1.idx < id2.idx {
            (id1, id2)
        } else {
            (id2, id1)
        };

        let (slice_low, slice_high) = self.data.split_at_mut(usize::from(id_high.idx));

        let item_low = match slice_low.get_mut(usize::from(id_low.idx)) {
            Some(Slot::Item { gen, value }) if *gen == id_low.gen => Some(value),
            _ => None,
        };

        let item_high = match slice_high.get_mut(0) {
            Some(Slot::Item { gen, value }) if *gen == id_high.gen => Some(value),
            _ => None,
        };

        if id1.idx < id2.idx {
            (item_low, item_high)
        } else {
            (item_high, item_low)
        }
    }

    /// Returns [`Id`] stored under provided index, if any.
    pub fn get_id_at_idx(&self, idx: u16) -> Option<Id> {
        match self.data.get(usize::from(idx)) {
            Some(Slot::Item { gen, .. }) => Some(Id { idx, gen: *gen }),
            _ => None,
        }
    }

    /// Removes value contained under provided [`Id`] and returns it, if
    /// any. Increases current generation.
    pub fn remove(&mut self, id: Id) -> Option<T> {
        // Check we won't overflow the generation, because it needs to be
        // nonzero for valid Ids.
        assert!(self.gen < ONE_PAST_MAX_GEN);

        if usize::from(id.idx) >= self.data.len() {
            return None;
        }

        match self.data[usize::from(id.idx)] {
            Slot::Item { gen, .. } if id.gen == gen => {
                let slot = mem::replace(
                    &mut self.data[usize::from(id.idx)],
                    Slot::Free {
                        freelist_next: self.freelist_first,
                    },
                );

                self.freelist_first = Some(id.idx);
                self.len -= 1;
                self.gen.checked_add(1).unwrap(); // Won't panic, we assert above

                match slot {
                    Slot::Item { gen: _, value } => Some(value),
                    Slot::Free { .. } => unreachable!(),
                }
            }
            _ => None,
        }
    }

    /// Clears all data. Increases current generation.
    pub fn clear(&mut self) {
        // Check we won't overflow the generation, because it needs to be
        // nonzero for valid Ids.
        assert!(self.gen < ONE_PAST_MAX_GEN);

        // TODO(yan): @Speed This iterates twice (second iteration is in
        // Self::fixup_freelist). Fuse.
        for slot in &mut self.data {
            *slot = Slot::Free {
                freelist_next: None,
            };
        }

        self.len = 0;
        self.gen.checked_add(1).unwrap(); // Won't panic, we assert above

        self.fixup_freelist();
    }

    /// Clears all data. Resets current generation to [`INITIAL_GEN`].
    ///
    /// # Warning
    ///
    /// Resetting the generation will cause [`Id`] conflicts for subsequent
    /// insertions. Only use if you are sure this can't happen.
    pub fn clear_and_reset_gen(&mut self) {
        // TODO(yan): Instead of doing self.data.clear(), we fill the data with
        // free slots and regenerate the freelist. This is so that we can use
        // IdMap::insert_at_vacant, but this is kinda leaky. Can we do something
        // better/simpler? (also for IdMap::clear)

        // TODO(yan): @Speed This iterates twice (second iteration is in
        // Self::fixup_freelist). Fuse.
        for slot in &mut self.data {
            *slot = Slot::Free {
                freelist_next: None,
            };
        }

        self.len = 0;
        self.gen = INITIAL_GEN;

        self.fixup_freelist();
    }

    /// Returns the number of elements in the [`IdMap`]. This is less or equal
    /// to the number of entries.
    pub fn len(&self) -> usize {
        usize::from(self.len)
    }

    /// Returns the number of entries (allocated storage) in the [`IdMap`].
    pub fn entry_len(&self) -> usize {
        self.data.len()
    }

    pub fn is_empty(&self) -> bool {
        self.len == 0
    }

    pub fn iter(&self) -> Iter<T> {
        Iter {
            inner: self.data.iter().enumerate(),
        }
    }

    pub fn iter_mut(&mut self) -> IterMut<T> {
        IterMut {
            inner: self.data.iter_mut().enumerate(),
        }
    }

    pub fn iter_entries(&self) -> IterEntries<T> {
        IterEntries {
            inner: self.data.iter().enumerate(),
        }
    }

    fn fixup_freelist(&mut self) {
        // Regenerate freelist such that the index of the slot monotonically
        // increases as we traverse the freelist. If the entire map consists
        // only of free slots, iterating the freelist and iterating the slots
        // yields the items in the same order. This is important for some fiddly
        // uses of the map (a combination of Self::clear_and_reset_gen,
        // Self::entry_len and Self::insert_at_vacant).

        let mut last_idx: Option<u16> = None;
        for (i, slot) in self.data.iter_mut().enumerate().rev() {
            let i = cast_u16!(i);

            match slot {
                Slot::Free { freelist_next } => {
                    *freelist_next = last_idx;
                    last_idx = Some(i);
                }
                _ => (),
            }
        }

        self.freelist_first = last_idx;
    }
}

impl<T: Clone, A: Allocator> IdMap<T, A> {
    /// Clones data from `other` into `self`, but allows these [`IdMap`]s to
    /// have a different allocator. Uses allocator of `self`, if needed.
    pub fn clone_from<OA: Allocator>(&mut self, other: &IdMap<T, OA>) {
        self.data.clear();
        self.data.extend(other.data.iter().cloned());
        self.freelist_first = other.freelist_first;
        self.len = other.len;
        self.gen = other.gen;
    }
}

#[derive(Debug)]
pub struct Iter<'a, T> {
    inner: iter::Enumerate<slice::Iter<'a, Slot<T>>>,
}

impl<'a, T> Iterator for Iter<'a, T> {
    type Item = (Id, &'a T);

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            match self.inner.next() {
                Some((_, &Slot::Free { .. })) => {
                    continue;
                }
                Some((idx, &Slot::Item { gen, ref value })) => {
                    debug_assert!(idx < usize::from(u16::MAX));
                    return Some((
                        Id {
                            idx: idx as u16,
                            gen,
                        },
                        value,
                    ));
                }
                None => return None,
            }
        }
    }
}

#[derive(Debug)]
pub struct IterMut<'a, T> {
    inner: iter::Enumerate<slice::IterMut<'a, Slot<T>>>,
}

impl<'a, T> Iterator for IterMut<'a, T> {
    type Item = (Id, &'a mut T);

    fn next(&mut self) -> Option<Self::Item> {
        loop {
            match self.inner.next() {
                Some((_, &mut Slot::Free { .. })) => {
                    continue;
                }
                Some((idx, &mut Slot::Item { gen, ref mut value })) => {
                    debug_assert!(idx < usize::from(u16::MAX));
                    return Some((
                        Id {
                            idx: idx as u16,
                            gen,
                        },
                        value,
                    ));
                }
                None => return None,
            }
        }
    }
}

pub enum Entry<'a, T> {
    Vacant(u16),
    Occupied(Id, &'a T),
}

pub struct IterEntries<'a, T> {
    inner: iter::Enumerate<slice::Iter<'a, Slot<T>>>,
}

impl<'a, T> Iterator for IterEntries<'a, T> {
    type Item = Entry<'a, T>;

    fn next(&mut self) -> Option<Self::Item> {
        match self.inner.next() {
            Some((idx, &Slot::Free { .. })) => {
                debug_assert!(idx < usize::from(u16::MAX));
                Some(Entry::Vacant(idx as u16))
            }
            Some((idx, &Slot::Item { gen, ref value })) => {
                debug_assert!(idx < usize::from(u16::MAX));
                Some(Entry::Occupied(
                    Id {
                        idx: idx as u16,
                        gen,
                    },
                    value,
                ))
            }
            None => None,
        }
    }
}

impl<'a, T, A: Allocator> IntoIterator for &'a IdMap<T, A> {
    type Item = (Id, &'a T);
    type IntoIter = Iter<'a, T>;

    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}

impl<'a, T, A: Allocator> IntoIterator for &'a mut IdMap<T, A> {
    type Item = (Id, &'a mut T);
    type IntoIter = IterMut<'a, T>;

    fn into_iter(self) -> Self::IntoIter {
        self.iter_mut()
    }
}

impl<T, A: Allocator> Index<Id> for IdMap<T, A> {
    type Output = T;

    fn index(&self, index: Id) -> &Self::Output {
        self.get(index).unwrap()
    }
}

impl<T, A: Allocator> IndexMut<Id> for IdMap<T, A> {
    fn index_mut(&mut self, index: Id) -> &mut Self::Output {
        self.get_mut(index).unwrap()
    }
}
