use alloc::alloc::Global;
use alloc::format;
use alloc::string::String;
use alloc::vec::Vec;
use core::alloc::Allocator;
use core::mem;
use core::ops::{BitAnd, BitAndAssign, BitOr, BitOrAssign};
use core::str;
use core::time::Duration;

use arrayvec::{ArrayString, ArrayVec};
use hashbrown::hash_map::{DefaultHashBuilder, Entry, HashMap};
use hashbrown::HashSet;
use lfg_alloc::Linear;
use lfg_common::cast_u32;
use lfg_math::{
    color_u32,
    const_radians,
    ivec3,
    libm,
    vec2,
    vec3,
    Color,
    IRect,
    IVec3,
    Mat4,
    Plane,
    Quat,
    Rect,
    UVec2,
    Vec2,
    Vec3,
};
use ph_platform::Platform;
use ph_renderer::{
    ColorSpace,
    Draw2DRectCommand,
    Draw2DRectPrimitive,
    Draw3DDebugOutlinePrimitive,
    Draw3DRectPrimitive,
    Draw3DVoxelPrimitive,
    Frame,
    RenderMode,
    Renderer,
    Sampler,
};

use crate::asset::{self, AssetId, AssetName, AssetReloadFlags, AssetType};
use crate::asset_catalog::{self, AssetCatalog};
use crate::camera::{self, Camera, CameraOptions};
use crate::gameplay::{
    self,
    Animation,
    Bearing,
    BinaryBooleanOp,
    EntityDataInit,
    EntityInit,
    EntityType,
    RunningAnimations,
    UnaryBooleanOp,
    VolumeAnimation,
    VolumeAnimationDirections,
};
use crate::grid::Grid;
use crate::history::{History, HistoryChange, HistoryError};
use crate::idmap::{Id, IdMap};
use crate::input::{Input, Key, KeyState, Mb};
use crate::time::Time;
use crate::xraw::{self, XRawDataRef};

macro_rules! fmt {
    ($dst:expr, $($fmt:tt)*) => ({
        use core::fmt::Write;

        $dst.clear();
        core::write!($dst, $($fmt)*).unwrap();

        &$dst
    });
}

const RECTANGLE_SELECT_THRESHOLD_SQUARED: f32 = 10.0 * 10.0;

const DRAG_SPEED_FAST: f32 = 0.1;
const DRAG_SPEED_PRECISE: f32 = 0.0001;

const CAMERA_SPEED: f32 = 5.0;
const CAMERA_SPEED_FAST: f32 = 20.0;

const MOVE_REPEAT_DELAY: Duration = Duration::from_millis(200);
const MOVE_REPEAT_COOLDOWN: Duration = Duration::from_millis(100);

const NOTIFICATION_DURATION: Duration = Duration::from_millis(3000);

const ASSET_RELOAD_POLL_INTERVAL: Duration = Duration::from_millis(8000);

const HISTORY_CAPACITY: usize = 10000;

const ASSET_ICON_SELECT: AssetId = AssetId::const_new("./data/images/editor_icon_select.png");
const ASSET_ICON_MOVE: AssetId = AssetId::const_new("./data/images/editor_icon_move.png");
const ASSET_ICON_BRUSH: AssetId = AssetId::const_new("./data/images/editor_icon_brush.png");
const ASSET_ICON_ERASER: AssetId = AssetId::const_new("./data/images/editor_icon_eraser.png");
const ASSET_ICON_CAMERA: AssetId = AssetId::const_new("./data/images/editor_icon_camera.png");
const ASSET_ICON_PICKER: AssetId = AssetId::const_new("./data/images/editor_icon_picker.png");

/*

TODO(yan): Editor features

LEVEL MANIPULATION

- [X] Open existing level (O)
- [X] Tab-cycle levels ("[" and "]")
- [X] Save level (UI)
- [X] Save level as (UI)
- [X] Close level (K)
- [X] Close modified level with prompt (K)
- [X] Open current level in game, even if unlisted (F1)
- [ ] Delete existing level

EDITING

- [ ] Create entity
- [X] Eyedrop pick entity to clipboard (Alt+Click)
- [X] Select entity ([SelectMode]::Click)
- [X] Select all entities ([SelectMode]::A")
- [X] Select multiple entities with marque/rectangle selection ([SelectMode]::Click+Drag)
- [X] Select/deselect multiple entities ([SelectMode]::Ctrl+Click or [SelectMode]::Ctrl+Click+Drag)
- [X] Edit selected entities (UI)
- [X] Delete selected entities ([SelectMode]::DELETE)
- [ ] Copy selected entities into clipboard ([SelectMode]::Ctrl+C)
- [ ] Paste clipboard into level ([SelectMode]::Ctrl+V)
      * Disambiguate from current clipboard, which is for brush picking
- [X] Move selected entities ([MoveMode]::{WASDQE})
- [ ] Move selected entities with gizmos
- [X] Entity brush picking on entities ([BrushMode]::Click+Drag)
- [X] Entity brush picking on level boundary ([BrushMode]::Click+Drag)
- [ ] Entity brush same plane modifier (default?)
- [ ] Entity brush same line modifier
- [X] Eraser brush ([EraserMode]::Click+Drag)
- [X] Highlight currently picked entity for entity brush, eraser brush and selection
- [X] Undo


TODO(yan): @Bug When entity brushing on a surface made out of entities
(e.g. brushing a second layer of ground), sometimes multiple brush preview cubes
appear (in various positions), and possibly multiple entities are added, either
in the same position, or in multiple positions.

 */

pub enum EditorTransition {
    None,
    Game,
    GameWithLevel { level_id: AssetId },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum EditorMode {
    Select,
    Move,
    Brush,
    Eraser,
}

struct AssetDropdownEntry {
    asset_id: AssetId,
    asset_name: AssetName,
}

impl AsRef<str> for AssetDropdownEntry {
    fn as_ref(&self) -> &str {
        &self.asset_name
    }
}

#[derive(Debug, Clone)]
struct Session {
    pub editor_mode: EditorMode,
    pub modified: bool,

    pub camera: Camera,

    pub history: History<EntityInit, Global>,
    pub entities: IdMap<EntityInit, Global>,

    pub highlight_id: Option<Id>,
    pub selection_add_buffer: HashSet<Id, DefaultHashBuilder, Global>,
    pub selection_buffer: HashSet<Id, DefaultHashBuilder, Global>,
    pub eraser_buffer: HashSet<Id, DefaultHashBuilder, Global>,
    pub brush_buffer: HashSet<IVec3>,

    pub text_edit_buffer: guise::AsciiArrayVec<32>,

    pub render_mode: RenderMode,
}

enum Dialog {
    Open,
    SaveAs(guise::AsciiArrayVec<{ AssetName::CAP }>),
    DiscardChanges,
    SyncData(SyncDataDialog),
}

struct SyncDataDialog {
    flags: EntityDataSyncFlags,
    current_level_only: bool,
}

#[derive(Clone, Copy, PartialEq, Eq, Hash, Default)]
struct EntityDataSyncFlags(u8);

impl EntityDataSyncFlags {
    pub const ANIMATIONS: Self = Self(0x01);
    pub const VOLUMES: Self = Self(0x02);

    #[allow(dead_code)]
    pub const NONE: Self = Self(0);
    pub const ALL: Self = Self::ANIMATIONS | Self::VOLUMES;

    #[allow(dead_code)]
    pub fn from_bits_truncate(bits: u8) -> Self {
        Self(Self::ALL.0 & bits)
    }

    #[allow(dead_code)]
    pub fn bits(&self) -> u8 {
        self.0
    }

    pub fn intersects(&self, other: Self) -> bool {
        self.0 & other.0 != 0
    }
}

impl const BitOr for EntityDataSyncFlags {
    type Output = Self;

    fn bitor(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl const BitOrAssign for EntityDataSyncFlags {
    fn bitor_assign(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

impl const BitAnd for EntityDataSyncFlags {
    type Output = Self;

    fn bitand(self, other: Self) -> Self {
        Self(self.0 & other.0)
    }
}

impl const BitAndAssign for EntityDataSyncFlags {
    fn bitand_assign(&mut self, other: Self) {
        self.0 &= other.0;
    }
}

pub struct Editor {
    time: Time,
    dtime: Duration,

    key_ctrl_down: bool,
    key_alt_down: bool,
    key_shift_down: bool,
    key_tab_down: bool,

    key_up_down: Option<Time>,
    key_down_down: Option<Time>,
    key_left_down: Option<Time>,
    key_right_down: Option<Time>,
    key_prev_down: Option<Time>,
    key_next_down: Option<Time>,

    mouse_down: bool,
    last_mouse_down_started_over_ui: bool,
    last_mouse_down_started_over_viewport: bool,
    rectangle_select_start: Option<Vec2>,

    ui: guise::Ui<Global>,
    show_dialog: Option<Dialog>,
    notifications: Vec<(Time, String)>,

    last_level_list_reload: Time,

    session_name: Option<AssetName>,
    sessions: HashMap<AssetName, Session>,
    sessions_order: Vec<AssetName>,
    session_open_request: Option<AssetName>,
    scratch_session: Session,

    clipboard_entity: Option<EntityInit>,
    draw_3d_rect_commands: Vec<Draw3DRectPrimitive, Global>,
}

impl Editor {
    pub fn new<P, R>(
        _root_allocator: &mut Linear,
        _temp_allocator: &Linear,
        _platform: &P,
        renderer: &mut R,
        input: &Input,
    ) -> Self
    where
        P: Platform,
        R: Renderer,
    {
        profile_scope!("Editor::new");

        renderer.insert_texture_rgba8_unorm(
            asset::ID_EDITOR_WHITE_TEX.into_raw(),
            &[255, 255, 255, 255],
            1,
            1,
            ColorSpace::Linear,
            Sampler::Nearest,
        );

        let logical_window_size = input.physical_window_size.as_vec2() / input.window_scale_factor;

        let mut ui = guise::Ui::new_in(
            logical_window_size.x,
            logical_window_size.y,
            input.window_scale_factor,
            guise::FONT_IBM_PLEX_MONO,
            guise::UnicodeRangeFlags::ALL_LATIN,
            14.0,
            input.window_scale_factor,
            Global,
        );

        let font_atlas_image = ui.font_atlas_image_rgba8_unorm();
        let (font_atlas_width, font_atlas_height) = ui.font_atlas_image_size();

        renderer.insert_texture_rgba8_unorm(
            asset::ID_EDITOR_FONT_ATLAS_TEX.into_raw(),
            font_atlas_image,
            font_atlas_width,
            font_atlas_height,
            ColorSpace::Linear,
            Sampler::Bilinear,
        );

        ui.set_font_atlas_texture_id(asset::ID_EDITOR_FONT_ATLAS_TEX.into_raw());

        Self {
            time: Time::ZERO,
            dtime: Duration::ZERO,

            key_ctrl_down: false,
            key_alt_down: false,
            key_shift_down: false,
            key_tab_down: false,

            key_up_down: None,
            key_down_down: None,
            key_left_down: None,
            key_right_down: None,
            key_prev_down: None,
            key_next_down: None,

            mouse_down: false,
            last_mouse_down_started_over_ui: false,
            last_mouse_down_started_over_viewport: false,
            rectangle_select_start: None,

            ui,
            show_dialog: None,
            notifications: Vec::with_capacity(8),

            last_level_list_reload: Time::ZERO,

            session_name: None,
            sessions: HashMap::new(),
            sessions_order: Vec::new(),
            session_open_request: None,
            scratch_session: scratch_session(Time::ZERO, input.physical_window_size),

            clipboard_entity: None,
            draw_3d_rect_commands: Vec::with_capacity_in(256, Global),
        }
    }

    pub fn update<P>(
        &mut self,
        temp_allocator: &Linear,
        platform: &P,
        input: &Input,
        asset_catalog: &AssetCatalog,
        asset_reload_flags: &mut AssetReloadFlags,
        // TODO(yan): Add asset_reload_flags_success and asset_reload_flags_failure.
    ) -> EditorTransition
    where
        P: Platform,
    {
        profile_scope!("Editor::update");

        let mut transition = EditorTransition::None;

        self.draw_3d_rect_commands.clear();

        self.time += input.dtime;
        self.dtime = input.dtime;

        let session_count = self.sessions.len();
        let any_session_modified = self.sessions.values().any(|session| session.modified);

        let (session, session_name, is_scratch_session) = match self.session_name {
            Some(session_name) => (
                self.sessions.get_mut(&session_name).unwrap(),
                session_name,
                false,
            ),
            None => (&mut self.scratch_session, AssetName::new(""), true),
        };

        session
            .camera
            .update(self.time.as_secs_f32(), input.physical_window_size);

        let ui_want_capture_keyboard = self.ui.want_capture_keyboard();
        let ui_want_capture_mouse = self.ui.want_capture_mouse();

        let mut mouse_pressed = false;
        let mut mouse_released = false;
        let mut key_a_pressed = false;
        let mut key_return_pressed = false;
        let mut key_delete_pressed = false;
        let mut move_actions: ArrayVec<IVec3, 32> = ArrayVec::new();

        let mut close_session = false;
        let mut open_level: Option<AssetName> = None;
        let mut save_level = false;
        let mut save_level_as: Option<AssetName> = None;
        let mut sync_data_from_entity: Option<(EntityInit, EntityDataSyncFlags, bool)> = None;

        // Are the camera rays not going to come from below ground or come in at
        // glancing angles?
        let can_raycast_ground = {
            const GLANCING_ANGLE_THRESHOLD: f32 = const_radians!(30.0);
            const HALF_PI: f32 = core::f32::consts::FRAC_PI_2;

            // TODO(yan): @Correctness Compute angle from camera fovy.
            let threshold = libm::cosf(HALF_PI - GLANCING_ANGLE_THRESHOLD);
            let normal = Vec3::Z;
            let direction = session.camera.direction();

            normal.dot(direction) < -threshold
        };

        let is_rectangle_selecting = {
            if let Some(start) = self.rectangle_select_start {
                let end = input.physical_cursor_position;
                start.distance_squared(end) > RECTANGLE_SELECT_THRESHOLD_SQUARED
            } else {
                false
            }
        };

        if !ui_want_capture_keyboard {
            for &(key, state) in &input.keys {
                let pressed = state == KeyState::Press;

                match key {
                    Key::Control => {
                        self.key_ctrl_down = pressed;
                    }
                    Key::Alt => {
                        self.key_alt_down = pressed;
                    }
                    Key::Shift => {
                        self.key_shift_down = pressed;
                    }

                    Key::R => {
                        if pressed && self.key_ctrl_down {
                            *asset_reload_flags |= AssetReloadFlags::ALL;
                        }
                    }

                    Key::Return => {
                        if pressed {
                            key_return_pressed = true;
                        }
                    }

                    Key::Delete => {
                        if pressed {
                            key_delete_pressed = true;
                        }
                    }

                    Key::W | Key::Up => {
                        if self.key_up_down.is_none() && pressed {
                            self.key_up_down = Some(self.time);
                            move_actions.push(ivec3(0, 1, 0));
                        } else if !pressed {
                            self.key_up_down = None;
                        }
                    }
                    Key::S => {
                        if self.key_down_down.is_none() && pressed {
                            self.key_down_down = Some(self.time);
                            move_actions.push(ivec3(0, -1, 0));
                        } else if !pressed {
                            self.key_down_down = None;
                        }

                        if pressed && self.key_ctrl_down {
                            if !is_scratch_session {
                                save_level = true;
                            } else {
                                self.show_dialog =
                                    Some(Dialog::SaveAs(guise::AsciiArrayVec::new()));
                            }
                        }
                    }
                    Key::Down => {
                        if self.key_down_down.is_none() && pressed {
                            self.key_down_down = Some(self.time);
                            move_actions.push(ivec3(0, -1, 0));
                        } else if !pressed {
                            self.key_down_down = None;
                        }
                    }
                    Key::A => {
                        if self.key_left_down.is_none() && pressed {
                            self.key_left_down = Some(self.time);
                            move_actions.push(ivec3(-1, 0, 0));
                        } else if !pressed {
                            self.key_left_down = None;
                        }

                        if pressed {
                            key_a_pressed = true;
                        }
                    }
                    Key::Left => {
                        if self.key_left_down.is_none() && pressed {
                            self.key_left_down = Some(self.time);
                            move_actions.push(ivec3(-1, 0, 0));
                        } else if !pressed {
                            self.key_left_down = None;
                        }
                    }

                    Key::D | Key::Right => {
                        if self.key_right_down.is_none() && pressed {
                            self.key_right_down = Some(self.time);
                            move_actions.push(ivec3(1, 0, 0));
                        } else if !pressed {
                            self.key_right_down = None;
                        }
                    }
                    Key::Q => {
                        if self.key_prev_down.is_none() && pressed {
                            self.key_prev_down = Some(self.time);
                            move_actions.push(ivec3(0, 0, -1));
                        } else if !pressed {
                            self.key_prev_down = None;
                        }
                    }
                    Key::E => {
                        if self.key_next_down.is_none() && pressed {
                            self.key_next_down = Some(self.time);
                            move_actions.push(ivec3(0, 0, 1));
                        } else if !pressed {
                            self.key_next_down = None;
                        }
                    }

                    Key::Z => {
                        if pressed {
                            if self.key_shift_down {
                                if let Some(transaction) =
                                    session.history.move_transaction_cursor_forward()
                                {
                                    // The transaction items are ordered such
                                    // that deletions go first to prevent
                                    // conflicts in the idmap. However, this is
                                    // REDO, so we need to manually reverse, and
                                    // switch around the meaning of insertions
                                    // and deletions.

                                    log::debug!("Redoing {} changes", transaction.len());
                                    for change in transaction.iter().rev() {
                                        match change {
                                            HistoryChange::Delete { id, value } => {
                                                // TODO(yan): EntityInits do not have IDs
                                                // debug_assert!(id == value.id);
                                                debug_assert!(!session
                                                    .entities
                                                    .contains_idx(id.idx()));
                                                session
                                                    .entities
                                                    .insert_at_vacant_entry(*id, *value);
                                            }
                                            HistoryChange::Insert { id, .. } => {
                                                // This deletion increases the
                                                // IdMap's generation, but that
                                                // shouldn't be a problem,
                                                // because we insert old
                                                // entities under their original
                                                // IDs, and there can be no
                                                // dangling references to
                                                // entities that do not exist
                                                // yet. Probably. I don't know
                                                // anymore.
                                                debug_assert!(session.entities.contains(*id));
                                                session.entities.remove(*id);
                                            }
                                        }

                                        session.modified = true;
                                    }
                                } else {
                                    log::debug!("Nothing else to redo");
                                }
                            } else {
                                if let Some(transaction) =
                                    session.history.move_transaction_cursor_back()
                                {
                                    // The transaction items are ordered such
                                    // that deletions go first to prevent
                                    // conflicts in the idmap.

                                    log::debug!("Undoing {} changes", transaction.len());
                                    for change in transaction {
                                        match change {
                                            HistoryChange::Insert { id, value } => {
                                                // TODO(yan): EntityInits do not have IDs
                                                // debug_assert!(id == value.id);
                                                debug_assert!(!session
                                                    .entities
                                                    .contains_idx(id.idx()));
                                                session
                                                    .entities
                                                    .insert_at_vacant_entry(*id, *value);
                                            }
                                            HistoryChange::Delete { id, .. } => {
                                                // This deletion increases the
                                                // IdMap's generation, but that
                                                // shouldn't be a problem,
                                                // because we insert old
                                                // entities under their original
                                                // IDs, and there can be no
                                                // dangling references to
                                                // entities that do not exist
                                                // yet.
                                                debug_assert!(session.entities.contains(*id));
                                                session.entities.remove(*id);
                                            }
                                        }

                                        session.modified = true;
                                    }
                                } else {
                                    log::debug!("Nothing else to undo");
                                }
                            }
                        }
                    }

                    Key::X => {
                        if pressed {
                            session.editor_mode = EditorMode::Eraser;
                            session.selection_buffer.clear();
                        }
                    }

                    Key::V => {
                        if pressed {
                            // Not clearing selection, because that's what
                            // we are moving.
                            session.editor_mode = EditorMode::Move;
                        }
                    }

                    Key::B => {
                        if pressed {
                            session.editor_mode = EditorMode::Brush;
                            session.selection_buffer.clear();
                        }
                    }

                    Key::K => {
                        if pressed {
                            if is_scratch_session {
                                // TODO(yan): Also allow closing scratch
                                // sessions and create new empty ones in their
                                // stead.
                            } else {
                                if session.modified {
                                    self.show_dialog = Some(Dialog::DiscardChanges);
                                } else {
                                    close_session = true;
                                }
                            }
                        }
                    }

                    Key::O => {
                        if pressed {
                            self.show_dialog = Some(Dialog::Open);
                        }
                    }

                    Key::LBracket => {
                        if pressed {
                            if session_count > 0 {
                                self.show_dialog = None;
                                self.rectangle_select_start = None;

                                if let Some(session_name) = self.session_name {
                                    let idx = self
                                        .sessions_order
                                        .iter()
                                        .position(|name| *name == session_name);

                                    if let Some(idx) = idx {
                                        if idx == 0 {
                                            self.session_name = None;
                                        } else {
                                            self.session_name = Some(self.sessions_order[idx - 1]);
                                        }
                                    }
                                } else {
                                    self.session_name = Some(*self.sessions_order.last().unwrap());
                                }
                            }
                        }
                    }
                    Key::RBracket => {
                        if pressed {
                            if session_count > 0 {
                                self.show_dialog = None;
                                self.rectangle_select_start = None;

                                if let Some(session_name) = self.session_name {
                                    let idx = self
                                        .sessions_order
                                        .iter()
                                        .position(|name| *name == session_name);

                                    if let Some(idx) = idx {
                                        if idx == self.sessions_order.len() - 1 {
                                            self.session_name = None;
                                        } else {
                                            self.session_name = Some(self.sessions_order[idx + 1]);
                                        }
                                    }
                                } else {
                                    self.session_name = Some(self.sessions_order[0]);
                                }
                            }
                        }
                    }

                    Key::F1 => {
                        if pressed {
                            transition = EditorTransition::Game;

                            if self.key_ctrl_down {
                                if let Some(session_name) = self.session_name {
                                    let levelset_entries = &asset_catalog.levelset_catalog
                                        [asset::ID_IMPLICIT_LEVELSET];
                                    let levelset_entry = levelset_entries
                                        .iter()
                                        .find(|e| e.level_name == session_name)
                                        .unwrap();
                                    let level_id = levelset_entry.level_id;
                                    transition = EditorTransition::GameWithLevel { level_id };
                                }

                                // TODO(yan): @Cleanup @Hack If we transition
                                // away from the editor, we won't get the event
                                // key-up for Ctrl, so it would stay pressed.
                                self.key_ctrl_down = false;
                            }
                        }
                    }
                    Key::F3 => {
                        if pressed {
                            session.render_mode = match session.render_mode {
                                RenderMode::Game => RenderMode::DepthMap,
                                RenderMode::DepthMap => RenderMode::Game,
                            };
                        }
                    }

                    Key::Tab => {
                        self.key_tab_down = pressed;
                    }

                    Key::Esc => {
                        if pressed {
                            if self.show_dialog.is_some() {
                                self.show_dialog = None;
                            } else {
                                // Not clearing selection unless Esc is pressed
                                // again, because we might want to do more with
                                // it after returning from previous mode.
                                if session.editor_mode == EditorMode::Select {
                                    session.selection_buffer.clear();
                                }

                                session.editor_mode = EditorMode::Select;
                                session.brush_buffer.clear();
                                session.eraser_buffer.clear();
                            }
                        }
                    }

                    _ => (),
                }
            }
        }

        if let Some(time) = &mut self.key_up_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                move_actions.push(ivec3(0, 1, 0));
            }
        }

        if let Some(time) = &mut self.key_down_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                move_actions.push(ivec3(0, -1, 0));
            }
        }

        if let Some(time) = &mut self.key_left_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                move_actions.push(ivec3(-1, 0, 0));
            }
        }

        if let Some(time) = &mut self.key_right_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                move_actions.push(ivec3(1, 0, 0));
            }
        }

        if let Some(time) = &mut self.key_prev_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                move_actions.push(ivec3(0, 0, -1));
            }
        }

        if let Some(time) = &mut self.key_next_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                move_actions.push(ivec3(0, 0, 1));
            }
        }

        for &(mb, state) in &input.mbs {
            let pressed = state == KeyState::Press;

            match mb {
                Mb::Left => {
                    self.mouse_down = pressed;

                    if pressed {
                        mouse_pressed = true;
                        if ui_want_capture_mouse {
                            self.last_mouse_down_started_over_ui = true;
                            self.last_mouse_down_started_over_viewport = false;
                        } else {
                            self.last_mouse_down_started_over_ui = false;
                            self.last_mouse_down_started_over_viewport = true;
                        }
                    } else {
                        mouse_released = true;
                    }
                }
                _ => (),
            }
        }

        {
            let logical_window_size =
                input.physical_window_size.as_vec2() / input.window_scale_factor;
            let logical_cursor_position =
                input.physical_cursor_position / input.window_scale_factor;
            let logical_scroll_delta = input.physical_scroll_delta / input.window_scale_factor;

            self.ui
                .set_window_size(logical_window_size.x, logical_window_size.y);
            self.ui.set_window_scale_factor(input.window_scale_factor);
            self.ui
                .set_cursor_position(logical_cursor_position.x, logical_cursor_position.y);

            for &c in &input.chars {
                self.ui.send_character(c);
            }

            self.ui
                .scroll(logical_scroll_delta.x, logical_scroll_delta.y);

            for &(key, state) in &input.keys {
                use guise::Inputs;

                let p = state == KeyState::Press;
                match key {
                    Key::Tab if p => self.ui.press_inputs(Inputs::KB_TAB),
                    Key::Tab if !p => self.ui.release_inputs(Inputs::KB_TAB),
                    Key::Left if p => self.ui.press_inputs(Inputs::KB_LEFT_ARROW),
                    Key::Left if !p => self.ui.release_inputs(Inputs::KB_LEFT_ARROW),
                    Key::Right if p => self.ui.press_inputs(Inputs::KB_RIGHT_ARROW),
                    Key::Right if !p => self.ui.release_inputs(Inputs::KB_RIGHT_ARROW),
                    Key::Up if p => self.ui.press_inputs(Inputs::KB_UP_ARROW),
                    Key::Up if !p => self.ui.release_inputs(Inputs::KB_UP_ARROW),
                    Key::Down if p => self.ui.press_inputs(Inputs::KB_DOWN_ARROW),
                    Key::Down if !p => self.ui.release_inputs(Inputs::KB_DOWN_ARROW),
                    Key::Home if p => self.ui.press_inputs(Inputs::KB_HOME),
                    Key::Home if !p => self.ui.release_inputs(Inputs::KB_HOME),
                    Key::End if p => self.ui.press_inputs(Inputs::KB_END),
                    Key::End if !p => self.ui.release_inputs(Inputs::KB_END),
                    Key::Insert if p => self.ui.press_inputs(Inputs::KB_INSERT),
                    Key::Insert if !p => self.ui.release_inputs(Inputs::KB_INSERT),
                    Key::Delete if p => self.ui.press_inputs(Inputs::KB_DELETE),
                    Key::Delete if !p => self.ui.release_inputs(Inputs::KB_DELETE),
                    Key::Backspace if p => self.ui.press_inputs(Inputs::KB_BACKSPACE),
                    Key::Backspace if !p => self.ui.release_inputs(Inputs::KB_BACKSPACE),
                    Key::Return if p => self.ui.press_inputs(Inputs::KB_ENTER),
                    Key::Return if !p => self.ui.release_inputs(Inputs::KB_ENTER),
                    Key::Esc if p => self.ui.press_inputs(Inputs::KB_ESCAPE),
                    Key::Esc if !p => self.ui.release_inputs(Inputs::KB_ESCAPE),
                    _ => (),
                }
            }

            for &(mb, state) in &input.mbs {
                use guise::Inputs;

                let p = state == KeyState::Press;
                match mb {
                    Mb::Left if p => self.ui.press_inputs(Inputs::MB_LEFT),
                    Mb::Left if !p => self.ui.release_inputs(Inputs::MB_LEFT),
                    Mb::Right if p => self.ui.press_inputs(Inputs::MB_RIGHT),
                    Mb::Right if !p => self.ui.release_inputs(Inputs::MB_RIGHT),
                    Mb::Middle if p => self.ui.press_inputs(Inputs::MB_MIDDLE),
                    Mb::Middle if !p => self.ui.release_inputs(Inputs::MB_MIDDLE),
                    _ => (),
                }
            }
        }

        let frame = &mut self.ui.begin_frame();
        let mut s: ArrayString<1024> = ArrayString::new();

        let mut hit_entity_and_normal: Option<(Id, IVec3)> = None;
        let mut hit_distance_squared = f32::MAX;

        let (camera_ray_origin, camera_ray_direction) = session
            .camera
            .ray_from_screen_position(input.physical_cursor_position);

        {
            profile_scope!("Editor::update click_select");
            // TODO(yan): @Speed Accelerate. Can we do BVH or Octree or something?
            for (entity_id, entity) in &session.entities {
                for (inormal, n1, n2, n3, n4) in [
                    (-IVec3::X, -Vec3::Y, Vec3::Y, -Vec3::Z, Vec3::Z),
                    (IVec3::X, -Vec3::Y, Vec3::Y, -Vec3::Z, Vec3::Z),
                    (-IVec3::Y, -Vec3::Z, Vec3::Z, -Vec3::X, Vec3::X),
                    (IVec3::Y, -Vec3::Z, Vec3::Z, -Vec3::X, Vec3::X),
                    (-IVec3::Z, -Vec3::X, Vec3::X, -Vec3::Y, Vec3::Y),
                    (IVec3::Z, -Vec3::X, Vec3::X, -Vec3::Y, Vec3::Y),
                ] {
                    let normal = inormal.as_vec3();

                    // IMPORTANT(yan): This dot product is computed with the
                    // normal and the camera *ray* direction, not just regular
                    // camera direction. We previously had a situation, where
                    // using just the camera direction incorrectly allowed
                    // away-facing walls to be picked when the cursor was
                    // skirting the edge of an entity wall. This would cause us
                    // to add entities inside the already existing entities.
                    // Surprisigly enough, this happened a lot during regular
                    // editing.
                    //
                    // Below, we use camera_ray_origin to compute distance
                    // instead of camera_position, but we probably don't have
                    // to? Doesn't hurt though, as we already have it computed.
                    if normal.dot(camera_ray_direction) < 0.0 {
                        let position = entity.position.as_vec3();
                        let plane = Plane::from_normal_origin(normal, position + 0.5 * normal);

                        if let Some(intersection) =
                            plane.ray_intersection(camera_ray_origin, camera_ray_direction)
                        {
                            let mut contained = true;

                            for n in [n1, n2, n3, n4] {
                                let p = position + 0.5 * normal + 0.5 * n;
                                let ip = p - intersection;

                                if ip.dot(n) < 0.0 {
                                    contained = false;
                                }
                            }

                            if contained {
                                let distance_squared = camera_ray_origin.distance_squared(position);
                                if distance_squared < hit_distance_squared {
                                    hit_entity_and_normal = Some((entity_id, inormal));
                                    hit_distance_squared = distance_squared;
                                }
                            }
                        }
                    }
                }
            }
        }

        session.selection_add_buffer.clear();
        if session.editor_mode == EditorMode::Select {
            if mouse_pressed && self.last_mouse_down_started_over_viewport {
                self.rectangle_select_start = Some(input.physical_cursor_position);
            }

            if let Some(start) = self.rectangle_select_start {
                profile_scope!("Editor::update rectangle_select");

                let end = input.physical_cursor_position;
                if start.distance_squared(end) > RECTANGLE_SELECT_THRESHOLD_SQUARED {
                    // Generate four inward-facing normals for plane tests from
                    // the screen space selection rectangle by finding the ray
                    // origins and ray directions in world space, and using
                    // cross product to find the normals.

                    // Corners of the selection rectangle in screen space, CW.
                    let min = start.min(end);
                    let max = start.max(end);
                    let p00 = vec2(min.x, min.y);
                    let p10 = vec2(max.x, min.y);
                    let p11 = vec2(max.x, max.y);
                    let p01 = vec2(min.x, max.y);

                    // Find rays in world space
                    let (ray00_origin, ray00_direction) =
                        session.camera.ray_from_screen_position(p00);
                    let (ray10_origin, ray10_direction) =
                        session.camera.ray_from_screen_position(p10);
                    let (ray11_origin, ray11_direction) =
                        session.camera.ray_from_screen_position(p11);
                    let (ray01_origin, ray01_direction) =
                        session.camera.ray_from_screen_position(p01);

                    // Compute normals from ray origins in world space. These
                    // normals are not actually normalized, but we just measure
                    // direction, not distance.
                    let d1 = ray00_origin - ray10_origin;
                    let d2 = ray10_origin - ray11_origin;
                    let d3 = ray11_origin - ray01_origin;
                    let d4 = ray01_origin - ray00_origin;

                    let n1 = Vec3::cross(d1, ray00_direction);
                    let n2 = Vec3::cross(d2, ray10_direction);
                    let n3 = Vec3::cross(d3, ray11_direction);
                    let n4 = Vec3::cross(d4, ray01_direction);

                    // TOOD(yan): @Cleanup @Hack @Speed Rectangle selection
                    // doesn't need full containment, an intersection is
                    // "enough". The problem with this is that containment is
                    // much simpler (but not necessarily cheaper) to check -
                    // just check all the vertices of a convex mesh for
                    // containment. We do intersection in a really hacky way -
                    // we check for point containment and report success if just
                    // one of the points is contained. If we draw a selection
                    // rectangle inside the thing we want to select, we still
                    // might miss all the test vertices (that would be on the
                    // surface, if we were testing for containment). We hack
                    // around this by populating the test voxel with more test
                    // points, but this is both incorrect possibly slow. One
                    // correct way os writing actual geometry intersection code
                    // like GJK or MPR (or a specialized quad/quad or
                    // triangle/triangle) version, but that also seems like it
                    // would be terribly slow and would likely need a broad
                    // phase to even work on levels of our current size.
                    //
                    // UPDATE: One way we could do this both reasonably fast and
                    // correct is by projecting the frustrum into a voxel layer,
                    // creating a quad, and checking which voxels are in that
                    // quad. Would look something like:
                    //
                    // 1) Find dominating direction
                    //
                    // 2) Raycast from selection rectangle corners, find
                    //    intersections with voxel layer, generating four
                    //    corners of a quad.
                    //
                    // 3) Scanline the quad to see which voxels intersect the
                    //    quad.
                    //
                    // ^ needs verification.

                    const DENSITY_X: usize = 5;
                    const DENSITY_Y: usize = 5;
                    const DENSITY_Z: usize = 5;
                    const OFFSETS_CAP: usize = DENSITY_X * DENSITY_Y * DENSITY_Z;

                    let mut offsets = Vec::with_capacity_in(OFFSETS_CAP, temp_allocator);
                    for x in 0..DENSITY_X {
                        for y in 0..DENSITY_Y {
                            for z in 0..DENSITY_Z {
                                offsets.push(vec3(
                                    x as f32 / DENSITY_X as f32 - 0.5,
                                    y as f32 / DENSITY_Y as f32 - 0.5,
                                    z as f32 / DENSITY_Z as f32 - 0.5,
                                ));
                            }
                        }
                    }

                    // TODO(yan): @Speed Accelerate. Can we do BVH or Octree or something?
                    for (entity_id, entity) in &session.entities {
                        let position = entity.position.as_vec3();

                        let mut hit = false;
                        for &offset in &offsets {
                            let p = position + offset;

                            let t1 = Vec3::dot(p - ray00_origin, n1) >= 0.0;
                            let t2 = Vec3::dot(p - ray10_origin, n2) >= 0.0;
                            let t3 = Vec3::dot(p - ray11_origin, n3) >= 0.0;
                            let t4 = Vec3::dot(p - ray01_origin, n4) >= 0.0;

                            if t1 && t2 && t3 && t4 {
                                hit = true;
                                break;
                            }
                        }

                        if hit {
                            session.selection_add_buffer.insert(entity_id);
                        }
                    }
                }
            }

            if mouse_released && self.last_mouse_down_started_over_viewport {
                if !self.key_ctrl_down {
                    session.selection_buffer.clear();
                }

                for &entity_id in &session.selection_add_buffer {
                    if !session.selection_buffer.insert(entity_id) {
                        session.selection_buffer.remove(&entity_id);
                    }
                }

                self.rectangle_select_start = None;
            }
        } else {
            self.rectangle_select_start = None;
        }

        if session.editor_mode == EditorMode::Select
            || session.editor_mode == EditorMode::Brush
            || session.editor_mode == EditorMode::Eraser
        {
            if let Some((hit_entity_id, _)) = hit_entity_and_normal && !is_rectangle_selecting {
                session.highlight_id = Some(hit_entity_id);
            } else {
                session.highlight_id = None;
            }
        }

        let mut hit_ground: Option<IVec3> = None;
        if hit_entity_and_normal.is_none() {
            // The ground plane is rendered and intersected at Z=-0.5, because
            // game positions translate to voxel centers in the float coordinates.
            let origin = -0.5 * Vec3::Z;
            let normal = Vec3::Z;

            // We don't test if the ray is coming from above or below the plane,
            // because we ask can_raycast_ground before registering the hit, but
            // we want to draw some version of the UI regardless to give
            // feedback.
            let plane = Plane::from_normal_origin(normal, origin);
            let intersection = plane.ray_intersection(camera_ray_origin, camera_ray_direction);

            if let Some(intersection) = intersection {
                let intersection_xy = intersection.truncate().round();
                let draw_position = intersection_xy.extend(-0.5);
                let game_position = intersection_xy.extend(0.0).as_ivec3();

                if can_raycast_ground {
                    hit_ground = Some(game_position);
                }

                // TODO(yan): @Cleanup This rendering code should probably
                // be in the EditorMode::Brush section, but we have all the
                // data here, and would have to reconstruct it there.
                if session.editor_mode == EditorMode::Brush {
                    let color_mul = if can_raycast_ground {
                        color_u32([50, 120, 50, 50])
                    } else {
                        color_u32([120, 50, 50, 50])
                    };
                    let m_top = Mat4::from_rotation_translation(
                        Quat::from_rotation_arc(-Vec3::Y, normal),
                        draw_position,
                    );
                    let m_bottom = Mat4::from_rotation_translation(
                        Quat::from_rotation_arc(-Vec3::Y, -normal),
                        draw_position,
                    );

                    // Add both top-facing and bottom-facing cursors, so we
                    // have consistent UI.
                    self.draw_3d_rect_commands.push(Draw3DRectPrimitive {
                        transform_matrix: m_top,
                        texture_rect: Rect::ONE,
                        color_mul,
                        color_add: color_u32([0; 4]),
                        texture_id: asset::ID_EDITOR_WHITE_TEX.into_raw(),
                    });

                    self.draw_3d_rect_commands.push(Draw3DRectPrimitive {
                        transform_matrix: m_bottom,
                        texture_rect: Rect::ONE,
                        color_mul,
                        color_add: color_u32([0; 4]),
                        texture_id: asset::ID_EDITOR_WHITE_TEX.into_raw(),
                    });
                }
            }
        }

        if let Some((entity_id, _)) = hit_entity_and_normal {
            if self.key_alt_down && mouse_pressed && self.last_mouse_down_started_over_viewport {
                let entity = session.entities[entity_id];
                self.clipboard_entity = Some(entity);
            }
        }

        if self.key_tab_down {
            let camera_direction = session.camera.direction();
            let mut move_direction = Vec3::ZERO;

            if self.key_up_down.is_some() {
                move_direction += camera_direction;
            }
            if self.key_down_down.is_some() {
                move_direction -= camera_direction;
            }
            if self.key_left_down.is_some() {
                move_direction -= camera_direction.cross(Vec3::Z).normalize();
            }
            if self.key_right_down.is_some() {
                move_direction += camera_direction.cross(Vec3::Z).normalize();
            }
            if self.key_prev_down.is_some() {
                move_direction -= camera_direction
                    .cross(Vec3::Z)
                    .normalize()
                    .cross(camera_direction);
            }
            if self.key_next_down.is_some() {
                move_direction += camera_direction
                    .cross(Vec3::Z)
                    .normalize()
                    .cross(camera_direction);
            }

            if move_direction != Vec3::ZERO {
                let v = if self.key_shift_down {
                    CAMERA_SPEED_FAST
                } else {
                    CAMERA_SPEED
                };
                let dposition = move_direction.normalize() * v * self.dtime.as_secs_f32();
                session.camera.change_position(dposition);
            }

            const MOUSE_SENSITIVITY: f32 = 0.002;
            let x = -MOUSE_SENSITIVITY * input.mouse_motion.x;
            let y = MOUSE_SENSITIVITY * input.mouse_motion.y;
            session.camera.change_orientation(x, y);
        }

        if !self.key_alt_down && !self.key_tab_down {
            match session.editor_mode {
                EditorMode::Select => {
                    if key_a_pressed {
                        session
                            .selection_buffer
                            .extend(session.entities.iter().map(|(id, _)| id));
                    }

                    if let Some((entity_id, _)) = hit_entity_and_normal {
                        if mouse_released
                            && self.last_mouse_down_started_over_viewport
                            && !is_rectangle_selecting
                        {
                            if self.key_ctrl_down {
                                if session.selection_buffer.contains(&entity_id) {
                                    session.selection_buffer.remove(&entity_id);
                                } else {
                                    session.selection_buffer.insert(entity_id);
                                }
                            } else {
                                session.selection_buffer.clear();
                                session.selection_buffer.insert(entity_id);
                            }
                        }
                    }

                    if key_delete_pressed {
                        let mut entities_prev =
                            IdMap::with_capacity_in(session.entities.len(), temp_allocator);
                        entities_prev.clone_from(&session.entities);

                        for entity_id in session.selection_buffer.drain() {
                            session.entities.remove(entity_id);
                        }

                        // TODO(yan): @Speed we can produce a concrete
                        // change-set here and don't have to run the diff.
                        session.modified = true;
                        push_transaction(
                            temp_allocator,
                            &mut session.history,
                            &session.entities,
                            &entities_prev,
                        );
                    }
                }
                EditorMode::Move => {
                    let mut direction = IVec3::ZERO;

                    for &move_direction in &move_actions {
                        direction += move_direction;
                    }

                    if direction != IVec3::ZERO {
                        let mut can_move = true;
                        for &entity_id in &session.selection_buffer {
                            // Check existence, because selection buffer can
                            // become outdated with undo/redo.
                            if let Some(entity) = session.entities.get(entity_id) {
                                let position = entity.position;
                                if !is_above_ground(position + direction) {
                                    can_move = false;
                                }
                            }
                        }

                        if can_move {
                            let mut entities_prev =
                                IdMap::with_capacity_in(session.entities.len(), temp_allocator);
                            entities_prev.clone_from(&session.entities);

                            for &entity_id in &session.selection_buffer {
                                // Check existence, because selection buffer can
                                // become outdated with undo/redo.
                                if let Some(entity) = session.entities.get_mut(entity_id) {
                                    entity.position += direction;
                                }
                            }

                            // TODO(yan): @Speed we can produce a concrete
                            // change-set here and don't have to run the diff.
                            session.modified = true;
                            push_transaction(
                                temp_allocator,
                                &mut session.history,
                                &session.entities,
                                &entities_prev,
                            );
                        }
                    }
                }
                EditorMode::Brush => {
                    if let Some(clipboard_entity) = &self.clipboard_entity {
                        let hit = if let Some((hit_entity_id, hit_normal)) = hit_entity_and_normal {
                            Some(session.entities[hit_entity_id].position + hit_normal)
                        } else if let Some(hit_position) = hit_ground {
                            Some(hit_position)
                        } else {
                            None
                        };

                        if let Some(position) = hit {
                            if self.mouse_down && self.last_mouse_down_started_over_viewport {
                                if is_above_ground(position) {
                                    session.brush_buffer.insert(position);
                                }
                            }
                        }

                        if mouse_released
                            && self.last_mouse_down_started_over_viewport
                            && !session.brush_buffer.is_empty()
                        {
                            let mut entities_prev =
                                IdMap::with_capacity_in(session.entities.len(), temp_allocator);
                            entities_prev.clone_from(&session.entities);

                            for position in session.brush_buffer.drain() {
                                session.entities.insert(EntityInit {
                                    position,
                                    ..*clipboard_entity
                                });
                            }

                            // TODO(yan): @Speed we can produce a concrete
                            // change-set here and don't have to run the diff.
                            session.modified = true;
                            push_transaction(
                                temp_allocator,
                                &mut session.history,
                                &session.entities,
                                &entities_prev,
                            );
                        }
                    }
                }
                EditorMode::Eraser => {
                    if let Some((entity_id, _)) = hit_entity_and_normal {
                        if self.mouse_down && self.last_mouse_down_started_over_viewport {
                            session.eraser_buffer.insert(entity_id);
                        }
                    }

                    if mouse_released
                        && self.last_mouse_down_started_over_viewport
                        && !session.eraser_buffer.is_empty()
                    {
                        let mut entities_prev =
                            IdMap::with_capacity_in(session.entities.len(), temp_allocator);
                        entities_prev.clone_from(&session.entities);

                        for entity_id in session.eraser_buffer.drain() {
                            session.entities.remove(entity_id);
                        }

                        // TODO(yan): @Speed we can produce a concrete
                        // change-set here and don't have to run the diff.
                        session.modified = true;
                        push_transaction(
                            temp_allocator,
                            &mut session.history,
                            &session.entities,
                            &entities_prev,
                        );
                    }
                }
            }
        }

        static THEME: &guise::Theme = &guise::Theme::DEFAULT;

        static THEME_LEFT_PANEL: &guise::Theme = &guise::Theme {
            window_border: 0.0,
            window_padding: 0.0,
            image_button_margin: 0.0,
            ..*THEME
        };

        // TODO(yan): Color manipulation functions in guise. Lighten/darken &
        // Saturate/desaturate, transparency manipulation
        static THEME_LEFT_PANEL_ACTIVE: &guise::Theme = &guise::Theme {
            image_button_background_color: 0xa0a0a090,
            image_button_background_color_hovered: 0xa0a0a0c0,
            image_button_background_color_active: 0xa0a0a0ff,
            ..*THEME_LEFT_PANEL
        };

        static THEME_LEFT_PANEL_TRANSIENT: &guise::Theme = &guise::Theme {
            image_button_border_color: 0x00000000,
            image_button_border_color_hovered: 0x00000000,
            image_button_border_color_active: 0x00000000,
            image_button_background_color: THEME.image_button_background_color,
            image_button_background_color_hovered: THEME.image_button_background_color,
            image_button_background_color_active: THEME.image_button_background_color,
            ..*THEME_LEFT_PANEL
        };

        {
            // TODO(yan): Ending a window created like this with guise::end_window is hairy!
            guise::Window::new(line!(), 5.0, 5.0, 40.0, 400.0)
                .set_movable(false)
                .set_resizable(false)
                .set_theme(THEME_LEFT_PANEL)
                .begin(frame);

            if guise::Button::new(line!(), "")
                .set_theme(if session.editor_mode == EditorMode::Select {
                    THEME_LEFT_PANEL_ACTIVE
                } else {
                    THEME_LEFT_PANEL
                })
                .set_image(ASSET_ICON_SELECT.into_raw())
                .set_tooltip("Select [Esc]")
                .show(frame)
            {
                session.editor_mode = EditorMode::Select;
            }

            if guise::Button::new(line!(), "")
                .set_theme(if session.editor_mode == EditorMode::Move {
                    THEME_LEFT_PANEL_ACTIVE
                } else {
                    THEME_LEFT_PANEL
                })
                .set_image(ASSET_ICON_MOVE.into_raw())
                .set_tooltip("Move [V]")
                .show(frame)
            {
                session.editor_mode = EditorMode::Move;
            }

            if guise::Button::new(line!(), "")
                .set_theme(if session.editor_mode == EditorMode::Brush {
                    THEME_LEFT_PANEL_ACTIVE
                } else {
                    THEME_LEFT_PANEL
                })
                .set_image(ASSET_ICON_BRUSH.into_raw())
                .set_tooltip("Entity Brush [B]")
                .show(frame)
            {
                session.editor_mode = EditorMode::Brush;
            }

            if guise::Button::new(line!(), "")
                .set_theme(if session.editor_mode == EditorMode::Eraser {
                    THEME_LEFT_PANEL_ACTIVE
                } else {
                    THEME_LEFT_PANEL
                })
                .set_image(ASSET_ICON_ERASER.into_raw())
                .set_tooltip("Eraser [E]")
                .show(frame)
            {
                session.editor_mode = EditorMode::Eraser;
            }

            guise::Button::new(line!(), "")
                .set_theme(if self.key_tab_down {
                    THEME_LEFT_PANEL_ACTIVE
                } else {
                    THEME_LEFT_PANEL_TRANSIENT
                })
                .set_image(ASSET_ICON_CAMERA.into_raw())
                .set_tooltip("Camera [Tab+WASDQE]")
                .show(frame);

            guise::Button::new(line!(), "")
                .set_theme(if self.key_alt_down {
                    THEME_LEFT_PANEL_ACTIVE
                } else {
                    THEME_LEFT_PANEL_TRANSIENT
                })
                .set_image(ASSET_ICON_PICKER.into_raw())
                .set_tooltip("Eydropper [Alt+Click]")
                .show(frame);

            guise::end_window(frame);
        }

        {
            guise::Window::new(line!(), "70%", 5.0, "29%", "98%")
                .set_movable(false)
                .set_resizable(false)
                .begin(frame);

            {
                guise::text(
                    frame,
                    line!(),
                    fmt!(
                        s,
                        "Level: {}{}",
                        if is_scratch_session {
                            "<scratch>"
                        } else {
                            &session_name
                        },
                        if session.modified { "*" } else { "" },
                    ),
                );

                if guise::button(frame, line!(), "Save Level As...") {
                    self.show_dialog = Some(Dialog::SaveAs(guise::AsciiArrayVec::new()));
                }

                if !is_scratch_session {
                    if guise::button(frame, line!(), "Save Level") {
                        log::info!("Saving level");
                        save_level = true;
                    }
                }
            }

            if guise::button(frame, line!(), "Sync animations from source entity") {
                self.show_dialog = Some(Dialog::SyncData(SyncDataDialog {
                    flags: EntityDataSyncFlags::ANIMATIONS,
                    current_level_only: true,
                }));
            }

            if guise::button(frame, line!(), "Sync volumes from source entity") {
                self.show_dialog = Some(Dialog::SyncData(SyncDataDialog {
                    flags: EntityDataSyncFlags::VOLUMES,
                    current_level_only: true,
                }));
            }

            guise::separator(frame, line!());
            guise::text(
                frame,
                line!(),
                if let Some(entity) = &self.clipboard_entity {
                    fmt!(s, "Clipboard: {}", entity.ty)
                } else {
                    "Clipboard: N/A"
                },
            );

            guise::separator(frame, line!());

            let mut entities_prev = IdMap::with_capacity_in(session.entities.len(), temp_allocator);
            entities_prev.clone_from(&session.entities);

            if draw_entity_editor(
                frame,
                line!(),
                &mut session.text_edit_buffer,
                &mut session.selection_buffer,
                &mut session.entities,
                asset_catalog,
            ) {
                // TODO(yan): @Correctness @Speed This can be triggered by a UI
                // slider. Dragging the slider can push tons of changes, but
                // we'd ideally just push the bulk change once it has finished
                // for both the UX and memory use.
                //
                // History::push_transaction is also super slow, which might
                // show if we call it per-frame here.
                //
                // The UI would have to notify us when a continuous change
                // starts and when does it end, so we can create entities_prev
                // ans push the transaction at the correct points in time.
                //
                // TODO(yan): @Speed we can produce a concrete change-set here
                // (only one entity gets modified) and don't have to run the
                // diff.
                session.modified = true;
                push_transaction(
                    temp_allocator,
                    &mut session.history,
                    &session.entities,
                    &entities_prev,
                );
            }

            guise::end_window(frame);
        }

        match &mut self.show_dialog {
            Some(Dialog::Open) => {
                // TODO(yan): @Correctness This doesn't check success or failure at all, and
                // just assumes instant success.
                if self.time - self.last_level_list_reload > ASSET_RELOAD_POLL_INTERVAL {
                    self.last_level_list_reload = self.time;
                    *asset_reload_flags |= AssetReloadFlags::LEVELSETS;
                }

                // TODO(yan): Always make on top with .set_active(true)
                guise::Window::new(line!(), "20%", "10%", "60%", "85%")
                    .set_movable(false)
                    .set_resizable(false)
                    .begin(frame);

                {
                    let mut level_entries: ArrayVec<AssetDropdownEntry, 512> = ArrayVec::new();
                    for levelset_entry in
                        &asset_catalog.levelset_catalog[asset::ID_IMPLICIT_LEVELSET]
                    {
                        level_entries.push(AssetDropdownEntry {
                            asset_id: levelset_entry.level_id,
                            asset_name: levelset_entry.level_name,
                        });
                    }

                    level_entries.sort_unstable_by_key(|entry| entry.asset_name);

                    let mut selected_level_idx = None;
                    // TODO(yan): Add text search to guise::dropdown. We want
                    // the following workflow:
                    //
                    // 1) Type "O" to open the Open Level Dialog w/ the dropdown already active
                    //
                    // 2) Start typing to filter levels (either
                    //    starts_with_str/contains_str, or some kind of fuzzy
                    //    search)
                    //
                    // 2.5) Use up/down arrow keys (or Emacs style P/N) to navigate
                    //
                    // 3) Hit "Enter" to load level
                    if guise::dropdown(
                        frame,
                        line!(),
                        "Select level",
                        &level_entries,
                        &mut selected_level_idx,
                    ) {
                        if let Some(selected_level_idx) = selected_level_idx {
                            open_level = Some(level_entries[selected_level_idx].asset_name);
                            self.show_dialog = None;
                        }
                    }
                }

                guise::end_window(frame)
            }
            Some(Dialog::SaveAs(text_buffer)) => {
                let mut close = false;

                // TODO(yan): Always make on top with .set_active(true)
                guise::Window::new(line!(), "20%", "35%", "60%", "25%")
                    .set_movable(false)
                    .set_resizable(false)
                    .begin(frame);

                {
                    guise::text(frame, line!(), "Choose level name and confirm");
                    match guise::input_text(frame, line!(), text_buffer, "Level Name") {
                        (_, guise::InputTextSubmit::None) => (),
                        (_, guise::InputTextSubmit::Submit) => {
                            let level_name = AssetName::new(text_buffer);
                            save_level_as = Some(level_name);

                            close = true;
                        }
                        (_, guise::InputTextSubmit::Cancel) => (),
                    }

                    if guise::button(frame, line!(), "Save as") {
                        let level_name = AssetName::new(text_buffer);
                        save_level_as = Some(level_name);

                        close = true;
                    }
                }

                guise::end_window(frame);

                if close {
                    self.show_dialog = None;
                }
            }
            Some(Dialog::DiscardChanges) => {
                // TODO(yan): Always make on top with .set_active(true)
                guise::Window::new(line!(), "20%", "35%", "60%", "25%")
                    .set_movable(false)
                    .set_resizable(false)
                    .begin(frame);

                {
                    guise::text(frame, line!(), "Discard changes?");
                    if guise::button(frame, line!(), "Yes") || key_return_pressed {
                        close_session = true;
                        self.show_dialog = None;
                    }
                    if guise::button(frame, line!(), "No") {
                        self.show_dialog = None;
                    }
                }

                guise::end_window(frame);
            }
            Some(Dialog::SyncData(dialog)) => {
                // TODO(yan): Always make on top with .set_active(true)
                guise::Window::new(line!(), "20%", "35%", "60%", "25%")
                    .set_movable(false)
                    .set_resizable(false)
                    .begin(frame);

                {
                    // We only allow this if all non-scratch sessions are saved
                    // first, because we'll be force-saving them again.
                    if any_session_modified {
                        guise::text(frame, line!(), "Save all other non-scratch sessions first");
                    } else {
                        guise::text(
                            frame,
                            line!(),
                            "Synchronize data across all entities of this type in all levels? \
                             (This also migrates all level assets to newest version)",
                        );

                        guise::checkbox(
                            frame,
                            line!(),
                            &mut dialog.current_level_only,
                            "Current Level only",
                        );

                        if session.selection_buffer.len() == 1 {
                            let mut close = false;

                            if dialog.flags.intersects(EntityDataSyncFlags::ANIMATIONS) {
                                if guise::button(frame, line!(), "Sync Animations") {
                                    let selected_id =
                                        session.selection_buffer.iter().next().unwrap();

                                    // Check existence, because selection buffer can
                                    // become outdated with undo/redo.
                                    if let Some(sync_source_entity) =
                                        session.entities.get(*selected_id)
                                    {
                                        sync_data_from_entity = Some((
                                            *sync_source_entity,
                                            EntityDataSyncFlags::ANIMATIONS,
                                            dialog.current_level_only,
                                        ));

                                        close = true;
                                    }
                                }
                            }

                            if dialog.flags.intersects(EntityDataSyncFlags::VOLUMES) {
                                if guise::button(frame, line!(), "Sync Volumes") {
                                    let selected_id =
                                        session.selection_buffer.iter().next().unwrap();

                                    // Check existence, because selection buffer can
                                    // become outdated with undo/redo.
                                    if let Some(sync_source_entity) =
                                        session.entities.get(*selected_id)
                                    {
                                        sync_data_from_entity = Some((
                                            *sync_source_entity,
                                            EntityDataSyncFlags::VOLUMES,
                                            dialog.current_level_only,
                                        ));

                                        close = true;
                                    }
                                }
                            }

                            if close {
                                self.show_dialog = None;
                            }
                        } else {
                            guise::text(frame, line!(), "Select exactly one entity");
                        }
                    }
                }

                guise::end_window(frame)
            }
            None => (),
        }

        if !self.notifications.is_empty() {
            let mut removed_count = 0;
            for i in 0..self.notifications.len() {
                let index = i - removed_count;
                if self.notifications[index].0 < self.time {
                    self.notifications.remove(index);
                    removed_count += 1;
                }
            }

            guise::Window::new(line!(), "35%", 5.0, "30%", 200.0)
                .set_movable(false)
                .set_resizable(false)
                .begin(frame);

            for (i, (time, notification)) in self.notifications.iter().enumerate() {
                if self.time <= *time {
                    guise::text(frame, cast_u32!(i), notification);
                }
            }

            guise::end_window(frame);
        }

        self.ui.end_frame();

        if close_session {
            self.close_current_session();
        }

        if let Some(open_level) = open_level {
            self.open_level_session(open_level, temp_allocator, platform, asset_catalog, input);
        }

        if let Some(session_open_request) = self.session_open_request.take() {
            self.open_level_session(
                session_open_request,
                temp_allocator,
                platform,
                asset_catalog,
                input,
            );
        }

        if save_level {
            self.save_current_level(temp_allocator, platform, asset_catalog);
            self.last_level_list_reload = self.time;
            *asset_reload_flags |= AssetReloadFlags::LEVELSETS;
        }

        if let Some(save_level_as) = save_level_as {
            self.save_current_level_as(
                save_level_as,
                temp_allocator,
                platform,
                asset_catalog,
                input,
            );
            self.last_level_list_reload = self.time;
            *asset_reload_flags |= AssetReloadFlags::LEVELSETS;
        }

        if let Some((sync_source_entity, flags, current_level_only)) = sync_data_from_entity {
            self.sync_data_from_entity(
                &sync_source_entity,
                flags,
                current_level_only,
                temp_allocator,
                platform,
                asset_catalog,
            );
        }

        transition
    }

    // TODO(yan): While Game::update and Editor::update are quite different, the
    // rendering is a bit less different. Can we extract parts of the rendering
    // into common scene rendering code?
    pub fn render<R>(
        &mut self,
        temp_allocator: &Linear,
        renderer: &mut R,
        input: &Input,
        asset_catalog: &AssetCatalog,
    ) where
        R: Renderer,
    {
        profile_scope!("Editor::render");

        let session = match self.session_name {
            Some(session_name) => self.sessions.get_mut(&session_name).unwrap(),
            None => &mut self.scratch_session,
        };

        if let Some(mut frame) = renderer.begin_frame(
            [0.04, 0.04, 0.08, 1.0],
            1.0,
            session.camera.view_matrix(),
            session.camera.projection_matrix(),
            session.render_mode,
            if self.key_tab_down {
                0xffffff40
            } else {
                0xffffffff
            },
        ) {
            let mut draw3d_rect_commands = Vec::with_capacity_in(1024, temp_allocator);
            let mut draw3d_voxel_primitives = Vec::with_capacity_in(1024, temp_allocator);
            let mut draw3d_debug_commands = Vec::with_capacity_in(1024, temp_allocator);

            const FLAG_TOP: u8 = 0x01;
            const FLAG_BOTTOM: u8 = 0x02;
            const FLAG_FRONT: u8 = 0x04;
            const FLAG_BACK: u8 = 0x08;
            const FLAG_LEFT: u8 = 0x10;
            const FLAG_RIGHT: u8 = 0x20;

            let entity_grid = build_entity_grid(temp_allocator, &session.entities);
            let mut volume_grid: Grid<u8, _> =
                Grid::with_aabb_in(entity_grid.min(), entity_grid.max(), temp_allocator);

            fn detect_water_edges(
                volume_grid: &mut Grid<u8, &Linear>,
                entity_grid: &Grid<ArrayVec<(Id, EntityType), 4>, &Linear>,
                position: IVec3,
            ) {
                for (direction, direction_flag) in [
                    (-IVec3::Z, FLAG_BOTTOM),
                    (IVec3::Z, FLAG_TOP),
                    (-IVec3::Y, FLAG_FRONT),
                    (IVec3::Y, FLAG_BACK),
                    (-IVec3::X, FLAG_LEFT),
                    (IVec3::X, FLAG_RIGHT),
                ] {
                    let neighbor_position = position + direction;

                    // Draw water edges at the edge of the map.
                    if !entity_grid.is_in_bounds(neighbor_position) {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }

                    let mut neighbor_contains_water_or_ground = false;
                    for &(_, entity_ty) in &entity_grid[neighbor_position] {
                        if entity_ty == EntityType::Water || entity_ty == EntityType::Ground {
                            neighbor_contains_water_or_ground = true;
                        }
                    }

                    // Draw water edges if the neighboring tile has no water nor ground.
                    if !neighbor_contains_water_or_ground {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }
                }
            }

            fn detect_ground_edges(
                volume_grid: &mut Grid<u8, &Linear>,
                entity_grid: &Grid<ArrayVec<(Id, EntityType), 4>, &Linear>,
                position: IVec3,
            ) {
                for (direction, direction_flag) in [
                    (-IVec3::Z, FLAG_BOTTOM),
                    (IVec3::Z, FLAG_TOP),
                    (-IVec3::Y, FLAG_FRONT),
                    (IVec3::Y, FLAG_BACK),
                    (-IVec3::X, FLAG_LEFT),
                    (IVec3::X, FLAG_RIGHT),
                ] {
                    let neighbor_position = position + direction;

                    // Draw water edges at the edge of the map.
                    if !entity_grid.is_in_bounds(neighbor_position) {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }

                    let mut neighbor_contains_ground = false;
                    for &(_, entity_ty) in &entity_grid[neighbor_position] {
                        if entity_ty == EntityType::Ground {
                            neighbor_contains_ground = true;
                        }
                    }

                    // Draw water edges if the neighboring tile has no ground.
                    if !neighbor_contains_ground {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }
                }
            }

            for (_, entity) in &session.entities {
                match entity.ty {
                    EntityType::Water => {
                        detect_water_edges(&mut volume_grid, &entity_grid, entity.position);
                    }
                    EntityType::Ground => {
                        detect_ground_edges(&mut volume_grid, &entity_grid, entity.position);
                    }
                    _ => (),
                }
            }

            let missing_anim = Animation {
                texture_id: asset::ID_MISSING_TEX,
                frame: IRect::ONE,
            };

            for (entity_id, entity) in &session.entities {
                let entity_position = entity.position.as_vec3();
                let color_mul = if session.eraser_buffer.contains(&entity_id) {
                    color_u32([255, 255, 255, 75])
                } else {
                    color_u32([255, 255, 255, 255])
                };
                let color_add = if session.selection_add_buffer.contains(&entity_id) {
                    color_u32([25, 25, 25, 0])
                } else if session.highlight_id == Some(entity_id) {
                    color_u32([5, 5, 5, 0])
                } else {
                    color_u32([0, 0, 0, 0])
                };

                if entity.volume_idle != asset::ID_MISSING_VOLUME {
                    let (header, data) = asset_catalog
                        .volume_catalog
                        .get(entity.volume_idle)
                        .unwrap();
                    for z in 0..header.size_z {
                        for y in 0..header.size_y {
                            for x in 0..header.size_x {
                                let color_base = match data {
                                    XRawDataRef::VoxelIndexed8PaletteRgbaU8(voxels, colors) => {
                                        let voxel_index = xraw::position_to_index(&header, x, y, z);
                                        let color_index = voxels[voxel_index];

                                        if color_index == xraw::XRAW_VOXEL_INDEX_EMPTY_8 {
                                            continue;
                                        }

                                        let color = colors[usize::from(color_index)];

                                        color
                                    }
                                    XRawDataRef::VoxelIndexed16PaletteRgbaU8(voxels, colors) => {
                                        let voxel_index = xraw::position_to_index(&header, x, y, z);
                                        let color_index = voxels[voxel_index];

                                        if color_index == xraw::XRAW_VOXEL_INDEX_EMPTY_16 {
                                            continue;
                                        }

                                        let color = colors[usize::from(color_index)];

                                        color
                                    }
                                };

                                let color = {
                                    let color_base = Color::from_array_srgb(color_base.0);
                                    let color_mul = Color::from_u32(color_mul);
                                    let color_add = Color::from_u32(color_add);

                                    let color = color_base * color_mul + color_add;

                                    // Color in XRAW is RGBA, but we can only
                                    // smuggle it to the gpu as a u32, which is
                                    // ABGR on LE platforms and RGBA on BE
                                    // platforms. We could read it reveresed on
                                    // the shader, but for consistency our
                                    // shader colors are native endian u32s
                                    // (ABGR on LE), so we flip (in
                                    // Color::into_u32).
                                    //
                                    // TODO(yan): @Speed @AssetBuild do both the
                                    // the byte swaps in the asset build, and
                                    // possibly also the srgb conversion, if do
                                    // not end up using a sRGB texture.
                                    //
                                    // TODO(yan): @Correctness By bringing the
                                    // texture out of sRGB AND packing the float
                                    // back to a byte we loose color precision
                                    // in dark colors. Should we be sending the
                                    // color to the GPU as vec4? Or should we be
                                    // decoding sRGB on the GPU?
                                    color.into_u32()
                                };

                                let scale = vec3(
                                    1.0 / header.size_x as f32,
                                    1.0 / header.size_y as f32,
                                    1.0 / header.size_z as f32,
                                );

                                let x = x as f32;
                                let y = y as f32;
                                let z = z as f32;

                                let offset = scale * (vec3(x, y, z) + 0.5) - 0.5;
                                let m = Mat4::from_scale_rotation_translation(
                                    scale,
                                    Quat::IDENTITY,
                                    entity_position + offset,
                                );

                                draw3d_voxel_primitives.push(Draw3DVoxelPrimitive {
                                    transform_matrix: m,
                                    color,
                                    _pad0: 0,
                                    _pad1: 0,
                                    _pad2: 0,
                                });
                            }
                        }
                    }
                } else {
                    match gameplay::get_entity_initial_running_anims(entity, missing_anim) {
                        RunningAnimations::Prop(anim) => {
                            let rotation = -90.0_f32.to_radians() + camera::DEFAULT_INCLINATION_INV;
                            let m = Mat4::from_rotation_translation(
                                Quat::from_rotation_x(rotation),
                                entity_position,
                            );

                            draw3d_rect_commands.push(Draw3DRectPrimitive {
                                transform_matrix: m,
                                texture_rect: anim.frame.as_rect(),
                                texture_id: anim.texture_id.into_raw(),
                                color_mul,
                                color_add,
                            });
                        }
                        RunningAnimations::Volume(anim) => {
                            let join_volume_edges =
                                entity.ty == EntityType::Water || entity.ty == EntityType::Ground;

                            let volume_flags = volume_grid[entity.position];

                            // TODO(yan): @Speed @Memory Do not depend GPU face
                            // culling for backward facing faces. We have all the
                            // information here, so just don't emit the draw
                            // command.

                            const INWARD: VolumeAnimationDirections =
                                VolumeAnimationDirections::INWARD;
                            const OUTWARD: VolumeAnimationDirections =
                                VolumeAnimationDirections::OUTWARD;
                            let top_offset_inv = 0.5 - anim.top_offset;
                            let sides_offset_inv = 0.5 - anim.sides_offset;
                            let bottom_offset_inv = 0.5 - anim.bottom_offset;

                            if !join_volume_edges || volume_flags & FLAG_TOP != 0 {
                                if let Some(top) = anim.top {
                                    if anim.top_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(-90.0_f32.to_radians()),
                                            entity_position + top_offset_inv * Vec3::Z,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: top.frame.as_rect(),
                                            texture_id: top.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }

                                    if anim.top_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(90.0_f32.to_radians()),
                                            entity_position + top_offset_inv * Vec3::Z,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: top.frame.as_rect(),
                                            texture_id: top.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_LEFT != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(-90.0_f32.to_radians()),
                                            entity_position - sides_offset_inv * Vec3::X,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(90.0_f32.to_radians()),
                                            entity_position - sides_offset_inv * Vec3::X,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_RIGHT != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(90.0_f32.to_radians()),
                                            entity_position + sides_offset_inv * Vec3::X,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(-90.0_f32.to_radians()),
                                            entity_position + sides_offset_inv * Vec3::X,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_FRONT != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_translation(
                                            entity_position - sides_offset_inv * Vec3::Y,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(180.0_f32.to_radians()),
                                            entity_position - sides_offset_inv * Vec3::Y,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_BACK != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(180.0_f32.to_radians()),
                                            entity_position + sides_offset_inv * Vec3::Y,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_translation(
                                            entity_position + sides_offset_inv * Vec3::Y,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_BOTTOM != 0 {
                                if let Some(bottom) = anim.bottom {
                                    if anim.bottom_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(90.0_f32.to_radians()),
                                            entity_position - bottom_offset_inv * Vec3::Z,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: bottom.frame.as_rect(),
                                            texture_id: bottom.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }

                                    if anim.bottom_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(-90.0_f32.to_radians()),
                                            entity_position - bottom_offset_inv * Vec3::Z,
                                        );

                                        draw3d_rect_commands.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: bottom.frame.as_rect(),
                                            texture_id: bottom.texture_id.into_raw(),
                                            color_mul,
                                            color_add,
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
            }

            for &position in &session.brush_buffer {
                let m = Mat4::from_scale_rotation_translation(
                    vec3(0.4, 0.4, 0.4),
                    Quat::IDENTITY,
                    position.as_vec3(),
                );

                draw3d_debug_commands.push(Draw3DDebugOutlinePrimitive {
                    transform_matrix: m,
                    color: color_u32([100, 200, 100, 100]),
                    _pad0: 0,
                    _pad1: 0,
                    _pad2: 0,
                });
            }

            for entity_id in &session.selection_buffer {
                // Check existence, because selection buffer can
                // become outdated with undo/redo.
                if let Some(entity) = session.entities.get(*entity_id) {
                    let position = entity.position;
                    let m = Mat4::from_scale_rotation_translation(
                        Vec3::ONE,
                        Quat::IDENTITY,
                        position.as_vec3(),
                    );

                    draw3d_debug_commands.push(Draw3DDebugOutlinePrimitive {
                        transform_matrix: m,
                        color: color_u32([200, 100, 200, 200]),
                        _pad0: 0,
                        _pad1: 0,
                        _pad2: 0,
                    });
                }
            }

            {
                let (level_min, level_max) = build_level_bounds(&session.entities);
                let min = level_min.as_vec3();
                let max = level_max.as_vec3();
                let diagonal = max - min;
                let half_diagonal = diagonal / 2.0;
                let center = min + half_diagonal;
                let scale = diagonal + 1.0;

                let m = Mat4::from_scale_rotation_translation(scale, Quat::IDENTITY, center);

                draw3d_debug_commands.push(Draw3DDebugOutlinePrimitive {
                    transform_matrix: m,
                    color: color_u32([255, 255, 255, 50]),
                    _pad0: 0,
                    _pad1: 0,
                    _pad2: 0,
                });
            }

            draw3d_rect_commands.extend(&self.draw_3d_rect_commands);

            frame.draw_3d_rects_to_intermediate(&draw3d_rect_commands);
            frame.draw_3d_voxels_to_intermediate(&draw3d_voxel_primitives);
            frame.draw_3d_debug_outlines_to_intermediate(&draw3d_debug_commands);
            if let Some(start) = self.rectangle_select_start {
                let end = input.physical_cursor_position;
                if start.distance_squared(end) > RECTANGLE_SELECT_THRESHOLD_SQUARED {
                    let rect = Rect::from_points(start, end);

                    frame.draw_2d_rects_to_intermediate(
                        &[Draw2DRectCommand {
                            primitive_count: 1,
                            texture_id: asset::ID_EDITOR_FONT_ATLAS_TEX.into_raw(),
                        }],
                        &[Draw2DRectPrimitive {
                            rect,
                            texture_rect: Rect::ZERO,
                            color: color_u32([100, 255, 100, 10]),
                        }],
                    );
                }
            }

            frame.blit_intermediate_to_surface();

            let (ui_commands, ui_vertices, ui_indices) = self.ui.draw_list();
            frame.draw_ui_to_surface(
                bytemuck::cast_slice(ui_commands),
                bytemuck::cast_slice(ui_vertices),
                ui_indices,
            );

            frame.submit_and_present();
        }
    }

    pub fn open_level(&mut self, asset_catalog: &AssetCatalog, level_id: AssetId) {
        if let Some(manifest_entry) = asset_catalog.manifest.get(&level_id) {
            let level_name = manifest_entry.name;
            if manifest_entry.ty == AssetType::Level {
                self.session_open_request = Some(level_name);
            } else {
                let ty = manifest_entry.ty;
                log::error!("Level {level_name} stored in manifest under a type {ty}!");
            }
        } else {
            log::error!("Level ID {level_id} not found in asset manifest!");
        }
    }

    fn close_current_session(&mut self) {
        if let Some(session_name) = self.session_name {
            self.sessions.remove(&session_name);
            let idx = self
                .sessions_order
                .iter()
                .position(|name| *name == session_name)
                .unwrap();

            self.sessions_order.remove(idx);

            let sessions_order_len = self.sessions_order.len();
            if sessions_order_len == 0 {
                // Go back to scratch session
                self.session_name = None;
            } else if sessions_order_len == idx {
                // We removed the last session in the order, pick the previous
                // session as the currently open one.
                assert!(idx > 0);
                let new_session_name = self.sessions_order[idx - 1];
                self.session_name = Some(new_session_name);
            } else {
                // We removed a level from the beginning or middle. Open the
                // subsequent open level.
                let new_session_name = self.sessions_order[idx];
                self.session_name = Some(new_session_name);
            }
        }
    }

    fn open_level_session<P>(
        &mut self,
        level_name: AssetName,
        temp_allocator: &Linear,
        platform: &P,
        asset_catalog: &AssetCatalog,
        input: &Input,
    ) where
        P: Platform,
    {
        // Only open level if we don't already have it open. Otherwise, just
        // switch to that level's session.
        match self.sessions.entry(level_name) {
            Entry::Occupied(_) => {
                log::info!("Level {level_name} already open, switching...");
                self.session_name = Some(level_name);
            }
            Entry::Vacant(entry) => {
                log::info!("Loading level {level_name}...");

                let mut path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
                path.push_str(&level_name);
                path.push_str(".ph_level");

                let level_bytes = platform
                    .read_file(temp_allocator, &path)
                    .unwrap_or_else(|_| Vec::new_in(temp_allocator));
                let level_str = str::from_utf8(&level_bytes).unwrap_or("");

                match asset_catalog::deserialize_and_migrate_level(temp_allocator, level_str) {
                    Ok(level_asset) => {
                        let mut camera = Camera::new(
                            self.time.as_secs_f32(),
                            input.physical_window_size,
                            vec3(0.0, -10.0, 1.0),
                            90.0_f32.to_radians(),
                            90.0_f32.to_radians(),
                            CameraOptions {
                                fovy: 45.0_f32.to_radians(),
                                znear: 0.1,
                                zfar: 1000.0,
                                unsteadiness: 0.0,
                            },
                        );

                        let mut entities: IdMap<EntityInit, _> =
                            IdMap::with_capacity_in(level_asset.entities.len(), Global);

                        for entity in level_asset.entities {
                            entities
                                .insert(asset_catalog::revive_entity_init(&entity, asset_catalog));
                        }

                        let (level_min, level_max) = build_level_bounds(&entities);
                        setup_camera_for_level(&mut camera, level_min, level_max);

                        self.session_name = Some(level_name);
                        self.sessions_order.push(level_name);

                        entry.insert(Session {
                            editor_mode: EditorMode::Select,
                            modified: false,

                            camera,

                            history: History::with_capacity_in(HISTORY_CAPACITY, Global),
                            entities,

                            highlight_id: None,
                            selection_add_buffer: HashSet::new(),
                            selection_buffer: HashSet::new(),
                            eraser_buffer: HashSet::new(),
                            brush_buffer: HashSet::new(),

                            text_edit_buffer: guise::AsciiArrayVec::new(),

                            render_mode: RenderMode::Game,
                        });
                    }
                    Err(err) => {
                        self.notifications.push((
                            self.time + NOTIFICATION_DURATION,
                            format!("Failed to deserialize level: {level_name} (see log)"),
                        ));

                        log::error!("Failed to deserialize level: {err}");
                    }
                }
            }
        }
    }

    fn save_current_level<P>(
        &mut self,
        temp_allocator: &Linear,
        platform: &P,
        asset_catalog: &AssetCatalog,
    ) where
        P: Platform,
    {
        // Save can only happen to already existing sessions, not the scratch
        // session.
        let session_name = self.session_name.unwrap();
        let mut session = self.sessions.get_mut(&session_name).unwrap();

        let mut entities = Vec::new_in(temp_allocator);
        for (_, entity) in &session.entities {
            entities.push(asset_catalog::flatten_entity_init(entity, asset_catalog));
        }

        let level_bytes = asset_catalog::serialize_level(
            temp_allocator,
            asset_catalog::vcurrent::LevelAssetSer { entities },
        );

        let mut path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
        path.push_str(&session_name);
        path.push_str(".ph_level");

        match platform.write_file(temp_allocator, &path, &level_bytes) {
            Ok(()) => {
                self.notifications.push((
                    self.time + NOTIFICATION_DURATION,
                    format!("Saved level: {session_name}"),
                ));
                session.modified = false;
            }
            Err(err) => {
                self.notifications.push((
                    self.time + NOTIFICATION_DURATION,
                    format!("Failed to save level: {session_name} (see log)"),
                ));

                log::error!("Failed to save level, error: {err}");
            }
        }
    }

    fn save_current_level_as<P>(
        &mut self,
        level_name: AssetName,
        temp_allocator: &Linear,
        platform: &P,
        asset_catalog: &AssetCatalog,
        input: &Input,
    ) where
        P: Platform,
    {
        if level_name.is_empty() {
            self.notifications.push((
                self.time + NOTIFICATION_DURATION,
                String::from("Failed to save level: name is empty"),
            ));

            return;
        }

        match self.session_name {
            Some(session_name) => {
                let mut session = self.sessions.get_mut(&session_name).unwrap();

                if session_name == level_name {
                    // If level name did not change, this is basically a save.

                    let mut entities = Vec::new_in(temp_allocator);
                    for (_, entity) in &session.entities {
                        entities.push(asset_catalog::flatten_entity_init(entity, asset_catalog));
                    }

                    let level_bytes = asset_catalog::serialize_level(
                        temp_allocator,
                        asset_catalog::vcurrent::LevelAssetSer { entities },
                    );

                    let mut path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
                    path.push_str(&level_name);
                    path.push_str(".ph_level");

                    match platform.write_file(temp_allocator, &path, &level_bytes) {
                        Ok(()) => {
                            self.notifications.push((
                                self.time + NOTIFICATION_DURATION,
                                format!("Saved level: {session_name}"),
                            ));
                            session.modified = false;
                        }
                        Err(err) => {
                            self.notifications.push((
                                self.time + NOTIFICATION_DURATION,
                                format!("Failed to save level: {session_name} (see log)"),
                            ));

                            log::error!("Failed to save level, error: {err}");
                        }
                    }
                } else {
                    // If the name did change, and if successful, we keep both
                    // sessions open, mark both as unmodified. Changes are
                    // preserved in the spin-off session.

                    let mut entities = Vec::new_in(temp_allocator);
                    for (_, entity) in &session.entities {
                        entities.push(asset_catalog::flatten_entity_init(entity, asset_catalog));
                    }

                    let level_bytes = asset_catalog::serialize_level(
                        temp_allocator,
                        asset_catalog::vcurrent::LevelAssetSer { entities },
                    );

                    let mut path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
                    path.push_str(&level_name);
                    path.push_str(".ph_level");

                    match platform.write_new_file(temp_allocator, &path, &level_bytes) {
                        Ok(()) => {
                            self.notifications.push((
                                self.time + NOTIFICATION_DURATION,
                                format!("Saved level as: {level_name}"),
                            ));
                            session.modified = false;

                            let spinoff_session = session.clone();

                            self.sessions.insert(level_name, spinoff_session);
                            self.sessions_order.push(level_name);
                            self.session_name = Some(level_name);

                            // TODO(yan): Instead of closing the original
                            // session, restore it to last saved snapshot -
                            // either reload from filesystem, save the snapshot
                            // when we load the session, or use the undo system.
                            self.sessions.remove(&session_name).unwrap();
                            let idx = self
                                .sessions_order
                                .iter()
                                .position(|name| *name == session_name)
                                .unwrap();
                            self.sessions_order.remove(idx);
                        }
                        Err(err) => {
                            self.notifications.push((
                                self.time + NOTIFICATION_DURATION,
                                format!("Failed to save level as: {level_name} (see log)"),
                            ));

                            log::error!("Failed to save level as, error: {err}");
                        }
                    }
                }
            }
            None => {
                if self.sessions.contains_key(&level_name) {
                    self.notifications.push((
                        self.time + NOTIFICATION_DURATION,
                        format!("Failed to save level as: name {level_name} already exists"),
                    ));

                    return;
                }

                let session = &mut self.scratch_session;

                let mut entities = Vec::new_in(temp_allocator);
                for (_, entity) in &session.entities {
                    entities.push(asset_catalog::flatten_entity_init(entity, asset_catalog));
                }

                let level_bytes = asset_catalog::serialize_level(
                    temp_allocator,
                    asset_catalog::vcurrent::LevelAssetSer { entities },
                );

                let mut path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
                path.push_str(&level_name);
                path.push_str(".ph_level");

                match platform.write_new_file(temp_allocator, &path, &level_bytes) {
                    Ok(()) => {
                        self.notifications.push((
                            self.time + NOTIFICATION_DURATION,
                            format!("Saved level as: {level_name}"),
                        ));
                        session.modified = false;

                        let saved_session = mem::replace(
                            &mut self.scratch_session,
                            scratch_session(self.time, input.physical_window_size),
                        );

                        self.sessions.insert(level_name, saved_session);
                        self.sessions_order.push(level_name);
                        self.session_name = Some(level_name);
                    }
                    Err(err) => {
                        self.notifications.push((
                            self.time + NOTIFICATION_DURATION,
                            format!("Failed to save level as: {level_name} (see log)"),
                        ));

                        log::error!("Failed to save level as, error: {err}");
                    }
                }
            }
        };
    }

    fn sync_data_from_entity<P>(
        &mut self,
        sync_source_entity: &EntityInit,
        sync_flags: EntityDataSyncFlags,
        sync_current_level_only: bool,
        temp_allocator: &Linear,
        platform: &P,
        asset_catalog: &AssetCatalog,
    ) where
        P: Platform,
    {
        let any_session_modified = self.sessions.values().any(|session| session.modified);
        assert!(!any_session_modified);

        // TODO(yan): @Correctness @Memory @Cleanup we use temp_allocator in a
        // loop without resetting and our usage patterns do not allow
        // reclamation, but we iterate across all the levels here, which will
        // eventually be a big number. Linear::scope_checked for this!
        for levelset_entry in &asset_catalog.levelset_catalog[asset::ID_IMPLICIT_LEVELSET] {
            let level_name = levelset_entry.level_name;
            if sync_current_level_only && Some(level_name) != self.session_name {
                continue;
            }

            let mut path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
            path.push_str(&level_name);
            path.push_str(".ph_level");

            if let Some(session) = self.sessions.get_mut(&level_name) {
                let mut entities_prev =
                    IdMap::with_capacity_in(session.entities.len(), temp_allocator);
                entities_prev.clone_from(&session.entities);

                for (_, entity) in &mut session.entities {
                    if sync_flags.intersects(EntityDataSyncFlags::ANIMATIONS) {
                        sync_animations(entity, sync_source_entity);
                    }

                    if sync_flags.intersects(EntityDataSyncFlags::VOLUMES) {
                        sync_volumes(entity, sync_source_entity);
                    }
                }

                // If we fail, the session stays marked as modified. We also
                // record undo for this.
                //
                // TODO(yan): @Speed Consider producing a concrete change-set
                // here, although it matters less than in other places.
                session.modified = true;
                push_transaction(
                    temp_allocator,
                    &mut session.history,
                    &session.entities,
                    &entities_prev,
                );

                let mut entities = Vec::new_in(temp_allocator);
                for (_, entity) in &session.entities {
                    entities.push(asset_catalog::flatten_entity_init(entity, asset_catalog));
                }

                let level_bytes = asset_catalog::serialize_level(
                    temp_allocator,
                    asset_catalog::vcurrent::LevelAssetSer { entities },
                );

                match platform.write_file(temp_allocator, &path, &level_bytes) {
                    Ok(()) => {
                        self.notifications.push((
                            self.time + NOTIFICATION_DURATION,
                            format!("Synced data for level: {level_name}"),
                        ));
                        session.modified = false;
                    }
                    Err(err) => {
                        self.notifications.push((
                            self.time + NOTIFICATION_DURATION,
                            format!("Data sync failed to save level: {level_name} (see log)"),
                        ));

                        log::error!("Data sync failed to save level, error: {err}");
                    }
                }
            } else {
                // If there is no session for this level, it can't be current.
                if sync_current_level_only {
                    continue;
                }

                let level_bytes = platform
                    .read_file(temp_allocator, &path)
                    .unwrap_or_else(|_| Vec::new_in(temp_allocator));
                let level_str = str::from_utf8(&level_bytes).unwrap_or("");

                match asset_catalog::deserialize_and_migrate_level(temp_allocator, level_str) {
                    Ok(level_asset) => {
                        let mut entities = Vec::new_in(temp_allocator);

                        for entity in level_asset.entities {
                            let mut entity =
                                asset_catalog::revive_entity_init(&entity, asset_catalog);

                            if sync_flags.intersects(EntityDataSyncFlags::ANIMATIONS) {
                                sync_animations(&mut entity, sync_source_entity);
                            }

                            if sync_flags.intersects(EntityDataSyncFlags::VOLUMES) {
                                sync_volumes(&mut entity, sync_source_entity);
                            }

                            entities
                                .push(asset_catalog::flatten_entity_init(&entity, asset_catalog));
                        }

                        let level_bytes = asset_catalog::serialize_level(
                            temp_allocator,
                            asset_catalog::vcurrent::LevelAssetSer { entities },
                        );

                        match platform.write_file(temp_allocator, &path, &level_bytes) {
                            Ok(()) => {
                                self.notifications.push((
                                    self.time + NOTIFICATION_DURATION,
                                    format!("Synced data for level: {level_name}"),
                                ));
                            }
                            Err(err) => {
                                self.notifications.push((
                                    self.time + NOTIFICATION_DURATION,
                                    format!(
                                        "Data sync failed to save level: {level_name} (see log)"
                                    ),
                                ));

                                log::error!("Data sync failed to save level, error: {err}");
                            }
                        }
                    }
                    Err(err) => {
                        self.notifications.push((
                            self.time + NOTIFICATION_DURATION,
                            format!(
                                "Data sync failed to deserialize level: {level_name} (see log)"
                            ),
                        ));

                        log::error!("Data sync failed to deserialize level: {err}");
                    }
                }
            }
        }
    }
}

// TODO(yan): Preview currently edited animations. Either have a checkbox that
// selects an animation to display in editor OR temporarily change preview to
// currently editited animation while the UI controls for that animation are
// active.
fn draw_entity_editor<A: Allocator + Clone>(
    frame: &mut guise::Frame<A>,
    id: u32,
    text_edit_buffer: &mut guise::AsciiArrayVec<32>,
    selection_buffer: &mut HashSet<Id, DefaultHashBuilder, Global>,
    entities: &mut IdMap<EntityInit, Global>,
    asset_catalog: &AssetCatalog,
) -> bool {
    let mut modified = false;
    let selected_count = selection_buffer.len();

    let mut s: ArrayString<1024> = ArrayString::new();

    guise::Panel::new(id, "100%", 0.0)
        .set_resize_height_to_fit_content(true)
        .begin(frame);

    guise::text(
        frame,
        line!(),
        fmt!(s, "Edit Entity: Selected {} entities", selected_count),
    );

    if selected_count == 1 {
        let selected_id = selection_buffer.iter().next().unwrap();

        // Check existence, because selection buffer can become outdated with
        // undo/redo.
        if let Some(selected_entity) = entities.get_mut(*selected_id) {
            // TODO(yan): Generate entity edit UI with metaprogramming.

            guise::text(frame, line!(), fmt!(s, "Entity ID: {}", selected_id.idx()));

            let mut selected_ty_index = Some(selected_entity.ty.index());
            guise::dropdown(
                frame,
                line!(),
                "Entity Type",
                EntityType::names(),
                &mut selected_ty_index,
            );
            if let Some(ty_index) = selected_ty_index {
                if selected_entity.ty != EntityType::from_index(ty_index) {
                    let entity_ty = EntityType::from_index(ty_index);
                    let entity_data = EntityDataInit::default_for_entity_ty(entity_ty);

                    selected_entity.ty = entity_ty;
                    selected_entity.data = entity_data;

                    modified = true;
                }
            }

            // Note: @AddEntity @Derive
            match EntityDataInit::from_entity_init_mut(selected_entity) {
                EntityDataInit::Wizard(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_front,
                        "anim_front",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_back,
                        "anim_back",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_left,
                        "anim_left",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_right,
                        "anim_right",
                        asset_catalog,
                    );
                }
                EntityDataInit::Exit(data) => {
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::Water(data) => {
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::Ground(data) => {
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::Tree(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::WoodenCrate(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::IronCrate(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::Key(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                }
                EntityDataInit::KeyGate(data) => {
                    modified |= guise::checkbox(frame, line!(), &mut data.open, "Open");
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_open,
                        "anim_open",
                        asset_catalog,
                    );
                }
                EntityDataInit::TranspositionStone(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_active,
                        "anim_active",
                        asset_catalog,
                    );
                }
                EntityDataInit::SummoningStone(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_active,
                        "anim_active",
                        asset_catalog,
                    );
                }
                EntityDataInit::FamiliarCat(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_front,
                        "anim_front",
                        asset_catalog,
                    );
                    draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_back,
                        "anim_back",
                        asset_catalog,
                    );
                    draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_left,
                        "anim_left",
                        asset_catalog,
                    );
                    draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_right,
                        "anim_right",
                        asset_catalog,
                    );
                }
                EntityDataInit::SkellyWarrior(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_front,
                        "anim_front",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_back,
                        "anim_back",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_left,
                        "anim_left",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_right,
                        "anim_right",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_front,
                        "anim_aggro_front",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_back,
                        "anim_aggro_back",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_left,
                        "anim_aggro_left",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_right,
                        "anim_aggro_right",
                        asset_catalog,
                    );
                }
                EntityDataInit::SkellyArcher(data) => {
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_front,
                        "anim_front",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_back,
                        "anim_back",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_left,
                        "anim_left",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_right,
                        "anim_right",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_front,
                        "anim_aggro_front",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_back,
                        "anim_aggro_back",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_left,
                        "anim_aggro_left",
                        asset_catalog,
                    );
                    modified |= draw_prop_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_aggro_right,
                        "anim_aggro_right",
                        asset_catalog,
                    );
                }
                EntityDataInit::PressurePlate(data) => {
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_pressed,
                        "anim_pressed",
                        asset_catalog,
                    );
                }
                EntityDataInit::PressurePlateGate(data) => {
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim,
                        "anim",
                        asset_catalog,
                    );
                    modified |= draw_volume_animation_editor(
                        frame,
                        line!(),
                        &mut data.anim_open,
                        "anim_open",
                        asset_catalog,
                    );

                    // XXX: open_if_active

                    if let Some((op, id)) = &mut data.open_if_active[0] {
                        let mut op_selected_index = Some(op.index());
                        if guise::dropdown(
                            frame,
                            line!(),
                            "Unary Boolean OP",
                            UnaryBooleanOp::names(),
                            &mut op_selected_index,
                        ) {
                            if let Some(selected_index) = op_selected_index {
                                *op = UnaryBooleanOp::from_index(selected_index);
                            }
                        }

                        static mut BUFFER: guise::AsciiArrayVec<32> =
                            guise::AsciiArrayVec::const_new();
                        match guise::input_text(frame, line!(), unsafe { &mut BUFFER }, "ID") {
                            (_, guise::InputTextSubmit::None) => {}
                            (_, guise::InputTextSubmit::Submit) => {
                                log::debug!("XXX submit");
                            }
                            (_, guise::InputTextSubmit::Cancel) => {
                                log::debug!("XXX cancel");
                            }
                        }

                        if guise::button(frame, line!(), "Remove Connection") {
                            data.open_if_active[0] = None;
                        }
                    } else {
                        if guise::button(frame, line!(), "Create Connection") {
                            data.open_if_active[0] = Some((UnaryBooleanOp::Identity, *selected_id));
                        }
                    }

                    let mut open_if_active_op_selected_index = Some(data.open_if_active_op.index());
                    if guise::dropdown(
                        frame,
                        line!(),
                        "Binary Boolean OP",
                        BinaryBooleanOp::names(),
                        &mut open_if_active_op_selected_index,
                    ) {
                        if let Some(selected_index) = open_if_active_op_selected_index {
                            data.open_if_active_op = BinaryBooleanOp::from_index(selected_index);
                        }
                    }
                }
            }

            let mut position = selected_entity.position.to_array();
            modified |= guise::DragInt3::new(line!(), &mut position, "Position")
                .set_speed(DRAG_SPEED_FAST)
                .set_min(0)
                .show(frame);

            selected_entity.position = IVec3::from(position);

            let mut selected_bearing_index = i32::from(selected_entity.bearing);
            modified |= guise::DragInt::new(line!(), &mut selected_bearing_index, "Bearing")
                .set_speed(DRAG_SPEED_FAST)
                .set_min(0)
                .set_max(3)
                .show(frame);
            selected_entity.bearing =
                Bearing::try_from(selected_bearing_index).unwrap_or(Bearing::South);

            modified |= draw_volume_editor(
                frame,
                line!(),
                &mut selected_entity.volume_idle,
                "Idle Volume",
                asset_catalog,
            );
        }
    }

    guise::end_panel(frame);

    modified
}

fn draw_prop_animation_editor<A: Allocator + Clone>(
    frame: &mut guise::Frame<A>,
    id: u32,
    animation: &mut Option<Animation>,
    label: &str,
    asset_catalog: &AssetCatalog,
) -> bool {
    let mut modified = false;

    let mut texture_entries: ArrayVec<AssetDropdownEntry, 128> = ArrayVec::new();
    for (texture_name, texture_id) in &asset_catalog.textures_by_name {
        texture_entries.push(AssetDropdownEntry {
            asset_id: *texture_id,
            asset_name: *texture_name,
        });
    }

    texture_entries.sort_unstable_by_key(|entry| entry.asset_name);

    let mut create = false;
    let mut remove = false;

    guise::Panel::new(id, "100%", 0.0)
        .set_resize_height_to_fit_content(true)
        .begin(frame);

    guise::Text::new(line!(), label)
        .set_horizontal_align(guise::Align::Center)
        .show(frame);

    if let Some(animation) = animation {
        let mut selected_texture_idx =
            if let Some(manifest_entry) = asset_catalog.manifest.get(&animation.texture_id) {
                let idx = texture_entries
                    .iter()
                    .position(|entry| entry.asset_name == manifest_entry.name)
                    .unwrap();

                Some(idx)
            } else {
                Some(0)
            };

        remove = guise::button(frame, line!(), "Remove frame");

        modified |= guise::dropdown(
            frame,
            line!(),
            "Texture",
            &texture_entries,
            &mut selected_texture_idx,
        );

        // TODO(yan): @Cleanup Guise dropdown now supports unselect. Use it here!
        if let Some(selected_texture_idx) = selected_texture_idx {
            animation.texture_id = texture_entries[selected_texture_idx].asset_id;
        }

        modified |= draw_rect_editor(frame, line!(), &mut animation.frame);
    } else {
        create = guise::button(frame, line!(), "Create frame");
    }
    guise::end_panel(frame);

    if create {
        *animation = Some(Animation {
            texture_id: texture_entries[0].asset_id,
            frame: IRect::new(0, 0, 32, 32),
        });
        modified = true;
    }

    if remove {
        *animation = None;
        modified = true;
    }

    modified
}

fn draw_volume_animation_editor<A: Allocator + Clone>(
    frame: &mut guise::Frame<A>,
    id: u32,
    volume_animation: &mut Option<VolumeAnimation>,
    label: &str,
    asset_catalog: &AssetCatalog,
) -> bool {
    const INWARD: VolumeAnimationDirections = VolumeAnimationDirections::INWARD;
    const OUTWARD: VolumeAnimationDirections = VolumeAnimationDirections::OUTWARD;

    let mut modified = false;

    let mut texture_entries: ArrayVec<AssetDropdownEntry, 128> = ArrayVec::new();
    for (texture_name, texture_id) in &asset_catalog.textures_by_name {
        texture_entries.push(AssetDropdownEntry {
            asset_id: *texture_id,
            asset_name: *texture_name,
        });
    }

    texture_entries.sort_unstable_by_key(|entry| entry.asset_name);

    let mut create_volume = false;
    let mut remove_volume = false;
    let mut create: Option<&mut Option<Animation>> = None;
    let mut remove: Option<&mut Option<Animation>> = None;

    guise::Panel::new(id, "100%", 0.0)
        .set_resize_height_to_fit_content(true)
        .begin(frame);

    guise::Text::new(line!(), label)
        .set_horizontal_align(guise::Align::Center)
        .show(frame);

    if let Some(volume_animation) = volume_animation {
        if guise::button(frame, line!(), "Remove volume animation") {
            remove_volume = true;
        }

        if let Some(animation) = &mut volume_animation.top {
            let mut selected_texture_idx =
                if let Some(manifest_entry) = asset_catalog.manifest.get(&animation.texture_id) {
                    let idx = texture_entries
                        .iter()
                        .position(|entry| entry.asset_name == manifest_entry.name)
                        .unwrap();

                    Some(idx)
                } else {
                    Some(0)
                };

            let remove_anim = guise::button(frame, line!(), "Remove frame (top)");

            modified |= guise::dropdown(
                frame,
                line!(),
                "Texture",
                &texture_entries,
                &mut selected_texture_idx,
            );

            // TODO(yan): @Cleanup Guise dropdown now supports unselect. Use it here!
            if let Some(selected_texture_idx) = selected_texture_idx {
                animation.texture_id = texture_entries[selected_texture_idx].asset_id;
            }

            modified |= draw_rect_editor(frame, line!(), &mut animation.frame);

            let mut inward = volume_animation.top_directions.intersects(INWARD);
            let mut outward = volume_animation.top_directions.intersects(OUTWARD);

            modified |= guise::checkbox(frame, line!(), &mut inward, "Render inward");
            modified |= guise::checkbox(frame, line!(), &mut outward, "Render outward");
            modified |= guise::DragFloat::new(line!(), &mut volume_animation.top_offset, "Offset")
                .set_speed(DRAG_SPEED_PRECISE)
                .set_min(0.0)
                .set_max(0.5)
                .show(frame);

            let mut directions = VolumeAnimationDirections::NONE;
            if inward {
                directions |= INWARD;
            }
            if outward {
                directions |= OUTWARD;
            }
            volume_animation.top_directions = directions;

            if remove_anim {
                remove = Some(&mut volume_animation.top);
            }
        } else {
            if guise::button(frame, line!(), "Create frame (top)") {
                create = Some(&mut volume_animation.top);
            }
        }

        if let Some(animation) = &mut volume_animation.sides {
            let mut selected_texture_idx =
                if let Some(manifest_entry) = asset_catalog.manifest.get(&animation.texture_id) {
                    let idx = texture_entries
                        .iter()
                        .position(|entry| entry.asset_name == manifest_entry.name)
                        .unwrap();

                    Some(idx)
                } else {
                    Some(0)
                };

            let remove_anim = guise::button(frame, line!(), "Remove frame (sides)");

            modified |= guise::dropdown(
                frame,
                line!(),
                "Texture",
                &texture_entries,
                &mut selected_texture_idx,
            );

            // TODO(yan): @Cleanup Guise dropdown now supports unselect. Use it here!
            if let Some(selected_texture_idx) = selected_texture_idx {
                animation.texture_id = texture_entries[selected_texture_idx].asset_id;
            }

            modified |= draw_rect_editor(frame, line!(), &mut animation.frame);

            let mut inward = volume_animation.sides_directions.intersects(INWARD);
            let mut outward = volume_animation.sides_directions.intersects(OUTWARD);

            modified |= guise::checkbox(frame, line!(), &mut inward, "Render inward");
            modified |= guise::checkbox(frame, line!(), &mut outward, "Render outward");
            modified |=
                guise::DragFloat::new(line!(), &mut volume_animation.sides_offset, "Offset")
                    .set_speed(DRAG_SPEED_PRECISE)
                    .set_min(0.0)
                    .set_max(0.5)
                    .show(frame);

            let mut directions = VolumeAnimationDirections::NONE;
            if inward {
                directions |= INWARD;
            }
            if outward {
                directions |= OUTWARD;
            }
            volume_animation.sides_directions = directions;

            if remove_anim {
                remove = Some(&mut volume_animation.sides);
            }
        } else {
            if guise::button(frame, line!(), "Create frame (sides)") {
                create = Some(&mut volume_animation.sides);
            }
        }

        if let Some(animation) = &mut volume_animation.bottom {
            let mut selected_texture_idx =
                if let Some(manifest_entry) = asset_catalog.manifest.get(&animation.texture_id) {
                    let idx = texture_entries
                        .iter()
                        .position(|entry| entry.asset_name == manifest_entry.name)
                        .unwrap();

                    Some(idx)
                } else {
                    Some(0)
                };

            let remove_anim = guise::button(frame, line!(), "Remove frame (bottom)");

            modified |= guise::dropdown(
                frame,
                line!(),
                "Texture",
                &texture_entries,
                &mut selected_texture_idx,
            );

            // TODO(yan): @Cleanup Guise dropdown now supports unselect. Use it here!
            if let Some(selected_texture_idx) = selected_texture_idx {
                animation.texture_id = texture_entries[selected_texture_idx].asset_id;
            }

            modified |= draw_rect_editor(frame, line!(), &mut animation.frame);

            let mut inward = volume_animation.bottom_directions.intersects(INWARD);
            let mut outward = volume_animation.bottom_directions.intersects(OUTWARD);

            modified |= guise::checkbox(frame, line!(), &mut inward, "Render inward");
            modified |= guise::checkbox(frame, line!(), &mut outward, "Render outward");
            modified |=
                guise::DragFloat::new(line!(), &mut volume_animation.bottom_offset, "Offset")
                    .set_speed(DRAG_SPEED_PRECISE)
                    .set_min(0.0)
                    .set_max(0.5)
                    .show(frame);

            let mut directions = VolumeAnimationDirections::NONE;
            if inward {
                directions |= INWARD;
            }
            if outward {
                directions |= OUTWARD;
            }
            volume_animation.bottom_directions = directions;

            if remove_anim {
                remove = Some(&mut volume_animation.bottom);
            }
        } else {
            if guise::button(frame, line!(), "Create frame (bottom)") {
                create = Some(&mut volume_animation.bottom);
            }
        }
    } else {
        if guise::button(frame, line!(), "Create volume animation") {
            create_volume = true;
        }
    }

    guise::end_panel(frame);

    if let Some(animation) = create {
        *animation = Some(Animation {
            texture_id: texture_entries[0].asset_id,
            frame: IRect::new(0, 0, 32, 32),
        });
        modified = true;
    }

    if let Some(animation) = remove {
        *animation = None;
        modified = true;
    }

    if create_volume {
        *volume_animation = Some(VolumeAnimation {
            top: None,
            top_directions: VolumeAnimationDirections::OUTWARD,
            top_offset: 0.0,
            sides: None,
            sides_directions: VolumeAnimationDirections::OUTWARD,
            sides_offset: 0.0,
            bottom: None,
            bottom_directions: VolumeAnimationDirections::OUTWARD,
            bottom_offset: 0.0,
        });
        modified = true;
    }

    if remove_volume {
        *volume_animation = None;
        modified = true;
    }

    modified
}

fn draw_volume_editor<A: Allocator + Clone>(
    frame: &mut guise::Frame<A>,
    id: u32,
    volume_id: &mut AssetId,
    label: &str,
    asset_catalog: &AssetCatalog,
) -> bool {
    let mut modified = false;

    let mut volume_entries: ArrayVec<AssetDropdownEntry, 128> = ArrayVec::new();
    for (name, id) in &asset_catalog.volumes_by_name {
        volume_entries.push(AssetDropdownEntry {
            asset_id: *id,
            asset_name: *name,
        });
    }

    volume_entries.sort_unstable_by_key(|entry| entry.asset_name);

    guise::Panel::new(id, "100%", 0.0)
        .set_resize_height_to_fit_content(true)
        .begin(frame);

    guise::Text::new(line!(), label)
        .set_horizontal_align(guise::Align::Center)
        .show(frame);

    let mut selected_volume_idx = Some(
        volume_entries
            .iter()
            .position(|entry| entry.asset_id == *volume_id)
            .unwrap(),
    );

    modified |= guise::dropdown(
        frame,
        line!(),
        "Volume",
        &volume_entries,
        &mut selected_volume_idx,
    );

    if let Some(selected_volume_idx) = selected_volume_idx {
        *volume_id = volume_entries[selected_volume_idx].asset_id;
    }

    guise::end_panel(frame);

    modified
}

fn draw_rect_editor<A: Allocator + Clone>(
    frame: &mut guise::Frame<A>,
    id: u32,
    rect: &mut IRect,
) -> bool {
    let mut value = [rect.x, rect.y, rect.width, rect.height];

    let modified = guise::DragInt4::new(id, &mut value, "Frame Rect")
        .set_speed(DRAG_SPEED_FAST)
        .set_min(0)
        .show(frame);

    *rect = IRect::new(value[0], value[1], value[2], value[3]);

    modified
}

fn scratch_session(time: Time, physical_window_size: UVec2) -> Session {
    let mut camera = Camera::new(
        time.as_secs_f32(),
        physical_window_size,
        vec3(0.0, -10.0, 1.0),
        90.0_f32.to_radians(),
        90.0_f32.to_radians(),
        CameraOptions {
            fovy: 45.0_f32.to_radians(),
            znear: 0.1,
            zfar: 1000.0,
            unsteadiness: 0.0,
        },
    );

    setup_camera_for_empty_level(&mut camera);

    Session {
        editor_mode: EditorMode::Select,
        modified: false,

        camera,

        history: History::with_capacity_in(HISTORY_CAPACITY, Global),
        entities: IdMap::new_in(Global),

        highlight_id: None,
        selection_add_buffer: HashSet::new(),
        selection_buffer: HashSet::new(),
        eraser_buffer: HashSet::new(),
        brush_buffer: HashSet::new(),

        text_edit_buffer: guise::AsciiArrayVec::new(),

        render_mode: RenderMode::Game,
    }
}

fn sync_animations(dst_entity: &mut EntityInit, src_entity: &EntityInit) {
    // Note: @AddEntity @Derive
    match (
        EntityDataInit::from_entity_init_mut(dst_entity),
        EntityDataInit::from_entity_init(src_entity),
    ) {
        (EntityDataInit::Wizard(dst), EntityDataInit::Wizard(src)) => {
            dst.anim_front = src.anim_front;
            dst.anim_back = src.anim_back;
            dst.anim_left = src.anim_left;
            dst.anim_right = src.anim_right;
        }
        (EntityDataInit::Exit(dst), EntityDataInit::Exit(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::Water(dst), EntityDataInit::Water(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::Ground(dst), EntityDataInit::Ground(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::Tree(dst), EntityDataInit::Tree(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::WoodenCrate(dst), EntityDataInit::WoodenCrate(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::IronCrate(dst), EntityDataInit::IronCrate(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::Key(dst), EntityDataInit::Key(src)) => {
            dst.anim = src.anim;
        }
        (EntityDataInit::KeyGate(dst), EntityDataInit::KeyGate(src)) => {
            dst.anim = src.anim;
            dst.anim_open = src.anim_open;
        }
        (EntityDataInit::TranspositionStone(dst), EntityDataInit::TranspositionStone(src)) => {
            dst.anim = src.anim;
            dst.anim_active = src.anim_active;
        }
        (EntityDataInit::SummoningStone(dst), EntityDataInit::SummoningStone(src)) => {
            dst.anim = src.anim;
            dst.anim_active = src.anim_active;
        }
        (EntityDataInit::FamiliarCat(dst), EntityDataInit::FamiliarCat(src)) => {
            dst.anim_front = src.anim_front;
            dst.anim_back = src.anim_back;
            dst.anim_left = src.anim_left;
            dst.anim_right = src.anim_right;
        }
        (EntityDataInit::SkellyWarrior(dst), EntityDataInit::SkellyWarrior(src)) => {
            dst.anim_front = src.anim_front;
            dst.anim_back = src.anim_back;
            dst.anim_left = src.anim_left;
            dst.anim_right = src.anim_right;
            dst.anim_aggro_front = src.anim_aggro_front;
            dst.anim_aggro_back = src.anim_aggro_back;
            dst.anim_aggro_left = src.anim_aggro_left;
            dst.anim_aggro_right = src.anim_aggro_right;
        }
        (EntityDataInit::SkellyArcher(dst), EntityDataInit::SkellyArcher(src)) => {
            dst.anim_front = src.anim_front;
            dst.anim_back = src.anim_back;
            dst.anim_left = src.anim_left;
            dst.anim_right = src.anim_right;
            dst.anim_aggro_front = src.anim_aggro_front;
            dst.anim_aggro_back = src.anim_aggro_back;
            dst.anim_aggro_left = src.anim_aggro_left;
            dst.anim_aggro_right = src.anim_aggro_right;
        }
        (EntityDataInit::PressurePlate(dst), EntityDataInit::PressurePlate(src)) => {
            dst.anim = src.anim;
            dst.anim_pressed = src.anim_pressed;
        }
        (EntityDataInit::PressurePlateGate(dst), EntityDataInit::PressurePlateGate(src)) => {
            dst.anim = src.anim;
            dst.anim_open = src.anim_open;
        }
        _ => (),
    }
}

fn sync_volumes(dst_entity: &mut EntityInit, src_entity: &EntityInit) {
    if dst_entity.ty == src_entity.ty {
        dst_entity.volume_idle = src_entity.volume_idle;
    }
}

fn setup_camera_for_level(camera: &mut Camera, min: IVec3, max: IVec3) {
    let level_diagonal = max.as_vec3() - min.as_vec3();
    let level_diagonal_length = level_diagonal.length();
    let look_at_point = min.as_vec3() + level_diagonal / 2.0;

    camera.set_azimuth(90.0_f32.to_radians());
    camera.set_inclination(camera::DEFAULT_INCLINATION);

    let position = look_at_point + 1.3 * level_diagonal_length * -camera.direction();

    camera.set_position(position);
}

fn setup_camera_for_empty_level(camera: &mut Camera) {
    let level_diagonal = vec3(10.0, 10.0, 2.0);
    let level_diagonal_length = level_diagonal.length();
    let look_at_point = Vec3::ZERO;

    camera.set_azimuth(90.0_f32.to_radians());
    camera.set_inclination(camera::DEFAULT_INCLINATION);

    let position = look_at_point + 1.3 * level_diagonal_length * -camera.direction();

    camera.set_position(position);
}

fn build_level_bounds(entities: &IdMap<EntityInit, Global>) -> (IVec3, IVec3) {
    if entities.is_empty() {
        (IVec3::ZERO, IVec3::ZERO)
    } else {
        let mut min = ivec3(i32::MAX, i32::MAX, i32::MAX);
        let mut max = ivec3(i32::MIN, i32::MIN, i32::MIN);

        for (_, entity) in entities {
            if min.x > entity.position.x {
                min.x = entity.position.x;
            }
            if min.y > entity.position.y {
                min.y = entity.position.y;
            }
            if min.z > entity.position.z {
                min.z = entity.position.z;
            }

            if max.x < entity.position.x {
                max.x = entity.position.x;
            }
            if max.y < entity.position.y {
                max.y = entity.position.y;
            }
            if max.z < entity.position.z {
                max.z = entity.position.z;
            }
        }

        (min, max)
    }
}

fn build_entity_grid<'a>(
    temp_allocator: &'a Linear,
    entities: &IdMap<EntityInit, Global>,
) -> Grid<ArrayVec<(Id, EntityType), 4>, &'a Linear> {
    let (min, max) = build_level_bounds(entities);

    let mut entity_grid: Grid<ArrayVec<(Id, EntityType), 4>, _> =
        Grid::with_aabb_in(min, max, temp_allocator);

    for (entity_id, entity) in entities {
        let grid_cell = &mut entity_grid[entity.position];
        grid_cell.push((entity_id, entity.ty));
    }

    entity_grid
}

fn push_transaction(
    temp_allocator: &Linear,
    history: &mut History<EntityInit, Global>,
    entities: &IdMap<EntityInit, Global>,
    entities_prev: &IdMap<EntityInit, &Linear>,
) {
    match history.push_transaction(temp_allocator, entities, entities_prev) {
        Ok((pushed_count, forgot_count, hosed_count)) => {
            log::debug!(
                "History transaction pushed/forgot/hosed {}/{}/{} changes",
                pushed_count,
                forgot_count,
                hosed_count,
            );
        }
        Err(HistoryError::OutOfMemory { needed, have }) => {
            // TODO(yan): Make this error louder by showing it on screen.
            log::error!(
                "History too small for {} changes (have enough for {}), clearing...",
                needed,
                have,
            );
        }
    }
}

fn is_above_ground(position: IVec3) -> bool {
    position.z >= 0
}
