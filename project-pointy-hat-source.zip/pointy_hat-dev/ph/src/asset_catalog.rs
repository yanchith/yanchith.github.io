use alloc::vec::Vec;
use core::fmt;

use hashbrown::hash_map::{DefaultHashBuilder, HashMap};
use lfg_alloc::Linear;
use lfg_cereal::{self as cereal, Serialize};
use lfg_math::{libm, IRect};

use crate::asset::{self, AssetId, AssetName, AssetType};
use crate::gameplay::{
    Animation,
    Bearing,
    BinaryBooleanOp,
    EntityDataInit,
    EntityInit,
    EntityType,
    ExitEntityDataInit,
    FamiliarCatEntityDataInit,
    GroundEntityDataInit,
    IronCrateEntityDataInit,
    KeyEntityDataInit,
    KeyGateEntityDataInit,
    PressurePlateEntityDataInit,
    PressurePlateGateEntityDataInit,
    SkellyArcherEntityDataInit,
    SkellyWarriorEntityDataInit,
    SummoningStoneEntityDataInit,
    TranspositionStoneEntityDataInit,
    TreeEntityDataInit,
    UnaryBooleanOp,
    VolumeAnimation,
    VolumeAnimationDirections,
    WaterEntityDataInit,
    WizardEntityDataInit,
    WoodenCrateEntityDataInit,
};
use crate::idmap::Id;
use crate::levelset_catalog::LevelsetCatalog;
use crate::volume_catalog::VolumeCatalog;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct AssetManifestEntry {
    pub ty: AssetType,
    pub id: AssetId,
    pub name: AssetName,
}

#[derive(Debug)]
pub struct AssetCatalog {
    pub world: World,

    // TODO(yan): The manifest should not exist in the dist build of the game,
    // and we should cfg to start enforcing this. We currently use it for:
    //
    // - Looking up the asset name for flattening when saving from editor
    // - Looking up the asset name in editor
    // - ID collision detection
    // - more?
    pub manifest: HashMap<AssetId, AssetManifestEntry, DefaultHashBuilder, &'static Linear>,

    pub levelsets_by_name: HashMap<AssetName, AssetId, DefaultHashBuilder, &'static Linear>,
    pub textures_by_name: HashMap<AssetName, AssetId, DefaultHashBuilder, &'static Linear>,
    pub volumes_by_name: HashMap<AssetName, AssetId, DefaultHashBuilder, &'static Linear>,

    pub levelset_catalog: LevelsetCatalog,
    pub texture_catalog: HashMap<AssetId, Texture, DefaultHashBuilder, &'static Linear>,
    pub volume_catalog: VolumeCatalog,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct World {
    pub default_levelset_id: AssetId,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Texture {
    pub width: u16,
    pub height: u16,
}

pub fn flatten_entity_init(
    entity: &EntityInit,
    asset_catalog: &AssetCatalog,
) -> vcurrent::EntityInitSer {
    vcurrent::EntityInitSer {
        ty: flatten_entity_type(entity.ty),
        data: flatten_entity_data_init(&entity.data, asset_catalog),

        position: entity.position,
        bearing: vcurrent::BearingSer::from(entity.bearing),

        volume_idle: flatten_volume(entity.volume_idle, asset_catalog),
    }
}

fn flatten_entity_type(entity_type: EntityType) -> vcurrent::EntityTypeSer {
    // Note: @AddEntity @Derive
    match entity_type {
        EntityType::Wizard => vcurrent::EntityTypeSer::Wizard,
        EntityType::Exit => vcurrent::EntityTypeSer::Exit,
        EntityType::Water => vcurrent::EntityTypeSer::Water,
        EntityType::Ground => vcurrent::EntityTypeSer::Ground,
        EntityType::Tree => vcurrent::EntityTypeSer::Tree,
        EntityType::WoodenCrate => vcurrent::EntityTypeSer::WoodenCrate,
        EntityType::IronCrate => vcurrent::EntityTypeSer::IronCrate,
        EntityType::Key => vcurrent::EntityTypeSer::Key,
        EntityType::KeyGate => vcurrent::EntityTypeSer::KeyGate,
        EntityType::TranspositionStone => vcurrent::EntityTypeSer::TranspositionStone,
        EntityType::SummoningStone => vcurrent::EntityTypeSer::SummoningStone,
        EntityType::FamiliarCat => vcurrent::EntityTypeSer::FamiliarCat,
        EntityType::SkellyWarrior => vcurrent::EntityTypeSer::SkellyWarrior,
        EntityType::SkellyArcher => vcurrent::EntityTypeSer::SkellyArcher,
        EntityType::PressurePlate => vcurrent::EntityTypeSer::PressurePlate,
        EntityType::PressurePlateGate => vcurrent::EntityTypeSer::PressurePlateGate,
    }
}

fn flatten_entity_data_init(
    entity_data_init: &EntityDataInit,
    asset_catalog: &AssetCatalog,
) -> vcurrent::EntityDataInitSer {
    match entity_data_init {
        EntityDataInit::Wizard(data) => {
            vcurrent::EntityDataInitSer::Wizard(vcurrent::WizardEntityDataInitSer {
                anim_front: data
                    .anim_front
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| flatten_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| flatten_animation(&a, asset_catalog)),
                anim_right: data
                    .anim_right
                    .map(|a| flatten_animation(&a, asset_catalog)),
            })
        }
        EntityDataInit::Exit(data) => {
            vcurrent::EntityDataInitSer::Exit(vcurrent::ExitEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::Water(data) => {
            vcurrent::EntityDataInitSer::Water(vcurrent::WaterEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::Ground(data) => {
            vcurrent::EntityDataInitSer::Ground(vcurrent::GroundEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::Tree(data) => {
            vcurrent::EntityDataInitSer::Tree(vcurrent::TreeEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::WoodenCrate(data) => {
            vcurrent::EntityDataInitSer::WoodenCrate(vcurrent::WoodenCrateEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::IronCrate(data) => {
            vcurrent::EntityDataInitSer::IronCrate(vcurrent::IronCrateEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::Key(data) => {
            vcurrent::EntityDataInitSer::Key(vcurrent::KeyEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::KeyGate(data) => {
            vcurrent::EntityDataInitSer::KeyGate(vcurrent::KeyGateEntityDataInitSer {
                open: data.open,
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
                anim_open: data
                    .anim_open
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::TranspositionStone(data) => {
            vcurrent::EntityDataInitSer::TranspositionStone(
                vcurrent::TranspositionStoneEntityDataInitSer {
                    anim: data
                        .anim
                        .as_ref()
                        .map(|a| flatten_animation(a, asset_catalog)),
                    anim_active: data
                        .anim_active
                        .as_ref()
                        .map(|a| flatten_animation(a, asset_catalog)),
                },
            )
        }
        EntityDataInit::SummoningStone(data) => {
            vcurrent::EntityDataInitSer::SummoningStone(vcurrent::SummoningStoneEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_animation(a, asset_catalog)),
                anim_active: data
                    .anim_active
                    .as_ref()
                    .map(|a| flatten_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::FamiliarCat(data) => {
            vcurrent::EntityDataInitSer::FamiliarCat(vcurrent::FamiliarCatEntityDataInitSer {
                anim_front: data
                    .anim_front
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| flatten_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| flatten_animation(&a, asset_catalog)),
                anim_right: data
                    .anim_right
                    .map(|a| flatten_animation(&a, asset_catalog)),
            })
        }
        EntityDataInit::SkellyWarrior(data) => {
            vcurrent::EntityDataInitSer::SkellyWarrior(vcurrent::SkellyWarriorEntityDataInitSer {
                anim_front: data
                    .anim_front
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| flatten_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| flatten_animation(&a, asset_catalog)),
                anim_right: data
                    .anim_right
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_front: data
                    .anim_aggro_front
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_back: data
                    .anim_aggro_back
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_left: data
                    .anim_aggro_left
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_right: data
                    .anim_aggro_right
                    .map(|a| flatten_animation(&a, asset_catalog)),
            })
        }
        EntityDataInit::SkellyArcher(data) => {
            vcurrent::EntityDataInitSer::SkellyArcher(vcurrent::SkellyArcherEntityDataInitSer {
                anim_front: data
                    .anim_front
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| flatten_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| flatten_animation(&a, asset_catalog)),
                anim_right: data
                    .anim_right
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_front: data
                    .anim_aggro_front
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_back: data
                    .anim_aggro_back
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_left: data
                    .anim_aggro_left
                    .map(|a| flatten_animation(&a, asset_catalog)),
                anim_aggro_right: data
                    .anim_aggro_right
                    .map(|a| flatten_animation(&a, asset_catalog)),
            })
        }
        EntityDataInit::PressurePlate(data) => {
            vcurrent::EntityDataInitSer::PressurePlate(vcurrent::PressurePlateEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
                anim_pressed: data
                    .anim_pressed
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
            })
        }
        EntityDataInit::PressurePlateGate(data) => vcurrent::EntityDataInitSer::PressurePlateGate(
            vcurrent::PressurePlateGateEntityDataInitSer {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
                anim_open: data
                    .anim_open
                    .as_ref()
                    .map(|a| flatten_volume_animation(a, asset_catalog)),
                open_if_active: [
                    data.open_if_active[0].map(|(op, id)| {
                        (
                            vcurrent::UnaryBooleanOpSer::from(op),
                            vcurrent::IdSer::from(id),
                        )
                    }),
                    data.open_if_active[1].map(|(op, id)| {
                        (
                            vcurrent::UnaryBooleanOpSer::from(op),
                            vcurrent::IdSer::from(id),
                        )
                    }),
                    data.open_if_active[2].map(|(op, id)| {
                        (
                            vcurrent::UnaryBooleanOpSer::from(op),
                            vcurrent::IdSer::from(id),
                        )
                    }),
                    data.open_if_active[3].map(|(op, id)| {
                        (
                            vcurrent::UnaryBooleanOpSer::from(op),
                            vcurrent::IdSer::from(id),
                        )
                    }),
                ],
                open_if_active_op: vcurrent::BinaryBooleanOpSer::from(data.open_if_active_op),
            },
        ),
    }
}

fn flatten_animation(
    animation: &Animation,
    asset_catalog: &AssetCatalog,
) -> vcurrent::AnimationSer {
    vcurrent::AnimationSer {
        texture_name: asset_catalog.manifest[&animation.texture_id].name,
        frame: vcurrent::IRectSer::from(animation.frame),
    }
}

fn flatten_volume_animation_directions(
    directions: VolumeAnimationDirections,
) -> vcurrent::VolumeAnimationDirectionsSer {
    vcurrent::VolumeAnimationDirectionsSer(directions.bits())
}

fn flatten_volume_animation(
    animation: &VolumeAnimation,
    asset_catalog: &AssetCatalog,
) -> vcurrent::VolumeAnimationSer {
    vcurrent::VolumeAnimationSer {
        top: animation.top.map(|a| flatten_animation(&a, asset_catalog)),
        top_directions: flatten_volume_animation_directions(animation.top_directions),
        top_offset: animation.top_offset,
        sides: animation
            .sides
            .map(|a| flatten_animation(&a, asset_catalog)),
        sides_directions: flatten_volume_animation_directions(animation.sides_directions),
        sides_offset: animation.sides_offset,
        bottom: animation
            .bottom
            .map(|a| flatten_animation(&a, asset_catalog)),
        bottom_directions: flatten_volume_animation_directions(animation.bottom_directions),
        bottom_offset: animation.bottom_offset,
    }
}

fn flatten_volume(volume_id: AssetId, asset_catalog: &AssetCatalog) -> AssetName {
    asset_catalog.manifest[&volume_id].name
}

pub fn revive_entity_init(
    entity: &vcurrent::EntityInitSer,
    asset_catalog: &AssetCatalog,
) -> EntityInit {
    EntityInit {
        ty: revive_entity_type(entity.ty),
        data: revive_entity_data_init(&entity.data, asset_catalog),

        position: entity.position,
        bearing: Bearing::from(entity.bearing),

        volume_idle: revive_volume(entity.volume_idle, asset_catalog),
    }
}

fn revive_entity_type(entity_type: vcurrent::EntityTypeSer) -> EntityType {
    match entity_type {
        vcurrent::EntityTypeSer::Wizard => EntityType::Wizard,
        vcurrent::EntityTypeSer::Exit => EntityType::Exit,
        vcurrent::EntityTypeSer::Water => EntityType::Water,
        vcurrent::EntityTypeSer::Ground => EntityType::Ground,
        vcurrent::EntityTypeSer::Tree => EntityType::Tree,
        vcurrent::EntityTypeSer::WoodenCrate => EntityType::WoodenCrate,
        vcurrent::EntityTypeSer::IronCrate => EntityType::IronCrate,
        vcurrent::EntityTypeSer::Key => EntityType::Key,
        vcurrent::EntityTypeSer::KeyGate => EntityType::KeyGate,
        vcurrent::EntityTypeSer::TranspositionStone => EntityType::TranspositionStone,
        vcurrent::EntityTypeSer::SummoningStone => EntityType::SummoningStone,
        vcurrent::EntityTypeSer::FamiliarCat => EntityType::FamiliarCat,
        vcurrent::EntityTypeSer::SkellyWarrior => EntityType::SkellyWarrior,
        vcurrent::EntityTypeSer::SkellyArcher => EntityType::SkellyArcher,
        vcurrent::EntityTypeSer::PressurePlate => EntityType::PressurePlate,
        vcurrent::EntityTypeSer::PressurePlateGate => EntityType::PressurePlateGate,
    }
}

fn revive_entity_data_init(
    entity_data_init: &vcurrent::EntityDataInitSer,
    asset_catalog: &AssetCatalog,
) -> EntityDataInit {
    match entity_data_init {
        vcurrent::EntityDataInitSer::Wizard(data) => EntityDataInit::Wizard(WizardEntityDataInit {
            anim_front: data.anim_front.map(|a| revive_animation(&a, asset_catalog)),
            anim_back: data.anim_back.map(|a| revive_animation(&a, asset_catalog)),
            anim_left: data.anim_left.map(|a| revive_animation(&a, asset_catalog)),
            anim_right: data.anim_right.map(|a| revive_animation(&a, asset_catalog)),
        }),
        vcurrent::EntityDataInitSer::Exit(data) => EntityDataInit::Exit(ExitEntityDataInit {
            anim: data
                .anim
                .as_ref()
                .map(|a| revive_volume_animation(a, asset_catalog)),
        }),
        vcurrent::EntityDataInitSer::Water(data) => EntityDataInit::Water(WaterEntityDataInit {
            anim: data
                .anim
                .as_ref()
                .map(|a| revive_volume_animation(a, asset_catalog)),
        }),
        vcurrent::EntityDataInitSer::Ground(data) => EntityDataInit::Ground(GroundEntityDataInit {
            anim: data
                .anim
                .as_ref()
                .map(|a| revive_volume_animation(a, asset_catalog)),
        }),
        vcurrent::EntityDataInitSer::Tree(data) => EntityDataInit::Tree(TreeEntityDataInit {
            anim: data
                .anim
                .as_ref()
                .map(|a| revive_animation(a, asset_catalog)),
        }),
        vcurrent::EntityDataInitSer::WoodenCrate(data) => {
            EntityDataInit::WoodenCrate(WoodenCrateEntityDataInit {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_animation(a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::IronCrate(data) => {
            EntityDataInit::IronCrate(IronCrateEntityDataInit {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_animation(a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::Key(data) => EntityDataInit::Key(KeyEntityDataInit {
            anim: data
                .anim
                .as_ref()
                .map(|a| revive_animation(a, asset_catalog)),
        }),
        vcurrent::EntityDataInitSer::KeyGate(data) => {
            EntityDataInit::KeyGate(KeyGateEntityDataInit {
                open: data.open,
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_volume_animation(a, asset_catalog)),
                anim_open: data
                    .anim_open
                    .as_ref()
                    .map(|a| revive_volume_animation(a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::TranspositionStone(data) => {
            EntityDataInit::TranspositionStone(TranspositionStoneEntityDataInit {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_animation(a, asset_catalog)),
                anim_active: data
                    .anim_active
                    .as_ref()
                    .map(|a| revive_animation(a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::SummoningStone(data) => {
            EntityDataInit::SummoningStone(SummoningStoneEntityDataInit {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_animation(a, asset_catalog)),
                anim_active: data
                    .anim_active
                    .as_ref()
                    .map(|a| revive_animation(a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::FamiliarCat(data) => {
            EntityDataInit::FamiliarCat(FamiliarCatEntityDataInit {
                anim_front: data.anim_front.map(|a| revive_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| revive_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| revive_animation(&a, asset_catalog)),
                anim_right: data.anim_right.map(|a| revive_animation(&a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::SkellyWarrior(data) => {
            EntityDataInit::SkellyWarrior(SkellyWarriorEntityDataInit {
                anim_front: data.anim_front.map(|a| revive_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| revive_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| revive_animation(&a, asset_catalog)),
                anim_right: data.anim_right.map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_front: data
                    .anim_aggro_front
                    .map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_back: data
                    .anim_aggro_back
                    .map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_left: data
                    .anim_aggro_left
                    .map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_right: data
                    .anim_aggro_right
                    .map(|a| revive_animation(&a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::SkellyArcher(data) => {
            EntityDataInit::SkellyArcher(SkellyArcherEntityDataInit {
                anim_front: data.anim_front.map(|a| revive_animation(&a, asset_catalog)),
                anim_back: data.anim_back.map(|a| revive_animation(&a, asset_catalog)),
                anim_left: data.anim_left.map(|a| revive_animation(&a, asset_catalog)),
                anim_right: data.anim_right.map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_front: data
                    .anim_aggro_front
                    .map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_back: data
                    .anim_aggro_back
                    .map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_left: data
                    .anim_aggro_left
                    .map(|a| revive_animation(&a, asset_catalog)),
                anim_aggro_right: data
                    .anim_aggro_right
                    .map(|a| revive_animation(&a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::PressurePlate(data) => {
            EntityDataInit::PressurePlate(PressurePlateEntityDataInit {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_volume_animation(a, asset_catalog)),
                anim_pressed: data
                    .anim_pressed
                    .as_ref()
                    .map(|a| revive_volume_animation(a, asset_catalog)),
            })
        }
        vcurrent::EntityDataInitSer::PressurePlateGate(data) => {
            EntityDataInit::PressurePlateGate(PressurePlateGateEntityDataInit {
                anim: data
                    .anim
                    .as_ref()
                    .map(|a| revive_volume_animation(a, asset_catalog)),
                anim_open: data
                    .anim_open
                    .as_ref()
                    .map(|a| revive_volume_animation(a, asset_catalog)),
                open_if_active: [
                    data.open_if_active[0].map(|(op, id)| (UnaryBooleanOp::from(op), Id::from(id))),
                    data.open_if_active[1].map(|(op, id)| (UnaryBooleanOp::from(op), Id::from(id))),
                    data.open_if_active[2].map(|(op, id)| (UnaryBooleanOp::from(op), Id::from(id))),
                    data.open_if_active[3].map(|(op, id)| (UnaryBooleanOp::from(op), Id::from(id))),
                ],
                open_if_active_op: BinaryBooleanOp::from(data.open_if_active_op),
            })
        }
    }
}

fn revive_volume_animation_directions(
    directions: vcurrent::VolumeAnimationDirectionsSer,
) -> VolumeAnimationDirections {
    VolumeAnimationDirections::from_bits_truncate(directions.0)
}

fn revive_volume_animation(
    animation: &vcurrent::VolumeAnimationSer,
    asset_catalog: &AssetCatalog,
) -> VolumeAnimation {
    VolumeAnimation {
        top: animation.top.map(|a| revive_animation(&a, asset_catalog)),
        top_directions: revive_volume_animation_directions(animation.top_directions),
        top_offset: animation.top_offset,
        sides: animation.sides.map(|a| revive_animation(&a, asset_catalog)),
        sides_directions: revive_volume_animation_directions(animation.sides_directions),
        sides_offset: animation.sides_offset,
        bottom: animation
            .bottom
            .map(|a| revive_animation(&a, asset_catalog)),
        bottom_directions: revive_volume_animation_directions(animation.bottom_directions),
        bottom_offset: animation.bottom_offset,
    }
}

fn revive_animation(animation: &vcurrent::AnimationSer, asset_catalog: &AssetCatalog) -> Animation {
    let texture_id = asset_catalog
        .textures_by_name
        .get(&animation.texture_name)
        .copied()
        .unwrap_or(asset::ID_MISSING_TEX);

    Animation {
        texture_id,
        frame: revive_irect(animation.frame),
    }
}

fn revive_volume(volume_name: AssetName, asset_catalog: &AssetCatalog) -> AssetId {
    asset_catalog
        .volumes_by_name
        .get(&volume_name)
        .copied()
        .unwrap_or(asset::ID_MISSING_VOLUME)
}

// NB: This is not a From impl, because it asserts for incorrect data.
//
// TODO(yan): @Correctness Do not crash the program when reviving. Should
// reviving be fallible? We can either make it fallible, fail to load a level
// and somehow react to that on the top level (e.g. by loading some default
// level instead and/or flashing the error to the user) OR we can default failed
// assets to something resonable (textures to missing texture, texts to empty
// strings, rects to zero rects, etc.) and flash the error.
fn revive_irect(irect: vcurrent::IRectSer) -> IRect {
    IRect::new(irect.x, irect.y, irect.width, irect.height)
}

#[derive(Debug)]
pub enum DeserializeAndMigrateError {
    Deserialize(cereal::DeserializeError),
    Migrate(MigrateError),
}

#[derive(Debug)]
pub struct MigrateError;

impl From<cereal::DeserializeError> for DeserializeAndMigrateError {
    fn from(err: cereal::DeserializeError) -> Self {
        Self::Deserialize(err)
    }
}

impl From<MigrateError> for DeserializeAndMigrateError {
    fn from(err: MigrateError) -> Self {
        Self::Migrate(err)
    }
}

impl fmt::Display for DeserializeAndMigrateError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        match self {
            Self::Deserialize(err) => write!(f, "Deserialize error: {err}"),
            Self::Migrate(err) => write!(f, "Migrate error: {err}"),
        }
    }
}

impl fmt::Display for MigrateError {
    fn fmt(&self, f: &mut fmt::Formatter) -> fmt::Result {
        write!(f, "{self:?}")
    }
}

#[derive(cereal::Serialize, cereal::Deserialize)]
#[cereal(allocator("&'a Linear"))]
enum VersionedLevelAssetSer<'a> {
    V1(v1::LevelAssetSer<'a>),
    V2(v2::LevelAssetSer<'a>),
    V3(v3::LevelAssetSer<'a>),
    V4(v4::LevelAssetSer<'a>),
    V5(v5::LevelAssetSer<'a>),
    V6(v6::LevelAssetSer<'a>),
    V7(v7::LevelAssetSer<'a>),
}

// TODO(yan): Return String<&'a Linear>
pub fn serialize_level<'a>(
    allocator: &'a Linear,
    level_asset: vcurrent::LevelAssetSer<'_>,
) -> Vec<u8, &'a Linear> {
    let level_asset = VersionedLevelAssetSer::V7(level_asset);

    let mut f = cereal::Formatter::new_in(allocator);
    level_asset.serialize(&mut f);
    f.into_data()
}

pub fn deserialize_and_migrate_level<'a>(
    allocator: &'a Linear,
    level_str: &str,
) -> Result<vcurrent::LevelAssetSer<'a>, DeserializeAndMigrateError> {
    let versioned_level_asset: VersionedLevelAssetSer =
        cereal::deserialize_in(level_str, allocator, allocator)?;

    let upped_level_asset = match versioned_level_asset {
        VersionedLevelAssetSer::V1(v1) => {
            let v2 = up_v1_to_v2(allocator, v1)?;
            let v3 = up_v2_to_v3(allocator, v2)?;
            let v4 = up_v3_to_v4(allocator, v3)?;
            let v5 = up_v4_to_v5(allocator, v4)?;
            let v6 = up_v5_to_v6(allocator, v5)?;
            let v7 = up_v6_to_v7(allocator, v6)?;
            v7
        }
        VersionedLevelAssetSer::V2(v2) => {
            let v3 = up_v2_to_v3(allocator, v2)?;
            let v4 = up_v3_to_v4(allocator, v3)?;
            let v5 = up_v4_to_v5(allocator, v4)?;
            let v6 = up_v5_to_v6(allocator, v5)?;
            let v7 = up_v6_to_v7(allocator, v6)?;
            v7
        }
        VersionedLevelAssetSer::V3(v3) => {
            let v4 = up_v3_to_v4(allocator, v3)?;
            let v5 = up_v4_to_v5(allocator, v4)?;
            let v6 = up_v5_to_v6(allocator, v5)?;
            let v7 = up_v6_to_v7(allocator, v6)?;
            v7
        }
        VersionedLevelAssetSer::V4(v4) => {
            let v5 = up_v4_to_v5(allocator, v4)?;
            let v6 = up_v5_to_v6(allocator, v5)?;
            let v7 = up_v6_to_v7(allocator, v6)?;
            v7
        }
        VersionedLevelAssetSer::V5(v5) => {
            let v6 = up_v5_to_v6(allocator, v5)?;
            let v7 = up_v6_to_v7(allocator, v6)?;
            v7
        }
        VersionedLevelAssetSer::V6(v6) => {
            let v7 = up_v6_to_v7(allocator, v6)?;
            v7
        }
        VersionedLevelAssetSer::V7(v7) => v7,
    };

    Ok(upped_level_asset)
}

fn up_v1_to_v2<'a>(
    allocator: &'a Linear,
    level_asset: v1::LevelAssetSer<'_>,
) -> Result<v2::LevelAssetSer<'a>, MigrateError> {
    log::debug!("Upping level from V1 to V2");

    let size = level_asset.size;
    let mut entities = Vec::with_capacity_in(level_asset.entities.len(), allocator);
    for entity in &level_asset.entities {
        entities.push(v2::EntityInitSer {
            ty: entity.ty,
            // NB: Omit entity.flags
            data: match &entity.data {
                v1::EntityDataInitSer::None => v2::EntityDataInitSer::None,
                v1::EntityDataInitSer::Gate(data) => {
                    v2::EntityDataInitSer::Gate(v2::GateEntityDataInitSer { open: data.open })
                }
                v1::EntityDataInitSer::ManaSource(data) => {
                    v2::EntityDataInitSer::ManaSource(v2::ManaSourceEntityDataInitSer {
                        anim_active_front: data.anim_active_front,
                    })
                }
            },

            position: entity.position,
            bearing: entity.bearing,

            anim_idle_front: entity.anim_idle_front,
            anim_idle_back: entity.anim_idle_back,
            anim_idle_left: entity.anim_idle_left,
            anim_idle_right: entity.anim_idle_right,
        });
    }

    Ok(v2::LevelAssetSer { size, entities })
}

fn up_v2_to_v3<'a>(
    allocator: &'a Linear,
    level_asset: v2::LevelAssetSer<'_>,
) -> Result<v3::LevelAssetSer<'a>, MigrateError> {
    log::debug!("Upping level from V2 to V3");

    let size = level_asset.size;
    let mut entities = Vec::with_capacity_in(level_asset.entities.len(), allocator);
    for entity in &level_asset.entities {
        entities.push(v3::EntityInitSer {
            ty: entity.ty,
            data: match &entity.data {
                v2::EntityDataInitSer::None => v3::EntityDataInitSer::None,
                v2::EntityDataInitSer::Gate(data) => {
                    v3::EntityDataInitSer::Gate(v3::GateEntityDataInitSer {
                        open: data.open,
                        // NB: Copy default animation
                        anim_open_front: entity.anim_idle_front,
                        anim_open_back: entity.anim_idle_back,
                        anim_open_left: entity.anim_idle_left,
                        anim_open_right: entity.anim_idle_right,
                    })
                }
                v2::EntityDataInitSer::ManaSource(data) => {
                    v3::EntityDataInitSer::ManaSource(v3::ManaSourceEntityDataInitSer {
                        anim_active_front: data.anim_active_front,
                        // NB: Copy default animation
                        anim_active_back: entity.anim_idle_back,
                        anim_active_left: entity.anim_idle_left,
                        anim_active_right: entity.anim_idle_right,
                    })
                }
            },

            position: entity.position,
            bearing: entity.bearing,

            anim_idle_front: entity.anim_idle_front,
            anim_idle_back: entity.anim_idle_back,
            anim_idle_left: entity.anim_idle_left,
            anim_idle_right: entity.anim_idle_right,
        });
    }

    Ok(v3::LevelAssetSer { size, entities })
}

fn up_v3_to_v4<'a>(
    allocator: &'a Linear,
    level_asset: v3::LevelAssetSer<'_>,
) -> Result<v4::LevelAssetSer<'a>, MigrateError> {
    log::debug!("Upping level from V3 to V4");

    let size = level_asset.size;
    let mut entities = Vec::with_capacity_in(level_asset.entities.len(), allocator);
    for entity in &level_asset.entities {
        entities.push(v4::EntityInitSer {
            ty: entity.ty,
            data: match (entity.ty, &entity.data) {
                (v3::EntityTypeSer::Wizard, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::Wizard(v4::WizardEntityDataInitSer {
                        anim_front: entity.anim_idle_front,
                        anim_back: entity.anim_idle_back,
                        anim_left: entity.anim_idle_left,
                        anim_right: entity.anim_idle_right,
                    })
                }
                (v3::EntityTypeSer::ManaPotion, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::ManaPotion(v4::ManaPotionEntityDataInitSer {
                        anim: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::Exit, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::Exit(v4::ExitEntityDataInitSer {
                        anim_top: entity.anim_idle_front,
                        anim_sides: entity.anim_idle_front,
                        anim_bottom: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::Water, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::Water(v4::WaterEntityDataInitSer {
                        anim_top: entity.anim_idle_front,
                        anim_sides: entity.anim_idle_front,
                        anim_bottom: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::Ground, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::Ground(v4::GroundEntityDataInitSer {
                        anim_top: entity.anim_idle_front,
                        anim_sides: entity.anim_idle_front,
                        anim_bottom: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::Tree, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::Tree(v4::TreeEntityDataInitSer {
                        anim: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::WoodenCrate, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::WoodenCrate(v4::WoodenCrateEntityDataInitSer {
                        anim: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::IronCrate, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::IronCrate(v4::IronCrateEntityDataInitSer {
                        anim: entity.anim_idle_front,
                    })
                }
                (v3::EntityTypeSer::Key, v3::EntityDataInitSer::None) => {
                    v4::EntityDataInitSer::Key(v4::KeyEntityDataInitSer {
                        anim: entity.anim_idle_front,
                    })
                }
                (_, v3::EntityDataInitSer::Gate(data)) => {
                    v4::EntityDataInitSer::Gate(v4::GateEntityDataInitSer {
                        open: data.open,
                        anim_top: entity.anim_idle_front,
                        anim_sides: entity.anim_idle_front,
                        anim_bottom: entity.anim_idle_front,
                        anim_open_top: data.anim_open_front,
                        anim_open_sides: data.anim_open_front,
                        anim_open_bottom: data.anim_open_front,
                    })
                }
                (_, v3::EntityDataInitSer::ManaSource(data)) => {
                    v4::EntityDataInitSer::ManaSource(v4::ManaSourceEntityDataInitSer {
                        anim: entity.anim_idle_front,
                        anim_active: data.anim_active_front,
                    })
                }
                _ => {
                    return Err(MigrateError);
                }
            },

            position: entity.position,
            bearing: entity.bearing,
            // NB: Omit anim_idle_{front,back,left,right}
        });
    }

    Ok(v4::LevelAssetSer { size, entities })
}

fn up_v4_to_v5<'a>(
    allocator: &'a Linear,
    level_asset: v4::LevelAssetSer<'_>,
) -> Result<v5::LevelAssetSer<'a>, MigrateError> {
    fn up_anim(animation: Option<v4::AnimationSer>) -> Option<v5::AnimationSer> {
        animation.map(|a| v5::AnimationSer {
            texture_name: a.texture_name,
            frame: v5::IRectSer {
                x: libm::roundf(a.frame.x) as i32,
                y: libm::roundf(a.frame.y) as i32,
                width: libm::roundf(a.frame.width) as i32,
                height: libm::roundf(a.frame.height) as i32,
            },
        })
    }

    log::debug!("Upping level from V4 to V5");

    const OUTWARD: VolumeAnimationDirections = VolumeAnimationDirections::OUTWARD;
    const INWARD: VolumeAnimationDirections = VolumeAnimationDirections::INWARD;
    const OUTWARD_INWARD: VolumeAnimationDirections = OUTWARD | INWARD;

    let mut entities = Vec::with_capacity_in(level_asset.entities.len(), allocator);
    for entity in &level_asset.entities {
        entities.push(v5::EntityInitSer {
            ty: entity.ty,
            data: match &entity.data {
                v4::EntityDataInitSer::Wizard(data) => {
                    v5::EntityDataInitSer::Wizard(v5::WizardEntityDataInitSer {
                        anim_front: up_anim(data.anim_front),
                        anim_back: up_anim(data.anim_back),
                        anim_left: up_anim(data.anim_left),
                        anim_right: up_anim(data.anim_right),
                    })
                }
                v4::EntityDataInitSer::ManaPotion(data) => {
                    v5::EntityDataInitSer::ManaPotion(v5::ManaPotionEntityDataInitSer {
                        anim: up_anim(data.anim),
                    })
                }
                v4::EntityDataInitSer::Exit(data) => {
                    v5::EntityDataInitSer::Exit(v5::ExitEntityDataInitSer {
                        anim: Some(v5::VolumeAnimationSer {
                            top: up_anim(data.anim_top),
                            top_directions: flatten_volume_animation_directions(OUTWARD),
                            top_offset: 0.0,
                            sides: up_anim(data.anim_sides),
                            sides_directions: flatten_volume_animation_directions(OUTWARD),
                            sides_offset: 0.0,
                            bottom: up_anim(data.anim_bottom),
                            bottom_directions: flatten_volume_animation_directions(OUTWARD_INWARD),
                            bottom_offset: 0.0,
                        }),
                    })
                }
                v4::EntityDataInitSer::Water(data) => {
                    v5::EntityDataInitSer::Water(v5::WaterEntityDataInitSer {
                        anim: Some(v5::VolumeAnimationSer {
                            top: up_anim(data.anim_top),
                            top_directions: flatten_volume_animation_directions(OUTWARD),
                            top_offset: 0.0,
                            sides: up_anim(data.anim_sides),
                            sides_directions: flatten_volume_animation_directions(OUTWARD),
                            sides_offset: 0.0,
                            bottom: up_anim(data.anim_bottom),
                            bottom_directions: flatten_volume_animation_directions(OUTWARD),
                            bottom_offset: 0.0,
                        }),
                    })
                }
                v4::EntityDataInitSer::Ground(data) => {
                    v5::EntityDataInitSer::Ground(v5::GroundEntityDataInitSer {
                        anim: Some(v5::VolumeAnimationSer {
                            top: up_anim(data.anim_top),
                            top_directions: flatten_volume_animation_directions(OUTWARD),
                            top_offset: 0.0,
                            sides: up_anim(data.anim_sides),
                            sides_directions: flatten_volume_animation_directions(OUTWARD),
                            sides_offset: 0.0,
                            bottom: up_anim(data.anim_bottom),
                            bottom_directions: flatten_volume_animation_directions(OUTWARD),
                            bottom_offset: 0.0,
                        }),
                    })
                }
                v4::EntityDataInitSer::Tree(data) => {
                    v5::EntityDataInitSer::Tree(v5::TreeEntityDataInitSer {
                        anim: up_anim(data.anim),
                    })
                }
                v4::EntityDataInitSer::WoodenCrate(data) => {
                    v5::EntityDataInitSer::WoodenCrate(v5::WoodenCrateEntityDataInitSer {
                        anim: up_anim(data.anim),
                    })
                }
                v4::EntityDataInitSer::IronCrate(data) => {
                    v5::EntityDataInitSer::IronCrate(v5::IronCrateEntityDataInitSer {
                        anim: up_anim(data.anim),
                    })
                }
                v4::EntityDataInitSer::Key(data) => {
                    v5::EntityDataInitSer::Key(v5::KeyEntityDataInitSer {
                        anim: up_anim(data.anim),
                    })
                }
                v4::EntityDataInitSer::Gate(data) => {
                    v5::EntityDataInitSer::Gate(v5::GateEntityDataInitSer {
                        open: data.open,
                        anim: Some(v5::VolumeAnimationSer {
                            top: up_anim(data.anim_top),
                            top_directions: flatten_volume_animation_directions(OUTWARD),
                            top_offset: 0.0,
                            sides: up_anim(data.anim_sides),
                            sides_directions: flatten_volume_animation_directions(OUTWARD),
                            sides_offset: 0.0,
                            bottom: up_anim(data.anim_bottom),
                            bottom_directions: flatten_volume_animation_directions(OUTWARD),
                            bottom_offset: 0.0,
                        }),
                        anim_open: Some(v5::VolumeAnimationSer {
                            top: up_anim(data.anim_open_top),
                            top_directions: flatten_volume_animation_directions(OUTWARD),
                            top_offset: 0.0,
                            sides: up_anim(data.anim_open_sides),
                            sides_directions: flatten_volume_animation_directions(OUTWARD),
                            sides_offset: 0.0,
                            bottom: up_anim(data.anim_open_bottom),
                            bottom_directions: flatten_volume_animation_directions(OUTWARD),
                            bottom_offset: 0.0,
                        }),
                    })
                }
                v4::EntityDataInitSer::ManaSource(data) => {
                    v5::EntityDataInitSer::ManaSource(v5::ManaSourceEntityDataInitSer {
                        anim: up_anim(data.anim),
                        anim_active: up_anim(data.anim_active),
                    })
                }
            },

            position: entity.position,
            bearing: entity.bearing,
        });
    }

    Ok(v5::LevelAssetSer { entities })
}

fn up_v5_to_v6<'a>(
    allocator: &'a Linear,
    level_asset: v5::LevelAssetSer<'_>,
) -> Result<v6::LevelAssetSer<'a>, MigrateError> {
    fn up_entity_type(ty: v5::EntityTypeSer) -> Result<v6::EntityTypeSer, MigrateError> {
        match ty {
            v5::EntityTypeSer::Wizard => Ok(v6::EntityTypeSer::Wizard),
            v5::EntityTypeSer::ManaPotion => Err(MigrateError),
            v5::EntityTypeSer::Exit => Ok(v6::EntityTypeSer::Exit),
            v5::EntityTypeSer::Water => Ok(v6::EntityTypeSer::Water),
            v5::EntityTypeSer::Ground => Ok(v6::EntityTypeSer::Ground),
            v5::EntityTypeSer::Tree => Ok(v6::EntityTypeSer::Tree),
            v5::EntityTypeSer::WoodenCrate => Ok(v6::EntityTypeSer::WoodenCrate),
            v5::EntityTypeSer::IronCrate => Ok(v6::EntityTypeSer::IronCrate),
            v5::EntityTypeSer::Key => Ok(v6::EntityTypeSer::Key),
            v5::EntityTypeSer::Gate => Ok(v6::EntityTypeSer::Gate),
            v5::EntityTypeSer::ManaSource => Ok(v6::EntityTypeSer::TranspositionStone),
            v5::EntityTypeSer::SkellyWarrior => Ok(v6::EntityTypeSer::SkellyWarrior),
            v5::EntityTypeSer::SkellyArcher => Ok(v6::EntityTypeSer::SkellyArcher),
        }
    }

    log::debug!("Upping level from V5 to V6");

    let mut entities = Vec::with_capacity_in(level_asset.entities.len(), allocator);
    for entity in &level_asset.entities {
        entities.push(v6::EntityInitSer {
            ty: up_entity_type(entity.ty)?,
            data: match entity.data {
                v5::EntityDataInitSer::Wizard(data) => v6::EntityDataInitSer::Wizard(data),
                v5::EntityDataInitSer::ManaPotion(_) => {
                    // NB: We stopped supporting ManaPotions here
                    return Err(MigrateError);
                }
                v5::EntityDataInitSer::Exit(data) => v6::EntityDataInitSer::Exit(data),
                v5::EntityDataInitSer::Water(data) => v6::EntityDataInitSer::Water(data),
                v5::EntityDataInitSer::Ground(data) => v6::EntityDataInitSer::Ground(data),
                v5::EntityDataInitSer::Tree(data) => v6::EntityDataInitSer::Tree(data),
                v5::EntityDataInitSer::WoodenCrate(data) => {
                    v6::EntityDataInitSer::WoodenCrate(data)
                }
                v5::EntityDataInitSer::IronCrate(data) => v6::EntityDataInitSer::IronCrate(data),
                v5::EntityDataInitSer::Key(data) => v6::EntityDataInitSer::Key(data),
                v5::EntityDataInitSer::Gate(data) => v6::EntityDataInitSer::Gate(data),
                v5::EntityDataInitSer::ManaSource(data) => {
                    v6::EntityDataInitSer::TranspositionStone(
                        v6::TranspositionStoneEntityDataInitSer {
                            anim: data.anim,
                            anim_active: data.anim_active,
                        },
                    )
                }
                v5::EntityDataInitSer::SkellyWarrior(data) => {
                    v6::EntityDataInitSer::SkellyWarrior(data)
                }
                v5::EntityDataInitSer::SkellyArcher(data) => {
                    v6::EntityDataInitSer::SkellyArcher(data)
                }
            },

            position: entity.position,
            bearing: entity.bearing,
        });
    }

    Ok(v6::LevelAssetSer { entities })
}

fn up_v6_to_v7<'a>(
    allocator: &'a Linear,
    level_asset: v6::LevelAssetSer<'_>,
) -> Result<v7::LevelAssetSer<'a>, MigrateError> {
    fn up_entity_type(ty: v6::EntityTypeSer) -> Result<v7::EntityTypeSer, MigrateError> {
        match ty {
            v6::EntityTypeSer::Wizard => Ok(v7::EntityTypeSer::Wizard),
            v6::EntityTypeSer::Exit => Ok(v7::EntityTypeSer::Exit),
            v6::EntityTypeSer::Water => Ok(v7::EntityTypeSer::Water),
            v6::EntityTypeSer::Ground => Ok(v7::EntityTypeSer::Ground),
            v6::EntityTypeSer::Tree => Ok(v7::EntityTypeSer::Tree),
            v6::EntityTypeSer::WoodenCrate => Ok(v7::EntityTypeSer::WoodenCrate),
            v6::EntityTypeSer::IronCrate => Ok(v7::EntityTypeSer::IronCrate),
            v6::EntityTypeSer::Key => Ok(v7::EntityTypeSer::Key),
            v6::EntityTypeSer::Gate => Ok(v7::EntityTypeSer::KeyGate),
            v6::EntityTypeSer::TranspositionStone => Ok(v7::EntityTypeSer::TranspositionStone),
            v6::EntityTypeSer::SummoningStone => Ok(v7::EntityTypeSer::SummoningStone),
            v6::EntityTypeSer::FamiliarCat => Ok(v7::EntityTypeSer::FamiliarCat),
            v6::EntityTypeSer::SkellyWarrior => Ok(v7::EntityTypeSer::SkellyWarrior),
            v6::EntityTypeSer::SkellyArcher => Ok(v7::EntityTypeSer::SkellyArcher),
        }
    }

    fn up_entity_data(data: v6::EntityDataInitSer) -> Result<v7::EntityDataInitSer, MigrateError> {
        match data {
            v6::EntityDataInitSer::Wizard(data) => Ok(v7::EntityDataInitSer::Wizard(data)),
            v6::EntityDataInitSer::Exit(data) => Ok(v7::EntityDataInitSer::Exit(data)),
            v6::EntityDataInitSer::Water(data) => Ok(v7::EntityDataInitSer::Water(data)),
            v6::EntityDataInitSer::Ground(data) => Ok(v7::EntityDataInitSer::Ground(data)),
            v6::EntityDataInitSer::Tree(data) => Ok(v7::EntityDataInitSer::Tree(data)),
            v6::EntityDataInitSer::WoodenCrate(data) => {
                Ok(v7::EntityDataInitSer::WoodenCrate(data))
            }
            v6::EntityDataInitSer::IronCrate(data) => Ok(v7::EntityDataInitSer::IronCrate(data)),
            v6::EntityDataInitSer::Key(data) => Ok(v7::EntityDataInitSer::Key(data)),
            v6::EntityDataInitSer::Gate(data) => Ok(v7::EntityDataInitSer::KeyGate(
                v7::KeyGateEntityDataInitSer {
                    open: data.open,
                    anim: data.anim,
                    anim_open: data.anim_open,
                },
            )),
            v6::EntityDataInitSer::TranspositionStone(data) => {
                Ok(v7::EntityDataInitSer::TranspositionStone(data))
            }
            v6::EntityDataInitSer::SummoningStone(data) => {
                Ok(v7::EntityDataInitSer::SummoningStone(data))
            }
            v6::EntityDataInitSer::FamiliarCat(data) => {
                Ok(v7::EntityDataInitSer::FamiliarCat(data))
            }
            v6::EntityDataInitSer::SkellyWarrior(data) => {
                Ok(v7::EntityDataInitSer::SkellyWarrior(data))
            }
            v6::EntityDataInitSer::SkellyArcher(data) => {
                Ok(v7::EntityDataInitSer::SkellyArcher(data))
            }
        }
    }

    log::debug!("Upping level from V6 to V7");

    let mut entities = Vec::with_capacity_in(level_asset.entities.len(), allocator);
    for entity in &level_asset.entities {
        entities.push(v7::EntityInitSer {
            ty: up_entity_type(entity.ty)?,
            data: up_entity_data(entity.data)?,

            position: entity.position,
            bearing: entity.bearing,

            volume_idle: AssetName::new(asset::NAME_MISSING_VOLUME),
        });
    }

    Ok(v7::LevelAssetSer { entities })
}

pub mod v1 {
    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::IVec3;

    use crate::asset::AssetName;
    use crate::gameplay::Bearing;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("V1LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub size: [u16; 3],
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Default)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityFlags"))]
    pub struct EntityFlagsSer(u32);

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityTypeSer {
        Wizard,
        ManaPotion,
        Exit,
        Water,
        Ground,
        Tree,
        WoodenCrate,
        IronCrate,
        Key,
        Gate,
        ManaSource,
        SkellyWarrior,
        SkellyArcher,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub flags: EntityFlagsSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,

        pub anim_idle_front: Option<AnimationSer>,
        pub anim_idle_back: Option<AnimationSer>,
        pub anim_idle_left: Option<AnimationSer>,
        pub anim_idle_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        None,
        Gate(GateEntityDataInitSer),
        ManaSource(ManaSourceEntityDataInitSer),
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GateEntityDataInit"))]
    pub struct GateEntityDataInitSer {
        pub open: bool,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaSourceEntityDataInit"))]
    pub struct ManaSourceEntityDataInitSer {
        pub anim_active_front: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("Animation"))]
    pub struct AnimationSer {
        pub texture_name: AssetName,
        pub frame: RectSer,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("Rect"))]
    pub struct RectSer {
        pub x: f32,
        pub y: f32,
        pub width: f32,
        pub height: f32,
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum BearingSer {
        North,
        South,
        East,
        West,
    }

    impl From<Bearing> for BearingSer {
        fn from(bearing: Bearing) -> Self {
            match bearing {
                Bearing::North => Self::North,
                Bearing::South => Self::South,
                Bearing::East => Self::East,
                Bearing::West => Self::West,
            }
        }
    }

    impl From<BearingSer> for Bearing {
        fn from(bearing: BearingSer) -> Self {
            match bearing {
                BearingSer::North => Self::North,
                BearingSer::South => Self::South,
                BearingSer::East => Self::East,
                BearingSer::West => Self::West,
            }
        }
    }
}

pub mod v2 {
    #[rustfmt::skip]
    pub use super::v1::*;

    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::IVec3;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("V2LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub size: [u16; 3],
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,

        pub anim_idle_front: Option<AnimationSer>,
        pub anim_idle_back: Option<AnimationSer>,
        pub anim_idle_left: Option<AnimationSer>,
        pub anim_idle_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        None,
        Gate(GateEntityDataInitSer),
        ManaSource(ManaSourceEntityDataInitSer),
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GateEntityDataInit"))]
    pub struct GateEntityDataInitSer {
        pub open: bool,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaSourceEntityDataInit"))]
    pub struct ManaSourceEntityDataInitSer {
        pub anim_active_front: Option<AnimationSer>,
    }
}

pub mod v3 {
    #[rustfmt::skip]
    pub use super::v2::*;

    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::IVec3;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub size: [u16; 3],
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,

        pub anim_idle_front: Option<AnimationSer>,
        pub anim_idle_back: Option<AnimationSer>,
        pub anim_idle_left: Option<AnimationSer>,
        pub anim_idle_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        None,
        Gate(GateEntityDataInitSer),
        ManaSource(ManaSourceEntityDataInitSer),
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GateEntityDataInit"))]
    pub struct GateEntityDataInitSer {
        pub open: bool,
        pub anim_open_front: Option<AnimationSer>,
        pub anim_open_back: Option<AnimationSer>,
        pub anim_open_left: Option<AnimationSer>,
        pub anim_open_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaSourceEntityDataInit"))]
    pub struct ManaSourceEntityDataInitSer {
        pub anim_active_front: Option<AnimationSer>,
        pub anim_active_back: Option<AnimationSer>,
        pub anim_active_left: Option<AnimationSer>,
        pub anim_active_right: Option<AnimationSer>,
    }
}

pub mod v4 {
    #[rustfmt::skip]
    pub use super::v3::*;

    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::IVec3;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub size: [u16; 3],
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        Wizard(WizardEntityDataInitSer),
        ManaPotion(ManaPotionEntityDataInitSer),
        Exit(ExitEntityDataInitSer),
        Water(WaterEntityDataInitSer),
        Ground(GroundEntityDataInitSer),
        Tree(TreeEntityDataInitSer),
        WoodenCrate(WoodenCrateEntityDataInitSer),
        IronCrate(IronCrateEntityDataInitSer),
        Key(KeyEntityDataInitSer),
        Gate(GateEntityDataInitSer),
        ManaSource(ManaSourceEntityDataInitSer),
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("WizardEntityDataInit"))]
    pub struct WizardEntityDataInitSer {
        pub anim_front: Option<AnimationSer>,
        pub anim_back: Option<AnimationSer>,
        pub anim_left: Option<AnimationSer>,
        pub anim_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaPotionEntityDataInit"))]
    pub struct ManaPotionEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ExitEntityDataInit"))]
    pub struct ExitEntityDataInitSer {
        pub anim_top: Option<AnimationSer>,
        pub anim_sides: Option<AnimationSer>,
        pub anim_bottom: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("WaterEntityDataInit"))]
    pub struct WaterEntityDataInitSer {
        pub anim_top: Option<AnimationSer>,
        pub anim_sides: Option<AnimationSer>,
        pub anim_bottom: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GroundEntityDataInit"))]
    pub struct GroundEntityDataInitSer {
        pub anim_top: Option<AnimationSer>,
        pub anim_sides: Option<AnimationSer>,
        pub anim_bottom: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("TreeEntityDataInit"))]
    pub struct TreeEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("WoodenCrateEntityDataInit"))]
    pub struct WoodenCrateEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("IronCrateEntityDataInit"))]
    pub struct IronCrateEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("KeyEntityDataInit"))]
    pub struct KeyEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GateEntityDataInit"))]
    pub struct GateEntityDataInitSer {
        pub open: bool,
        pub anim_top: Option<AnimationSer>,
        pub anim_sides: Option<AnimationSer>,
        pub anim_bottom: Option<AnimationSer>,
        pub anim_open_top: Option<AnimationSer>,
        pub anim_open_sides: Option<AnimationSer>,
        pub anim_open_bottom: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaSourceEntityDataInit"))]
    pub struct ManaSourceEntityDataInitSer {
        pub anim: Option<AnimationSer>,
        pub anim_active: Option<AnimationSer>,
    }
}

pub mod v5 {
    #[rustfmt::skip]
    pub use super::v4::*;

    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::{IRect, IVec3};

    use crate::asset::AssetName;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        Wizard(WizardEntityDataInitSer),
        ManaPotion(ManaPotionEntityDataInitSer),
        Exit(ExitEntityDataInitSer),
        Water(WaterEntityDataInitSer),
        Ground(GroundEntityDataInitSer),
        Tree(TreeEntityDataInitSer),
        WoodenCrate(WoodenCrateEntityDataInitSer),
        IronCrate(IronCrateEntityDataInitSer),
        Key(KeyEntityDataInitSer),
        Gate(GateEntityDataInitSer),
        ManaSource(ManaSourceEntityDataInitSer),
        SkellyWarrior(SkellyWarriorEntityDataInitSer),
        SkellyArcher(SkellyArcherEntityDataInitSer),
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("WizardEntityDataInit"))]
    pub struct WizardEntityDataInitSer {
        pub anim_front: Option<AnimationSer>,
        pub anim_back: Option<AnimationSer>,
        pub anim_left: Option<AnimationSer>,
        pub anim_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaPotionEntityDataInit"))]
    pub struct ManaPotionEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ExitEntityDataInit"))]
    pub struct ExitEntityDataInitSer {
        pub anim: Option<VolumeAnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("WaterEntityDataInit"))]
    pub struct WaterEntityDataInitSer {
        pub anim: Option<VolumeAnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GroundEntityDataInit"))]
    pub struct GroundEntityDataInitSer {
        pub anim: Option<VolumeAnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("TreeEntityDataInit"))]
    pub struct TreeEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("WoodenCrateEntityDataInit"))]
    pub struct WoodenCrateEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("IronCrateEntityDataInit"))]
    pub struct IronCrateEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("KeyEntityDataInit"))]
    pub struct KeyEntityDataInitSer {
        pub anim: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("GateEntityDataInit"))]
    pub struct GateEntityDataInitSer {
        pub open: bool,
        pub anim: Option<VolumeAnimationSer>,
        pub anim_open: Option<VolumeAnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("ManaSourceEntityDataInit"))]
    pub struct ManaSourceEntityDataInitSer {
        pub anim: Option<AnimationSer>,
        pub anim_active: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("SkellyWarriorEntityDataInit"))]
    pub struct SkellyWarriorEntityDataInitSer {
        pub anim_front: Option<AnimationSer>,
        pub anim_back: Option<AnimationSer>,
        pub anim_left: Option<AnimationSer>,
        pub anim_right: Option<AnimationSer>,
        pub anim_aggro_front: Option<AnimationSer>,
        pub anim_aggro_back: Option<AnimationSer>,
        pub anim_aggro_left: Option<AnimationSer>,
        pub anim_aggro_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("SkellyArcherEntityDataInit"))]
    pub struct SkellyArcherEntityDataInitSer {
        pub anim_front: Option<AnimationSer>,
        pub anim_back: Option<AnimationSer>,
        pub anim_left: Option<AnimationSer>,
        pub anim_right: Option<AnimationSer>,
        pub anim_aggro_front: Option<AnimationSer>,
        pub anim_aggro_back: Option<AnimationSer>,
        pub anim_aggro_left: Option<AnimationSer>,
        pub anim_aggro_right: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("Animation"))]
    pub struct AnimationSer {
        pub texture_name: AssetName,
        pub frame: IRectSer,
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("VolumeAnimationDirections"))]
    pub struct VolumeAnimationDirectionsSer(pub u8);

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("VolumeAnimation"))]
    pub struct VolumeAnimationSer {
        pub top: Option<AnimationSer>,
        pub top_directions: VolumeAnimationDirectionsSer,
        pub top_offset: f32,
        pub sides: Option<AnimationSer>,
        pub sides_directions: VolumeAnimationDirectionsSer,
        pub sides_offset: f32,
        pub bottom: Option<AnimationSer>,
        pub bottom_directions: VolumeAnimationDirectionsSer,
        pub bottom_offset: f32,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("IRect"))]
    pub struct IRectSer {
        pub x: i32,
        pub y: i32,
        pub width: i32,
        pub height: i32,
    }

    impl From<IRect> for IRectSer {
        fn from(irect: IRect) -> Self {
            Self {
                x: irect.x,
                y: irect.y,
                width: irect.width,
                height: irect.height,
            }
        }
    }
}

pub mod v6 {
    #[rustfmt::skip]
    pub use super::v5::*;

    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::IVec3;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityTypeSer {
        Wizard,
        Exit,
        Water,
        Ground,
        Tree,
        WoodenCrate,
        IronCrate,
        Key,
        Gate,
        TranspositionStone,
        SummoningStone,
        FamiliarCat,
        SkellyWarrior,
        SkellyArcher,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        Wizard(WizardEntityDataInitSer),
        Exit(ExitEntityDataInitSer),
        Water(WaterEntityDataInitSer),
        Ground(GroundEntityDataInitSer),
        Tree(TreeEntityDataInitSer),
        WoodenCrate(WoodenCrateEntityDataInitSer),
        IronCrate(IronCrateEntityDataInitSer),
        Key(KeyEntityDataInitSer),
        Gate(GateEntityDataInitSer),
        TranspositionStone(TranspositionStoneEntityDataInitSer),
        SummoningStone(SummoningStoneEntityDataInitSer),
        FamiliarCat(FamiliarCatEntityDataInitSer),
        SkellyWarrior(SkellyWarriorEntityDataInitSer),
        SkellyArcher(SkellyArcherEntityDataInitSer),
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("TranspositionStoneEntityDataInit"))]
    pub struct TranspositionStoneEntityDataInitSer {
        pub anim: Option<AnimationSer>,
        pub anim_active: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("SummoningStoneEntityDataInit"))]
    pub struct SummoningStoneEntityDataInitSer {
        pub anim: Option<AnimationSer>,
        pub anim_active: Option<AnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("FamiliarCatEntityDataInit"))]
    pub struct FamiliarCatEntityDataInitSer {
        pub anim_front: Option<AnimationSer>,
        pub anim_back: Option<AnimationSer>,
        pub anim_left: Option<AnimationSer>,
        pub anim_right: Option<AnimationSer>,
    }
}

pub mod v7 {
    #[rustfmt::skip]
    pub use super::v6::*;

    use alloc::vec::Vec;

    use lfg_alloc::Linear;
    use lfg_cereal as cereal;
    use lfg_math::IVec3;

    use crate::asset::AssetName;
    use crate::gameplay::{BinaryBooleanOp, UnaryBooleanOp};
    use crate::idmap::Id;

    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"), rename("LevelAsset"))]
    pub struct LevelAssetSer<'a> {
        pub entities: Vec<EntityInitSer, &'a Linear>,
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityTypeSer {
        Wizard,
        Exit,
        Water,
        Ground,
        Tree,
        WoodenCrate,
        IronCrate,
        Key,
        KeyGate,
        TranspositionStone,
        SummoningStone,
        FamiliarCat,
        SkellyWarrior,
        SkellyArcher,
        PressurePlate,
        PressurePlateGate,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("EntityInit"))]
    pub struct EntityInitSer {
        pub ty: EntityTypeSer,
        pub data: EntityDataInitSer,

        pub position: IVec3,
        pub bearing: BearingSer,

        pub volume_idle: AssetName,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum EntityDataInitSer {
        Wizard(WizardEntityDataInitSer),
        Exit(ExitEntityDataInitSer),
        Water(WaterEntityDataInitSer),
        Ground(GroundEntityDataInitSer),
        Tree(TreeEntityDataInitSer),
        WoodenCrate(WoodenCrateEntityDataInitSer),
        IronCrate(IronCrateEntityDataInitSer),
        Key(KeyEntityDataInitSer),
        KeyGate(KeyGateEntityDataInitSer),
        TranspositionStone(TranspositionStoneEntityDataInitSer),
        SummoningStone(SummoningStoneEntityDataInitSer),
        FamiliarCat(FamiliarCatEntityDataInitSer),
        SkellyWarrior(SkellyWarriorEntityDataInitSer),
        SkellyArcher(SkellyArcherEntityDataInitSer),
        PressurePlate(PressurePlateEntityDataInitSer),
        PressurePlateGate(PressurePlateGateEntityDataInitSer),
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("KeyGateEntityDataInit"))]
    pub struct KeyGateEntityDataInitSer {
        pub open: bool,
        pub anim: Option<VolumeAnimationSer>,
        pub anim_open: Option<VolumeAnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("PressurePlateEntityDataInit"))]
    pub struct PressurePlateEntityDataInitSer {
        pub anim: Option<VolumeAnimationSer>,
        pub anim_pressed: Option<VolumeAnimationSer>,
    }

    #[derive(Debug, Clone, Copy, PartialEq)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("PressurePlateGateEntityDataInit"))]
    pub struct PressurePlateGateEntityDataInitSer {
        pub anim: Option<VolumeAnimationSer>,
        pub anim_open: Option<VolumeAnimationSer>,
        pub open_if_active: [Option<(UnaryBooleanOpSer, IdSer)>; 4],
        pub open_if_active_op: BinaryBooleanOpSer,
    }

    // This is just the index from the runtime ID
    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    #[cereal(rename("Id"))]
    pub struct IdSer(u16);

    impl From<Id> for IdSer {
        fn from(id: Id) -> Self {
            IdSer(id.idx())
        }
    }

    impl From<IdSer> for Id {
        fn from(id: IdSer) -> Self {
            Id::from_idx_initial_gen(id.0)
        }
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum UnaryBooleanOpSer {
        Identity,
        Not,
    }

    impl From<UnaryBooleanOp> for UnaryBooleanOpSer {
        fn from(op: UnaryBooleanOp) -> Self {
            match op {
                UnaryBooleanOp::Identity => Self::Identity,
                UnaryBooleanOp::Not => Self::Not,
            }
        }
    }

    impl From<UnaryBooleanOpSer> for UnaryBooleanOp {
        fn from(op: UnaryBooleanOpSer) -> Self {
            match op {
                UnaryBooleanOpSer::Identity => Self::Identity,
                UnaryBooleanOpSer::Not => Self::Not,
            }
        }
    }

    #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
    #[derive(cereal::Serialize, cereal::Deserialize)]
    pub enum BinaryBooleanOpSer {
        And,
        Or,
        Xor,
    }

    impl From<BinaryBooleanOp> for BinaryBooleanOpSer {
        fn from(op: BinaryBooleanOp) -> Self {
            match op {
                BinaryBooleanOp::And => Self::And,
                BinaryBooleanOp::Or => Self::Or,
                BinaryBooleanOp::Xor => Self::Xor,
            }
        }
    }

    impl From<BinaryBooleanOpSer> for BinaryBooleanOp {
        fn from(op: BinaryBooleanOpSer) -> Self {
            match op {
                BinaryBooleanOpSer::And => Self::And,
                BinaryBooleanOpSer::Or => Self::Or,
                BinaryBooleanOpSer::Xor => Self::Xor,
            }
        }
    }
}

pub mod vcurrent {
    #[rustfmt::skip]
    pub use super::v7::*;
}
