use core::f32::consts::{PI, TAU};

use lfg_math::{
    const_radians,
    libm,
    vec3,
    CubicBezierCurve,
    Mat4,
    Quat,
    UVec2,
    Vec2,
    Vec3,
    Vec3Swizzles as _,
};

const INCLINATION_MIN: f32 = 5.0_f32 * PI / 180.0_f32;
const INCLINATION_MAX: f32 = PI - INCLINATION_MIN;

// TODO(yan): Make camera inclination configurable per-level. Possibly allow
// even multiple inclinations the player can cycle through.
pub const DEFAULT_INCLINATION: f32 = const_radians!(150.0);
pub const DEFAULT_INCLINATION_INV: f32 = const_radians!(180.0 - 150.0);

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct CameraOptions {
    pub fovy: f32,
    pub znear: f32,
    pub zfar: f32,
    pub unsteadiness: f32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct Camera {
    // TODO(yan): Is this enough precision for 72 hours?
    time: f32,
    physical_window_size: UVec2,
    position: Vec3,
    position_unsteady_offset: Vec3,
    position_interpolation: Option<Interpolation>,
    azimuth: f32,
    inclination: f32,
    options: CameraOptions,
}

impl Camera {
    /// Creates a new camera with screen dimensions, radius, azimuth and
    /// inclination. Both angles are measured as if the camera was the center of
    /// the sphere pointing outwards.
    ///
    /// Azimuth ranges from 0 to TAU and wraps. Zero is (1, 0, 0) in Z-up RH
    /// cartesian coordinates, PI/2 is (0, 1, 0), PI is (-1, 0, 0), etc.
    ///
    /// Inclination ranges from 0 to PI and doesn't wrap. Zero is (0, 0, 1) in
    /// Z-up RH cartesian coordinates, PI/2 is (x, y, 0), PI is (0, 0, -1).
    pub fn new(
        time: f32,
        physical_window_size: UVec2,
        position: Vec3,
        azimuth: f32,
        inclination: f32,
        options: CameraOptions,
    ) -> Camera {
        Camera {
            time,
            physical_window_size,
            position,
            position_unsteady_offset: Vec3::ZERO,
            position_interpolation: None,
            azimuth: azimuth % TAU,
            inclination: f32::clamp(inclination, INCLINATION_MIN, INCLINATION_MAX),
            options,
        }
    }

    pub fn update(&mut self, time: f32, physical_window_size: UVec2) {
        // TODO(yan): Lerp with easing instead?
        // TODO(yan): @Speed Vectorize!

        self.time = time;
        self.physical_window_size = physical_window_size;

        self.position_unsteady_offset = vec3(
            libm::sinf(time / 2.0),
            libm::sinf(time / 2.5),
            libm::sinf(time / 3.0),
        ) * self.options.unsteadiness;

        if let Some(interpolation) = self.position_interpolation {
            let duration = interpolation.target_time - interpolation.source_time;
            let duration_passed = time - interpolation.source_time;
            let x = duration_passed / duration;

            if x < 1.0 {
                let t = interpolation.curve.evaluate(x);
                let source = interpolation.source_value;
                let target = interpolation.target_value;
                self.position = Vec3::lerp(source, target, t);
            } else {
                self.position = interpolation.target_value;
                self.position_interpolation = None;
            }
        }
    }

    pub fn set_position(&mut self, position: Vec3) {
        self.position = position;
        self.position_interpolation = None;
    }

    pub fn interpolate_position(
        &mut self,
        target_position: Vec3,
        duration: f32,
        curve: CubicBezierCurve,
    ) {
        self.position_interpolation = Some(Interpolation {
            curve,
            source_value: self.position,
            source_time: self.time,
            target_value: target_position,
            target_time: self.time + duration,
        });
    }

    pub fn change_position(&mut self, dposition: Vec3) {
        self.position += dposition;
        self.position_interpolation = None;
    }

    #[allow(dead_code)]
    pub fn set_orientation(&mut self, azimuth: f32, inclination: f32) {
        self.azimuth = azimuth % TAU;
        self.inclination = f32::clamp(inclination, INCLINATION_MIN, INCLINATION_MAX);
    }

    /// Sets camera orientation to look at a point in the cartesian space.
    ///
    /// Does nothing if the X and Y components of the point and the camera
    /// position are equal to zero.
    #[allow(dead_code)]
    pub fn set_orientation_to_look_at(&mut self, point: Vec3) {
        let direction = point - self.position;

        // Note: We terminate early if (x,y) is a zero vector. This is because
        // arctan2(y, x) has domain R^2, where x^2 + y^2 > 0. This also makes
        // sense intuitively, as with both X and Y components being zero there
        // is no way to determine the azimuth.
        if direction.xy() == Vec2::ZERO {
            return;
        }

        // Note: We normalize only because arccos(x) has domain [-1, 1],
        // arctan2(y, x) would handle any nonzero 2D vector as input.
        let unit_direction = direction.normalize();

        self.azimuth = libm::atan2f(unit_direction.y, unit_direction.x) % TAU;
        self.inclination = f32::clamp(
            libm::acosf(unit_direction.z),
            INCLINATION_MIN,
            INCLINATION_MAX,
        );
    }

    pub fn change_orientation(&mut self, dazimuth: f32, dinclination: f32) {
        self.azimuth = (self.azimuth + dazimuth) % TAU;
        self.inclination = f32::clamp(
            self.inclination + dinclination,
            INCLINATION_MIN,
            INCLINATION_MAX,
        );
    }

    pub fn set_azimuth(&mut self, azimuth: f32) {
        self.azimuth = azimuth % TAU;
    }

    pub fn set_inclination(&mut self, inclination: f32) {
        self.inclination = f32::clamp(inclination, INCLINATION_MIN, INCLINATION_MAX);
    }

    pub fn position(&self) -> Vec3 {
        self.position + self.position_unsteady_offset
    }

    #[allow(dead_code)]
    pub fn orientation(&self) -> Quat {
        let azimuth_rotation = Quat::from_rotation_z(self.azimuth);
        let inclination_rotation = Quat::from_rotation_y(-90_f32.to_radians() + self.inclination);

        azimuth_rotation * inclination_rotation
    }

    pub fn direction(&self) -> Vec3 {
        let x = libm::cosf(self.azimuth) * libm::sinf(self.inclination);
        let y = libm::sinf(self.azimuth) * libm::sinf(self.inclination);
        let z = libm::cosf(self.inclination);

        vec3(x, y, z)
    }

    pub fn view_matrix(&self) -> Mat4 {
        let position = self.position();
        Mat4::look_at_rh(position, position + self.direction(), Vec3::Z)
    }

    pub fn projection_matrix(&self) -> Mat4 {
        // TODO(yan): @Correctness @Portability In what coordinate system are
        // we? Why does this actually work? We originally used
        // Mat4::perspective_rh_gl and it worked. Why?
        let aspect_ratio = self.physical_window_size.x as f32 / self.physical_window_size.y as f32;
        Mat4::perspective_rh(
            self.options.fovy,
            aspect_ratio,
            self.options.znear,
            self.options.zfar,
        )
    }

    /// Returns the position where the ray cast from screen positon intersects
    /// the near plane as well as the direction of the ray, both in world-space
    /// coordinates.
    pub fn ray_from_screen_position(&self, physical_screen_position: Vec2) -> (Vec3, Vec3) {
        // TODO(yan): @Correctness Check inverse matrices validity and do
        // nothing for invalid matrices.
        let projection_matrix_inverse = self.projection_matrix().inverse();
        let view_matrix_inverse = self.view_matrix().inverse();

        let window_size = self.physical_window_size.as_vec2();
        let screen_x = physical_screen_position.x;
        let screen_y = physical_screen_position.y;

        let ndc_x = screen_x / window_size.x * 2.0 - 1.0;
        let ndc_y = (window_size.y - screen_y) / window_size.y * 2.0 - 1.0;

        // TODO(yan): @Corretness @Portability Which NDC are we assuming?
        // OpenGL? D3D?
        let ndc_near = Vec3::new(ndc_x, ndc_y, -1.0);
        let ndc_far = Vec3::new(ndc_x, ndc_y, 1.0);

        // We use project_point3 instead of transform_point3, because the matrix
        // does not contain a valid affine transform.
        let eye_near = projection_matrix_inverse.project_point3(ndc_near);
        let eye_far = projection_matrix_inverse.project_point3(ndc_far);

        // We use project_point3 instead of transform_point3, because while the
        // matrix should contain a valid affine transform, it sometimes doesn't.
        let world_near = view_matrix_inverse.project_point3(eye_near);
        let world_far = view_matrix_inverse.project_point3(eye_far);

        // Note: ray_origin is world_near. It could also be the camera position
        // and it would still be a valid world position as far as the ray itself
        // is concerned, but we'd like distinct positions for ray origins,
        // e.g. when we are doing a rectangle selection with the cursor and want
        // to construct plane normals.
        let ray_origin = world_near;
        let ray_direction = (world_far - world_near).normalize();

        (ray_origin, ray_direction)
    }
}

#[derive(Debug, Clone, Copy, PartialEq)]
struct Interpolation {
    curve: CubicBezierCurve,
    source_value: Vec3,
    source_time: f32,
    target_value: Vec3,
    target_time: f32,
}
