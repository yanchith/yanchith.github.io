use core::ops::{Add, AddAssign, Sub};
use core::time::Duration;

// TODO(yan): Consider removing this altogether, and just use Duration.

/// Like std's `Instant`, but without platform co-dependence and
/// angst. [`Time::ZERO`] is the time when [`game_init`] was called.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct Time(Duration);

impl Time {
    pub const ZERO: Time = Time(Duration::ZERO);

    #[allow(dead_code)]
    pub fn as_secs_f32(&self) -> f32 {
        self.0.as_secs_f32()
    }
}

impl Add<Duration> for Time {
    type Output = Self;

    fn add(self, other: Duration) -> Self {
        Self(self.0 + other)
    }
}

impl AddAssign<Duration> for Time {
    fn add_assign(&mut self, other: Duration) {
        self.0 += other;
    }
}

impl Sub<Time> for Time {
    type Output = Duration;

    fn sub(self, other: Time) -> Duration {
        self.0 - other.0
    }
}
