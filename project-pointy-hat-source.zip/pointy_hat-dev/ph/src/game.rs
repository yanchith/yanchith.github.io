use alloc::alloc::Global;
use alloc::vec::Vec;
use core::str;
use core::time::Duration;

use arrayvec::{ArrayString, ArrayVec};
use lfg_alloc::Linear;
use lfg_common::megabytes;
use lfg_math::{
    color_u32,
    vec2,
    vec3,
    Color,
    CubicBezierCurve,
    IRect,
    IVec3,
    Mat4,
    Quat,
    Rect,
    Vec3,
};
use ph_platform::Platform;
use ph_renderer::{
    ColorSpace,
    Draw3DRectPrimitive,
    Draw3DVoxelPrimitive,
    Frame,
    RenderMode,
    Renderer,
    Sampler,
};

use crate::arena::Arena;
use crate::asset::{self, AssetId};
use crate::asset_catalog::{self, AssetCatalog};
use crate::camera::{self, Camera, CameraOptions};
use crate::draw_list::DrawList;
use crate::gameplay::{
    self,
    Action,
    Animation,
    Bearing,
    Entity,
    EntityInit,
    EntityType,
    Item,
    Level,
    LevelStateTransition,
    RunningAnimations,
    Turn,
    VolumeAnimationDirections,
};
use crate::grid::Grid;
use crate::history::{History, HistoryError};
use crate::idmap::{Id, IdMap};
use crate::input::{Input, Key, KeyState, Mb};
use crate::time::Time;
use crate::xraw::{self, XRawDataRef};

macro_rules! fmt {
    ($dst:expr, $($fmt:tt)*) => ({
        use core::fmt::Write;

        $dst.clear();
        core::write!($dst, $($fmt)*).unwrap();

        &$dst
    });
}

const CAMERA_SPEED: f32 = 5.0;
const CAMERA_SPEED_FAST: f32 = 20.0;

const MOVE_REPEAT_DELAY: Duration = Duration::from_millis(200);
const MOVE_REPEAT_COOLDOWN: Duration = Duration::from_millis(100);
const INTERACT_REPEAT_DELAY: Duration = MOVE_REPEAT_DELAY;
const INTERACT_REPEAT_COOLDOWN: Duration = MOVE_REPEAT_COOLDOWN;
const REWIND_REPEAT_DELAY: Duration = MOVE_REPEAT_DELAY;
const REWIND_REPEAT_COOLDOWN: Duration = MOVE_REPEAT_COOLDOWN;
const SWITCH_CHARACTER_REPEAT_DELAY: Duration = MOVE_REPEAT_DELAY;
const SWITCH_CHARACTER_REPEAT_COOLDOWN: Duration = MOVE_REPEAT_COOLDOWN;

const HISTORY_CAPACITY: usize = 50000;

const ASSET_ICON_KEY: AssetId = AssetId::const_new("./data/images/icon_key.png");
const ASSET_ICON_FRAME: AssetId = AssetId::const_new("./data/images/icon_frame.png");

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum GameTransition {
    None,
    Editor,
    EditorWithLevel { level_id: AssetId },
    // TODO(yan): MainMenu,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum CurrentLevel {
    None,
    Standalone {
        level_id: AssetId,
    },
    Levelset {
        levelset_id: AssetId,
        level_id: AssetId,
    },
}

#[derive(Debug)]
struct FrameData {
    ui_draw_list: DrawList,
}

#[repr(u8)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
enum InputAction {
    Action(Action),
    Rewind,
    Restart,
}

impl InputAction {
    pub const WAIT: InputAction = Self::Action(Action::Wait);

    pub const UP: InputAction = Self::Action(Action::Move {
        bearing: Bearing::North,
    });

    pub const DOWN: InputAction = Self::Action(Action::Move {
        bearing: Bearing::South,
    });

    pub const LEFT: InputAction = Self::Action(Action::Move {
        bearing: Bearing::West,
    });

    pub const RIGHT: InputAction = Self::Action(Action::Move {
        bearing: Bearing::East,
    });

    pub const TURN_LEFT: InputAction = Self::Action(Action::Turn { turn: Turn::Left });
    pub const TURN_RIGHT: InputAction = Self::Action(Action::Turn { turn: Turn::Right });

    pub const INTERACT: InputAction = Self::Action(Action::Interact);
    pub const SWITCH_CHARACTER: InputAction = Self::Action(Action::SwitchCharacter);
}

pub struct Game {
    time: Time,
    dtime: Duration,

    // TODO(yan): @Bug Tracking these in the editor and the game separately
    // means that when we switch, we might miss the keyup event and keep the
    // state active. We could perhaps lift the key states, time and dtime up to
    // lib.rs.
    key_ctrl_down: bool,
    key_alt_down: bool,
    key_shift_down: bool,
    key_tab_down: bool,

    key_space_down: Option<Time>,
    key_up_down: Option<Time>,
    key_down_down: Option<Time>,
    key_left_down: Option<Time>,
    key_right_down: Option<Time>,
    key_prev_down: Option<Time>,
    key_next_down: Option<Time>,
    key_interact_down: Option<Time>,
    key_switch_character_down: Option<Time>,
    key_rewind_down: Option<Time>,

    // TODO(yan): @Memory Give guise Linear for a permanent allocator and make
    // sure it uses it well.
    ui: guise::Ui<Global>,
    dev_show_fps: bool,

    current_level: CurrentLevel,
    current_level_failed: bool,

    camera: Camera,

    level: Arena<Level>,
    reload_level: bool,

    frame_data: Arena<FrameData>,

    render_mode: RenderMode,
}

impl Game {
    pub fn new<P, R>(
        root_allocator: &mut Linear,
        _temp_allocator: &Linear,
        _platform: &P,
        renderer: &mut R,
        input: &Input,
    ) -> Self
    where
        P: Platform,
        R: Renderer,
    {
        profile_scope!("Game::new");

        let logical_window_size = input.physical_window_size.as_vec2() / input.window_scale_factor;

        let mut ui = guise::Ui::new_in(
            logical_window_size.x,
            logical_window_size.y,
            input.window_scale_factor,
            guise::FONT_IBM_PLEX_MONO,
            guise::UnicodeRangeFlags::ALL_LATIN,
            14.0,
            input.window_scale_factor,
            Global,
        );

        let font_atlas_image = ui.font_atlas_image_rgba8_unorm();
        let (font_atlas_width, font_atlas_height) = ui.font_atlas_image_size();

        renderer.insert_texture_rgba8_unorm(
            asset::ID_GAME_FONT_ATLAS_TEX.into_raw(),
            font_atlas_image,
            font_atlas_width,
            font_atlas_height,
            ColorSpace::Linear,
            Sampler::Bilinear,
        );

        ui.set_font_atlas_texture_id(asset::ID_GAME_FONT_ATLAS_TEX.into_raw());

        let level = Arena::new(root_allocator.split(megabytes(64)).unwrap(), default_level);
        let frame_data = Arena::new(
            root_allocator.split(megabytes(64)).unwrap(),
            default_frame_data,
        );

        Self {
            time: Time::ZERO,
            dtime: Duration::ZERO,

            key_ctrl_down: false,
            key_alt_down: false,
            key_shift_down: false,
            key_tab_down: false,

            key_space_down: None,
            key_up_down: None,
            key_down_down: None,
            key_left_down: None,
            key_right_down: None,
            key_prev_down: None,
            key_next_down: None,
            key_interact_down: None,
            key_switch_character_down: None,
            key_rewind_down: None,

            ui,
            dev_show_fps: false,

            current_level: CurrentLevel::None,
            current_level_failed: false,

            camera: Camera::new(
                0.0,
                input.physical_window_size,
                vec3(0.0, -10.0, 1.0),
                90.0_f32.to_radians(),
                90.0_f32.to_radians(),
                CameraOptions {
                    fovy: 45.0_f32.to_radians(),
                    znear: 0.1,
                    zfar: 1000.0,
                    unsteadiness: 0.05,
                },
            ),

            level,
            reload_level: true,

            frame_data,

            render_mode: RenderMode::Game,
        }
    }

    pub fn open_level(&mut self, asset_catalog: &AssetCatalog, level_id: AssetId) {
        let mut found_levelset_id: Option<AssetId> = None;
        for (levelset_id, levelset_entries) in &asset_catalog.levelset_catalog {
            if levelset_id != asset::ID_IMPLICIT_LEVELSET {
                if levelset_entries
                    .iter()
                    .find(|e| e.level_id == level_id)
                    .is_some()
                {
                    found_levelset_id = Some(levelset_id);
                }
            }
        }

        if let Some(levelset_id) = found_levelset_id {
            self.current_level = CurrentLevel::Levelset {
                levelset_id,
                level_id,
            };
            self.reload_level = true;
        } else {
            self.current_level = CurrentLevel::Standalone { level_id };
            self.reload_level = true;
        }
    }

    pub fn update<P>(
        &mut self,
        temp_allocator: &Linear,
        platform: &P,
        input: &Input,
        asset_catalog: &AssetCatalog,
    ) -> GameTransition
    where
        P: Platform,
    {
        profile_scope!("Game::update");

        let mut transition = GameTransition::None;

        unsafe { Arena::reset(&mut self.frame_data, default_frame_data) };

        self.time += input.dtime;
        self.dtime = input.dtime;

        let dtime_f32 = self.dtime.as_secs_f32();

        let logical_window_size = input.physical_window_size.as_vec2() / input.window_scale_factor;
        let logical_cursor_position = input.physical_cursor_position / input.window_scale_factor;
        let logical_scroll_delta = input.physical_scroll_delta / input.window_scale_factor;

        self.camera
            .update(self.time.as_secs_f32(), input.physical_window_size);

        let mut dev_load_prev_level = false;
        let mut dev_load_next_level = false;

        let mut input_actions: ArrayVec<InputAction, 32> = ArrayVec::new();

        // TODO(yan): Guard against key repeats here, where it makes sense, e.g. for
        // non-dev stuff.
        for &(key, state) in &input.keys {
            let pressed = state == KeyState::Press;

            match key {
                Key::Control => {
                    self.key_ctrl_down = pressed;
                }
                Key::Alt => {
                    self.key_alt_down = pressed;
                }
                Key::Shift => {
                    self.key_shift_down = pressed;
                }

                Key::R => {
                    if pressed {
                        if self.key_ctrl_down {
                            self.reload_level = true;
                        } else {
                            input_actions.push(InputAction::Restart);
                        }
                    }
                }
                Key::LBracket => {
                    if pressed {
                        dev_load_prev_level = true;
                    }
                }
                Key::RBracket => {
                    if pressed {
                        dev_load_next_level = true;
                    }
                }

                Key::Grave => {
                    if pressed {
                        self.dev_show_fps = !self.dev_show_fps;
                    }
                }

                Key::F1 => {
                    if pressed {
                        transition = GameTransition::Editor;

                        if self.key_ctrl_down {
                            match self.current_level {
                                CurrentLevel::None => (),
                                CurrentLevel::Standalone { level_id } => {
                                    transition = GameTransition::EditorWithLevel { level_id };
                                }
                                CurrentLevel::Levelset { level_id, .. } => {
                                    transition = GameTransition::EditorWithLevel { level_id };
                                }
                            }
                        }
                    }
                }
                Key::F3 => {
                    if pressed {
                        self.render_mode = match self.render_mode {
                            RenderMode::Game => RenderMode::DepthMap,
                            RenderMode::DepthMap => RenderMode::Game,
                        };
                    }
                }

                Key::Tab => {
                    self.key_tab_down = pressed;
                }

                Key::Space => {
                    if self.key_space_down.is_none() && pressed {
                        self.key_space_down = Some(self.time);
                        input_actions.push(InputAction::WAIT);
                    } else if self.key_space_down.is_some() && !pressed {
                        self.key_space_down = None;
                    }
                }
                Key::W | Key::Up => {
                    if self.key_up_down.is_none() && pressed {
                        self.key_up_down = Some(self.time);
                        input_actions.push(InputAction::UP);
                    } else if self.key_up_down.is_some() && !pressed {
                        self.key_up_down = None;
                    }
                }
                Key::S | Key::Down => {
                    if self.key_down_down.is_none() && pressed {
                        self.key_down_down = Some(self.time);
                        input_actions.push(InputAction::DOWN);
                    } else if self.key_down_down.is_some() && !pressed {
                        self.key_down_down = None;
                    }
                }
                Key::A | Key::Left => {
                    if self.key_left_down.is_none() && pressed {
                        self.key_left_down = Some(self.time);
                        input_actions.push(InputAction::LEFT);
                    } else if self.key_left_down.is_some() && !pressed {
                        self.key_left_down = None;
                    }
                }
                Key::D | Key::Right => {
                    if self.key_right_down.is_none() && pressed {
                        self.key_right_down = Some(self.time);
                        input_actions.push(InputAction::RIGHT);
                    } else if self.key_right_down.is_some() && !pressed {
                        self.key_right_down = None;
                    }
                }
                Key::Q => {
                    if self.key_prev_down.is_none() && pressed {
                        self.key_prev_down = Some(self.time);
                        input_actions.push(InputAction::TURN_LEFT);
                    } else if self.key_prev_down.is_some() && !pressed {
                        self.key_prev_down = None;
                    }
                }
                Key::E => {
                    if self.key_next_down.is_none() && pressed {
                        self.key_next_down = Some(self.time);
                        input_actions.push(InputAction::TURN_RIGHT);
                    } else if self.key_next_down.is_some() && !pressed {
                        self.key_next_down = None;
                    }
                }
                Key::Z => {
                    if self.key_rewind_down.is_none() && pressed {
                        self.key_rewind_down = Some(self.time);
                        input_actions.push(InputAction::Rewind);
                    } else if self.key_rewind_down.is_some() && !pressed {
                        self.key_rewind_down = None;
                    }
                }
                Key::X => {
                    if self.key_interact_down.is_none() && pressed {
                        self.key_interact_down = Some(self.time);
                        input_actions.push(InputAction::INTERACT);
                    } else if self.key_interact_down.is_some() && !pressed {
                        self.key_interact_down = None;
                    }
                }
                Key::C => {
                    if self.key_switch_character_down.is_none() && pressed {
                        self.key_switch_character_down = Some(self.time);
                        input_actions.push(InputAction::SWITCH_CHARACTER);
                    } else if self.key_switch_character_down.is_some() && !pressed {
                        self.key_switch_character_down = None;
                    }
                }

                Key::Esc => {
                    if pressed {
                        // TODO(yan): @Cleanup is this used for something?
                        self.key_interact_down = None;
                    }
                }

                _ => (),
            }
        }

        if let Some(time) = &mut self.key_space_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::WAIT);
            }
        }

        if let Some(time) = &mut self.key_up_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::UP);
            }
        }

        if let Some(time) = &mut self.key_down_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::DOWN);
            }
        }

        if let Some(time) = &mut self.key_left_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::LEFT);
            }
        }

        if let Some(time) = &mut self.key_right_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::RIGHT);
            }
        }

        if let Some(time) = &mut self.key_prev_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::TURN_LEFT);
            }
        }

        if let Some(time) = &mut self.key_next_down {
            if self.time - *time >= MOVE_REPEAT_DELAY + MOVE_REPEAT_COOLDOWN {
                *time += MOVE_REPEAT_COOLDOWN;
                input_actions.push(InputAction::TURN_RIGHT);
            }
        }

        if let Some(time) = &mut self.key_interact_down {
            if self.time - *time >= INTERACT_REPEAT_DELAY + INTERACT_REPEAT_COOLDOWN {
                *time += INTERACT_REPEAT_COOLDOWN;
                input_actions.push(InputAction::INTERACT);
            }
        }

        if let Some(time) = &mut self.key_switch_character_down {
            if self.time - *time >= SWITCH_CHARACTER_REPEAT_DELAY + SWITCH_CHARACTER_REPEAT_COOLDOWN
            {
                *time += SWITCH_CHARACTER_REPEAT_COOLDOWN;
                input_actions.push(InputAction::SWITCH_CHARACTER);
            }
        }

        if let Some(time) = &mut self.key_rewind_down {
            if self.time - *time >= REWIND_REPEAT_DELAY + REWIND_REPEAT_COOLDOWN {
                *time += REWIND_REPEAT_COOLDOWN;
                input_actions.push(InputAction::Rewind);
            }
        }

        {
            self.ui
                .set_window_size(logical_window_size.x, logical_window_size.y);
            self.ui.set_window_scale_factor(input.window_scale_factor);
            self.ui
                .set_cursor_position(logical_cursor_position.x, logical_cursor_position.y);

            for &c in &input.chars {
                self.ui.send_character(c);
            }

            self.ui
                .scroll(logical_scroll_delta.x, logical_scroll_delta.y);

            for &(key, state) in &input.keys {
                use guise::Inputs;

                let p = state == KeyState::Press;
                match key {
                    Key::Tab if p => self.ui.press_inputs(Inputs::KB_TAB),
                    Key::Tab if !p => self.ui.release_inputs(Inputs::KB_TAB),
                    Key::Left if p => self.ui.press_inputs(Inputs::KB_LEFT_ARROW),
                    Key::Left if !p => self.ui.release_inputs(Inputs::KB_LEFT_ARROW),
                    Key::Right if p => self.ui.press_inputs(Inputs::KB_RIGHT_ARROW),
                    Key::Right if !p => self.ui.release_inputs(Inputs::KB_RIGHT_ARROW),
                    Key::Up if p => self.ui.press_inputs(Inputs::KB_UP_ARROW),
                    Key::Up if !p => self.ui.release_inputs(Inputs::KB_UP_ARROW),
                    Key::Down if p => self.ui.press_inputs(Inputs::KB_DOWN_ARROW),
                    Key::Down if !p => self.ui.release_inputs(Inputs::KB_DOWN_ARROW),
                    Key::Home if p => self.ui.press_inputs(Inputs::KB_HOME),
                    Key::Home if !p => self.ui.release_inputs(Inputs::KB_HOME),
                    Key::End if p => self.ui.press_inputs(Inputs::KB_END),
                    Key::End if !p => self.ui.release_inputs(Inputs::KB_END),
                    Key::Insert if p => self.ui.press_inputs(Inputs::KB_INSERT),
                    Key::Insert if !p => self.ui.release_inputs(Inputs::KB_INSERT),
                    Key::Delete if p => self.ui.press_inputs(Inputs::KB_DELETE),
                    Key::Delete if !p => self.ui.release_inputs(Inputs::KB_DELETE),
                    Key::Backspace if p => self.ui.press_inputs(Inputs::KB_BACKSPACE),
                    Key::Backspace if !p => self.ui.release_inputs(Inputs::KB_BACKSPACE),
                    Key::Return if p => self.ui.press_inputs(Inputs::KB_ENTER),
                    Key::Return if !p => self.ui.release_inputs(Inputs::KB_ENTER),
                    Key::Esc if p => self.ui.press_inputs(Inputs::KB_ESCAPE),
                    Key::Esc if !p => self.ui.release_inputs(Inputs::KB_ESCAPE),
                    _ => (),
                }
            }

            for &(mb, state) in &input.mbs {
                use guise::Inputs;

                let p = state == KeyState::Press;
                match mb {
                    Mb::Left if p => self.ui.press_inputs(Inputs::MB_LEFT),
                    Mb::Left if !p => self.ui.release_inputs(Inputs::MB_LEFT),
                    Mb::Right if p => self.ui.press_inputs(Inputs::MB_RIGHT),
                    Mb::Right if !p => self.ui.release_inputs(Inputs::MB_RIGHT),
                    Mb::Middle if p => self.ui.press_inputs(Inputs::MB_MIDDLE),
                    Mb::Middle if !p => self.ui.release_inputs(Inputs::MB_MIDDLE),
                    _ => (),
                }
            }
        }

        if self.key_tab_down {
            let camera_direction = self.camera.direction();
            let mut move_direction = Vec3::ZERO;

            if self.key_up_down.is_some() {
                move_direction += camera_direction;
            }
            if self.key_down_down.is_some() {
                move_direction -= camera_direction;
            }
            if self.key_left_down.is_some() {
                move_direction -= camera_direction.cross(Vec3::Z).normalize();
            }
            if self.key_right_down.is_some() {
                move_direction += camera_direction.cross(Vec3::Z).normalize();
            }
            if self.key_prev_down.is_some() {
                move_direction -= camera_direction
                    .cross(Vec3::Z)
                    .normalize()
                    .cross(camera_direction);
            }
            if self.key_next_down.is_some() {
                move_direction += camera_direction
                    .cross(Vec3::Z)
                    .normalize()
                    .cross(camera_direction);
            }

            if move_direction != Vec3::ZERO {
                let v = if self.key_shift_down {
                    CAMERA_SPEED_FAST
                } else {
                    CAMERA_SPEED
                };
                let dposition = move_direction.normalize() * v * self.dtime.as_secs_f32();
                self.camera.change_position(dposition);
            }

            const MOUSE_SENSITIVITY: f32 = 0.002;
            let x = -MOUSE_SENSITIVITY * input.mouse_motion.x;
            let y = MOUSE_SENSITIVITY * input.mouse_motion.y;
            self.camera.change_orientation(x, y);
        }

        let frame = &mut self.ui.begin_frame();
        {
            let mut s: ArrayString<256> = ArrayString::new();

            if self.dev_show_fps {
                guise::Window::new(line!(), "1%", "1%", 250.0, 35.0)
                    .set_movable(false)
                    .set_resizable(false)
                    .begin(frame);
                guise::text(
                    frame,
                    line!(),
                    fmt!(s, "Frame Time: {}", self.dtime.as_secs_f32()),
                );
                guise::end_window(frame);
            }

            if self.current_level_failed {
                guise::Window::new(line!(), "30%", "30%", "48%", 100.0)
                    .set_movable(false)
                    .set_resizable(false)
                    .begin(frame);

                static TEXT_THEME: &guise::Theme = &guise::Theme {
                    text_margin: 20.0,
                    ..guise::Theme::DEFAULT
                };

                guise::Text::new(line!(), "You died. Z to undo.")
                    .set_horizontal_align(guise::Align::Center)
                    .set_theme(TEXT_THEME)
                    .show(frame);

                guise::end_window(frame);
            }
        }
        self.ui.end_frame();

        if dev_load_prev_level || dev_load_next_level {
            if let CurrentLevel::Levelset {
                levelset_id,
                ref mut level_id,
            } = self.current_level
            {
                if let Some(levelset_entries) = asset_catalog.levelset_catalog.get(levelset_id) {
                    let levelset_len = levelset_entries.len();

                    if levelset_len == 0 {
                        log::warn!("Can't switch to next level, there are none!");
                    } else {
                        let mut idx = levelset_entries
                            .iter()
                            .position(|e| e.level_id == *level_id)
                            .unwrap();

                        if dev_load_prev_level {
                            wrapping_dec(&mut idx, levelset_len);
                        } else if dev_load_next_level {
                            wrapping_inc(&mut idx, levelset_len);
                        }

                        *level_id = levelset_entries[idx].level_id;
                        self.reload_level = true;
                    }
                } else {
                    log::error!("Could not find levelset {levelset_id}");
                }
            }
        }

        if self.reload_level {
            unsafe { Arena::reset(&mut self.level, default_level) };

            if self.current_level == CurrentLevel::None {
                // We should only get here if we run the game for the first time.
                log::info!(
                    "Level reload requested without setting level or levelset, loading default"
                );
                let levelset_id = asset_catalog.world.default_levelset_id;
                let levelset_entries = &asset_catalog.levelset_catalog[levelset_id];
                if let Some(levelset_entry) = levelset_entries.first() {
                    self.current_level = CurrentLevel::Levelset {
                        levelset_id,
                        level_id: levelset_entry.level_id,
                    };
                } else {
                    log::error!(
                        "Levelset {levelset_id} is empty, can not switch to its first level"
                    );
                }
            }

            let (level_id, levelset_id) = match self.current_level {
                CurrentLevel::None => unreachable!(),
                CurrentLevel::Standalone { level_id } => (level_id, asset::ID_IMPLICIT_LEVELSET),
                CurrentLevel::Levelset {
                    level_id,
                    levelset_id,
                } => (level_id, levelset_id),
            };

            if let Some(levelset_entry) = &asset_catalog.levelset_catalog[levelset_id]
                .iter()
                .find(|e| e.level_id == level_id)
            {
                // TODO(yan): In non-developer builds, loading should not drop
                // frame-rate. Do we want to thread this, or preload it somehow?

                let level_name = levelset_entry.level_name;

                log::info!("Loading level {level_name}");

                let mut level_path: ArrayString<256> = ArrayString::from("./data/levels/").unwrap();
                level_path.push_str(&level_name);
                level_path.push_str(".ph_level");

                let level_bytes = platform
                    .read_file(temp_allocator, &level_path)
                    .unwrap_or_else(|_| Vec::new_in(temp_allocator));
                let level_str = str::from_utf8(&level_bytes).unwrap_or("");

                let (level, level_allocator) = self.level.get_mut_with_allocator();
                match asset_catalog::deserialize_and_migrate_level(temp_allocator, level_str) {
                    Ok(level_asset) => {
                        let mut wizard_id: Option<Id> = None;
                        let mut exit_id: Option<Id> = None;
                        let mut entities: IdMap<Entity, &'static Linear> =
                            IdMap::with_capacity_in(level_asset.entities.len(), level_allocator);
                        let mut entities_init: Vec<EntityInit, &'static Linear> =
                            Vec::with_capacity_in(level_asset.entities.len(), level_allocator);

                        for entity_init_ser in &level_asset.entities {
                            let entity_init =
                                asset_catalog::revive_entity_init(entity_init_ser, asset_catalog);
                            let id = gameplay::create_entity(
                                &mut entities,
                                &entity_init,
                                Animation {
                                    texture_id: asset::ID_MISSING_TEX,
                                    frame: IRect::ONE,
                                },
                            );

                            entities_init.push(entity_init);

                            if entity_init.ty == EntityType::Wizard {
                                wizard_id = Some(id);
                            }
                            if entity_init.ty == EntityType::Exit {
                                exit_id = Some(id);
                            }
                        }

                        let (level_min, level_max) = gameplay::build_level_bounds(&entities);
                        setup_camera_for_level(&mut self.camera, level_min, level_max);

                        level.wizard_id = wizard_id;
                        level.history =
                            History::with_capacity_in(HISTORY_CAPACITY, level_allocator);
                        level.entities = entities;
                        level.entities_init = entities_init;

                        if wizard_id.is_none() {
                            log::warn!("Loaded level does not contain a wizard");
                        }

                        if exit_id.is_none() {
                            log::warn!("Loaded level does not contain an exit");
                        }

                        log::debug!(
                            "Initial memory use for level {level_name}: {}/{}",
                            level_allocator.used_capacity(),
                            level_allocator.capacity(),
                        );

                        self.current_level_failed = false;
                        self.reload_level = false;

                        let transition = gameplay::simulate(
                            temp_allocator,
                            Action::Wait,
                            level,
                            // We are telling gameplay not to record undo,
                            // because the the initial simulation should not be
                            // rewindable.
                            false,
                        );

                        // TODO(yan): @Correctness Process transition as usual.
                        if transition != LevelStateTransition::None {
                            log::error!("Initial game round produced a level transition");
                        }
                    }
                    Err(err) => {
                        log::error!("Failed to deserialize level {level_name}: {err}");

                        // The level failed to load, but leave it up to the
                        // developer to try and load a different level.
                        self.reload_level = false;
                    }
                }
            } else {
                log::error!("Did not find level {level_id} in asset manifest");

                // The level failed to load, but leave it up to the
                // developer to try and load a different level.
                self.reload_level = false;
            }
        }

        if let Some(wizard_id) = self.level.wizard_id {
            if !self.current_level_failed && !self.key_tab_down {
                //
                // Immediate Level UI
                //

                // TODO(yan): @Bug This crashed during the playtest (called
                // unwrap on a None value). Looks hard to repro.
                let wizard = &self.level.entities[wizard_id];
                let wizard_data = wizard.data.unwrap_wizard();

                let icon_missing = asset_catalog.texture_catalog[&asset::ID_MISSING_TEX];
                let icon_frame = asset_catalog
                    .texture_catalog
                    .get(&ASSET_ICON_FRAME)
                    .copied()
                    .unwrap_or(icon_missing);

                // TODO(yan): @Cleanup Do we want to size the UI rects below
                // with the sizes of textures in the asset system? Probably not,
                // but the UI is very much in flux at the moment.

                for (i, slot) in wizard_data.inventory.iter().enumerate() {
                    let icon_rect = Rect::new(
                        0.0,
                        0.0,
                        f32::from(icon_frame.width),
                        f32::from(icon_frame.height),
                    );
                    let ui_icon_offset = vec2(
                        10.0 + i as f32 * (icon_rect.width + 4.0),
                        logical_window_size.y as f32 - 10.0 - icon_rect.height,
                    );
                    let ui_icon_rect = icon_rect + ui_icon_offset;

                    self.frame_data.ui_draw_list.draw_rect(
                        ui_icon_rect.scale(input.window_scale_factor),
                        icon_rect,
                        0xffffffff,
                        ASSET_ICON_FRAME.into_raw(),
                    );
                    if let Some(item) = slot {
                        match item {
                            // TODO(yan): Use actual key icon.
                            Item::Key => {
                                self.frame_data.ui_draw_list.draw_rect(
                                    ui_icon_rect.scale(input.window_scale_factor),
                                    icon_rect,
                                    0xffffffff,
                                    ASSET_ICON_KEY.into_raw(),
                                );
                            }
                        }
                    }
                }
            }

            for (_, entity) in &mut self.level.entities {
                if let Some(interpolation) = &mut entity.position_interpolation {
                    interpolation.update(dtime_f32);
                    if interpolation.finished() {
                        entity.position_interpolation = None;
                    }
                }
            }

            if !self.key_tab_down {
                for input_action in input_actions {
                    match input_action {
                        InputAction::Action(action) => {
                            if !self.current_level_failed {
                                let transition = gameplay::simulate(
                                    temp_allocator,
                                    action,
                                    self.level.get_mut(),
                                    true,
                                );

                                match transition {
                                    LevelStateTransition::None => (),
                                    LevelStateTransition::Failure => {
                                        self.current_level_failed = true;
                                    }
                                    LevelStateTransition::Success => {
                                        match self.current_level {
                                            CurrentLevel::None => {
                                                log::warn!(
                                                    "Finished a level, but no level was set."
                                                );
                                            }
                                            CurrentLevel::Standalone { .. } => {
                                                // We entered this level from
                                                // editor, and there is nowhere
                                                // to go after, so we just
                                                // reload the same level again.
                                                //
                                                // TODO(yan): Do we want to load
                                                // something else, e.g. detect
                                                // if the level is part of a
                                                // levelset and continue there,
                                                // or go to the
                                                // default_levelset?
                                            }
                                            CurrentLevel::Levelset {
                                                levelset_id,
                                                ref mut level_id,
                                            } => {
                                                if let Some(levelset_entries) =
                                                    asset_catalog.levelset_catalog.get(levelset_id)
                                                {
                                                    let levelset_len = levelset_entries.len();
                                                    if levelset_len == 0 {
                                                        log::warn!(
                                                            "Can't switch to next level, there \
                                                             are none!"
                                                        );
                                                    } else {
                                                        let mut idx = levelset_entries
                                                            .iter()
                                                            .position(|e| e.level_id == *level_id)
                                                            .unwrap();
                                                        wrapping_inc(&mut idx, levelset_len);

                                                        *level_id = levelset_entries[idx].level_id;
                                                    }
                                                } else {
                                                    log::error!(
                                                        "Can't switch to next level, could not \
                                                         find current levelset {levelset_id}"
                                                    );
                                                }
                                            }
                                        }

                                        self.reload_level = true;
                                    }
                                }
                            }
                        }
                        InputAction::Rewind => {
                            if gameplay::rewind(temp_allocator, self.level.as_mut()) {
                                self.current_level_failed = false;
                            }
                        }
                        InputAction::Restart => {
                            // Restarting works by using by reenacting what
                            // happens when the level is first loaded. We use
                            // the already cached entity inits to populate a
                            // entities in the level, run the initial simulation
                            // without recording history to initialize game
                            // systems. This gives us the canonical initial
                            // state of the level.
                            //
                            // Because we want undo to work on restarts, we add
                            // a history transaction, diffing the newly
                            // constructed initial state and the current state
                            // of the level.

                            let level = self.level.as_mut();

                            let entities_prev = {
                                let mut entities_prev = IdMap::new_in(temp_allocator);
                                entities_prev.clone_from(&level.entities);
                                entities_prev
                            };

                            let mut wizard_id = None;

                            // IMPORTANT: This clears the idmap and resets
                            // generation back to INITIAL_GEN. This is because
                            // if we are resetting state back to the start, the
                            // IDs of entities should be the same! This is not
                            // just a question of generating small diffs, but
                            // those entities could have references we'd
                            // invalidate, if we assigned a different ID each
                            // time the level resets.
                            //
                            // IMPORTANT: To work with IdMap::insert_at_vacant
                            // used by undo, IdMap::clear and
                            // IdMap::clear_and_reset_gen do not shrink the
                            // underlying vec, but instead link the free slots
                            // in the freelist. For that not to break level
                            // reset, the freelist has to be generated such that
                            // calling IdMap::insert with a sequence of entities
                            // on a pristine IdMap should generate exactly the
                            // same IDs as calling it on an idmap that had
                            // IdMap::clear_and_reset_gen called on it.
                            level.entities.clear_and_reset_gen();

                            for entity_init in &level.entities_init {
                                let id = gameplay::create_entity(
                                    &mut level.entities,
                                    entity_init,
                                    Animation {
                                        texture_id: asset::ID_MISSING_TEX,
                                        frame: IRect::ONE,
                                    },
                                );

                                if entity_init.ty == EntityType::Wizard {
                                    wizard_id = Some(id);
                                }
                            }

                            level.wizard_id = wizard_id;

                            let transition = gameplay::simulate(
                                temp_allocator,
                                Action::Wait,
                                level,
                                // We are telling gameplay not to record undo,
                                // because the the initial simulation should not
                                // be rewindable.
                                false,
                            );

                            // TODO(yan): @Correctness Process transition as usual.
                            if transition != LevelStateTransition::None {
                                log::error!("Initial game round produced a level transition");
                            }

                            match level.history.push_transaction(
                                temp_allocator,
                                &level.entities,
                                &entities_prev,
                            ) {
                                Ok((pushed_count, forgot_count, hosed_count)) => {
                                    log::debug!(
                                        "History transaction pushed/forgot/hosed {}/{}/{} changes",
                                        pushed_count,
                                        forgot_count,
                                        hosed_count,
                                    );
                                }
                                Err(HistoryError::OutOfMemory { needed, have }) => {
                                    // TODO(yan): Make this error louder by showing it on screen.
                                    log::error!(
                                        "History too small for {} changes (have enough for {}), \
                                         clearing...",
                                        needed,
                                        have,
                                    );
                                }
                            }

                            self.current_level_failed = false;
                        }
                    }
                }
            }
        }

        transition
    }

    pub fn render<R>(
        &mut self,
        temp_allocator: &Linear,
        renderer: &mut R,
        input: &Input,
        asset_catalog: &AssetCatalog,
    ) where
        R: Renderer,
    {
        profile_scope!("Game::render");

        if let Some(mut frame) = renderer.begin_frame(
            [0.04, 0.04, 0.08, 1.0],
            1.0,
            self.camera.view_matrix(),
            self.camera.projection_matrix(),
            self.render_mode,
            0xffffffff,
        ) {
            // Rendering! We have sprites and volumes.
            //
            // - Sprites are just always oriented to the camera (or camera plane?),
            //
            // - Volumes are, well, volumetric. GROUND, WATER and EXIT are
            //   example of volumes. A basic volume can render a combination of
            //   its out-facing and in-facing faces. In addition, WATER and
            //   GROUND are merged, meaning they don't draw their edges if their
            //   neighbor is of the same type (or GROUND, in case of WATER).

            const FLAG_TOP: u8 = 0x01;
            const FLAG_BOTTOM: u8 = 0x02;
            const FLAG_FRONT: u8 = 0x04;
            const FLAG_BACK: u8 = 0x08;
            const FLAG_LEFT: u8 = 0x10;
            const FLAG_RIGHT: u8 = 0x20;

            // This assumes the level does not contain two mergeable volume
            // entities occupying the same space. If it does, the result will be
            // incorrect, because the volume grid is re-used for both Water and
            // Ground (potentially more later).
            let entity_grid = gameplay::build_entity_grid(temp_allocator, &self.level.entities);
            let mut volume_grid: Grid<u8, _> =
                Grid::with_aabb_in(entity_grid.min(), entity_grid.max(), temp_allocator);

            fn detect_water_edges(
                volume_grid: &mut Grid<u8, &Linear>,
                entity_grid: &Grid<ArrayVec<(Id, EntityType), 4>, &Linear>,
                position: IVec3,
            ) {
                for (direction, direction_flag) in [
                    (-IVec3::Z, FLAG_BOTTOM),
                    (IVec3::Z, FLAG_TOP),
                    (-IVec3::Y, FLAG_FRONT),
                    (IVec3::Y, FLAG_BACK),
                    (-IVec3::X, FLAG_LEFT),
                    (IVec3::X, FLAG_RIGHT),
                ] {
                    let neighbor_position = position + direction;

                    // Draw water edges at the edge of the map.
                    if !entity_grid.is_in_bounds(neighbor_position) {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }

                    let mut neighbor_contains_water_or_ground = false;
                    for &(_, entity_ty) in &entity_grid[neighbor_position] {
                        if entity_ty == EntityType::Water || entity_ty == EntityType::Ground {
                            neighbor_contains_water_or_ground = true;
                        }
                    }

                    // Draw water edges if the neighboring tile has no water nor ground.
                    if !neighbor_contains_water_or_ground {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }
                }
            }

            fn detect_ground_edges(
                volume_grid: &mut Grid<u8, &Linear>,
                entity_grid: &Grid<ArrayVec<(Id, EntityType), 4>, &Linear>,
                position: IVec3,
            ) {
                for (direction, direction_flag) in [
                    (-IVec3::Z, FLAG_BOTTOM),
                    (IVec3::Z, FLAG_TOP),
                    (-IVec3::Y, FLAG_FRONT),
                    (IVec3::Y, FLAG_BACK),
                    (-IVec3::X, FLAG_LEFT),
                    (IVec3::X, FLAG_RIGHT),
                ] {
                    let neighbor_position = position + direction;

                    // Draw water edges at the edge of the map.
                    if !entity_grid.is_in_bounds(neighbor_position) {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }

                    let mut neighbor_contains_ground = false;
                    for &(_, entity_ty) in &entity_grid[neighbor_position] {
                        if entity_ty == EntityType::Ground {
                            neighbor_contains_ground = true;
                        }
                    }

                    // Draw water edges if the neighboring tile has no ground.
                    if !neighbor_contains_ground {
                        volume_grid[position] |= direction_flag;
                        continue;
                    }
                }
            }

            for (_, entity) in &self.level.entities {
                match entity.ty {
                    EntityType::Water => {
                        detect_water_edges(&mut volume_grid, &entity_grid, entity.position);
                    }
                    EntityType::Ground => {
                        detect_ground_edges(&mut volume_grid, &entity_grid, entity.position);
                    }
                    _ => (),
                }
            }

            let mut entity_draw_voxel_primitives = Vec::new_in(temp_allocator);
            let mut entity_draw_commands_rect = Vec::new_in(temp_allocator);

            for (_, entity) in &self.level.entities {
                let entity_position = if let Some(interpolation) = entity.position_interpolation {
                    interpolation.value()
                } else {
                    entity.position.as_vec3()
                };

                if entity.volume_idle != asset::ID_MISSING_VOLUME {
                    let (header, data) = asset_catalog
                        .volume_catalog
                        .get(entity.volume_idle)
                        .unwrap();
                    for z in 0..header.size_z {
                        for y in 0..header.size_y {
                            for x in 0..header.size_x {
                                let color_base = match data {
                                    XRawDataRef::VoxelIndexed8PaletteRgbaU8(voxels, colors) => {
                                        let voxel_index = xraw::position_to_index(&header, x, y, z);
                                        let color_index = voxels[voxel_index];

                                        if color_index == xraw::XRAW_VOXEL_INDEX_EMPTY_8 {
                                            continue;
                                        }

                                        let color = colors[usize::from(color_index)];

                                        color
                                    }
                                    XRawDataRef::VoxelIndexed16PaletteRgbaU8(voxels, colors) => {
                                        let voxel_index = xraw::position_to_index(&header, x, y, z);
                                        let color_index = voxels[voxel_index];

                                        if color_index == xraw::XRAW_VOXEL_INDEX_EMPTY_16 {
                                            continue;
                                        }

                                        let color = colors[usize::from(color_index)];

                                        color
                                    }
                                };

                                // Color in XRAW is RGBA, but we can only
                                // smuggle it to the gpu as a u32, which is ABGR
                                // on LE platforms and RGBA on BE platforms. We
                                // could read it reveresed on the shader, but
                                // for consistency our shader colors are native
                                // endian u32s (ABGR on LE), so we flip (in
                                // Color::into_u32).
                                //
                                // TODO(yan): @Speed @AssetBuild do both the the
                                // byte swaps in the asset build, and possibly
                                // also the srgb conversion, if do not end up
                                // using a sRGB texture.
                                //
                                // TODO(yan): @Correctness By bringing the
                                // texture out of sRGB AND packing the float
                                // back to a byte we loose color precision in
                                // dark colors. Should we be sending the color
                                // to the GPU as vec4? Or should we be decoding
                                // sRGB on the GPU?
                                let color = Color::from_array_srgb(color_base.0).into_u32();

                                let scale = vec3(
                                    1.0 / header.size_x as f32,
                                    1.0 / header.size_y as f32,
                                    1.0 / header.size_z as f32,
                                );

                                let x = x as f32;
                                let y = y as f32;
                                let z = z as f32;

                                let offset = scale * (vec3(x, y, z) + 0.5) - 0.5;
                                let m = Mat4::from_scale_rotation_translation(
                                    scale,
                                    Quat::IDENTITY,
                                    entity_position + offset,
                                );

                                entity_draw_voxel_primitives.push(Draw3DVoxelPrimitive {
                                    transform_matrix: m,
                                    color,
                                    _pad0: 0,
                                    _pad1: 0,
                                    _pad2: 0,
                                });
                            }
                        }
                    }
                } else {
                    match entity.running_anims {
                        RunningAnimations::Prop(anim) => {
                            let rotation = -90.0_f32.to_radians() + camera::DEFAULT_INCLINATION_INV;
                            let m = Mat4::from_rotation_translation(
                                Quat::from_rotation_x(rotation),
                                entity_position,
                            );

                            entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                transform_matrix: m,
                                texture_rect: anim.frame.as_rect(),
                                texture_id: anim.texture_id.into_raw(),
                                color_mul: entity.color_mul,
                                color_add: 0,
                            });
                        }
                        RunningAnimations::Volume(anim) => {
                            let join_volume_edges =
                                entity.ty == EntityType::Water || entity.ty == EntityType::Ground;

                            let volume_flags = volume_grid[entity.position];

                            // TODO(yan): @Speed @Memory Do not depend GPU face
                            // culling for backward facing faces. We have all the
                            // information here, so just don't emit the draw
                            // command.

                            const INWARD: VolumeAnimationDirections =
                                VolumeAnimationDirections::INWARD;
                            const OUTWARD: VolumeAnimationDirections =
                                VolumeAnimationDirections::OUTWARD;

                            let top_offset_inv = 0.5 - anim.top_offset;
                            let sides_offset_inv = 0.5 - anim.sides_offset;
                            let bottom_offset_inv = 0.5 - anim.bottom_offset;

                            if !join_volume_edges || volume_flags & FLAG_TOP != 0 {
                                if let Some(top) = anim.top {
                                    if anim.top_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(-90.0_f32.to_radians()),
                                            entity_position + top_offset_inv * Vec3::Z,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: top.frame.as_rect(),
                                            texture_id: top.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }

                                    if anim.top_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(90.0_f32.to_radians()),
                                            entity_position + top_offset_inv * Vec3::Z,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: top.frame.as_rect(),
                                            texture_id: top.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_LEFT != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(-90.0_f32.to_radians()),
                                            entity_position - sides_offset_inv * Vec3::X,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(90.0_f32.to_radians()),
                                            entity_position - sides_offset_inv * Vec3::X,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_RIGHT != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(90.0_f32.to_radians()),
                                            entity_position + sides_offset_inv * Vec3::X,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(-90.0_f32.to_radians()),
                                            entity_position + sides_offset_inv * Vec3::X,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_FRONT != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_translation(
                                            entity_position - sides_offset_inv * Vec3::Y,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(180.0_f32.to_radians()),
                                            entity_position - sides_offset_inv * Vec3::Y,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_BACK != 0 {
                                if let Some(sides) = anim.sides {
                                    if anim.sides_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_z(180.0_f32.to_radians()),
                                            entity_position + sides_offset_inv * Vec3::Y,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }

                                    if anim.sides_directions.intersects(INWARD) {
                                        let m = Mat4::from_translation(
                                            entity_position + sides_offset_inv * Vec3::Y,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: sides.frame.as_rect(),
                                            texture_id: sides.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }
                                }
                            }

                            if !join_volume_edges || volume_flags & FLAG_BOTTOM != 0 {
                                if let Some(bottom) = anim.bottom {
                                    if anim.bottom_directions.intersects(OUTWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(90.0_f32.to_radians()),
                                            entity_position - bottom_offset_inv * Vec3::Z,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: bottom.frame.as_rect(),
                                            texture_id: bottom.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }

                                    if anim.bottom_directions.intersects(INWARD) {
                                        let m = Mat4::from_rotation_translation(
                                            Quat::from_rotation_x(-90.0_f32.to_radians()),
                                            entity_position - bottom_offset_inv * Vec3::Z,
                                        );

                                        entity_draw_commands_rect.push(Draw3DRectPrimitive {
                                            transform_matrix: m,
                                            texture_rect: bottom.frame.as_rect(),
                                            texture_id: bottom.texture_id.into_raw(),
                                            color_mul: entity.color_mul,
                                            color_add: 0,
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if self.current_level_failed {
                self.frame_data.ui_draw_list.draw_rect(
                    Rect::new(
                        0.0,
                        0.0,
                        input.physical_window_size.x as f32,
                        input.physical_window_size.y as f32,
                    ),
                    Rect::ZERO,
                    color_u32([30, 30, 30, 210]),
                    asset::ID_GAME_FONT_ATLAS_TEX.into_raw(),
                );
            }

            frame.draw_3d_rects_to_intermediate(&entity_draw_commands_rect);
            frame.draw_3d_voxels_to_intermediate(&entity_draw_voxel_primitives);
            frame.draw_2d_rects_to_intermediate(
                self.frame_data.ui_draw_list.commands(),
                self.frame_data.ui_draw_list.primitives(),
            );

            frame.blit_intermediate_to_surface();

            let (ui_commands, ui_vertices, ui_indices) = self.ui.draw_list();
            frame.draw_ui_to_surface(
                bytemuck::cast_slice(ui_commands),
                bytemuck::cast_slice(ui_vertices),
                ui_indices,
            );

            frame.submit_and_present();
        }
    }
}

fn setup_camera_for_level(camera: &mut Camera, min: IVec3, max: IVec3) {
    let level_diagonal = max.as_vec3() - min.as_vec3();
    let level_diagonal_length = level_diagonal.length();
    let look_at_point = min.as_vec3() + level_diagonal / 2.0;

    camera.set_azimuth(90.0_f32.to_radians());
    camera.set_inclination(camera::DEFAULT_INCLINATION);

    let position_target = look_at_point + 1.3 * level_diagonal_length * -camera.direction();
    let position = position_target + 0.3 * Vec3::Z;

    camera.set_position(position);
    camera.interpolate_position(
        position_target,
        1.2,
        CubicBezierCurve::new(vec2(0.17, 0.18), vec2(0.12, 1.37)),
    );
}

fn wrapping_inc(x: &mut usize, count: usize) {
    debug_assert!(count != 0);
    *x = x.wrapping_add(1) % count;
}

fn wrapping_dec(x: &mut usize, count: usize) {
    debug_assert!(count != 0);
    if *x == 0 {
        *x = count - 1;
    } else {
        *x -= 1;
    }
}

fn default_level(allocator: &'static Linear) -> Level {
    // TODO(yan): @Memory @Correctness Instead of sharing the same allocator and
    // suffering reallocations on failed grows, we should split the allocator
    // OR, preferably, have a collection that can gracefully handle growing with
    // bump-allocators, such as Slab from the_machinery, and base our own
    // collections (arrays, dictionaries, deques) on top of that and have
    // SlabArray (or just Slab), SlabTable, and SlabDeque.
    Level {
        wizard_id: None,
        // No need for setting capacities - these are never actually used and
        // are replaced by properly initialized versions when a level is loaded.
        history: History::new_in(allocator),
        entities: IdMap::new_in(allocator),
        entities_init: Vec::new_in(allocator),
    }
}

fn default_frame_data(allocator: &'static Linear) -> FrameData {
    FrameData {
        ui_draw_list: DrawList::with_capacity_in(2048, allocator),
    }
}
