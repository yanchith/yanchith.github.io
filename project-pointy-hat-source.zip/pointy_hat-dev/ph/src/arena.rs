use alloc::boxed::Box;
use core::convert::{AsMut, AsRef};
use core::mem::{self, ManuallyDrop};
use core::ops::{Deref, DerefMut};

use lfg_alloc::Linear;
use lfg_common::static_assert;

// TODO(yan): @Cleanup The way we usually use this is populate the T in the
// arena with a dummy data, and later swap that with the real thing. Consider
// not requiring the data to be always present. There would be no constructor
// fns, Arena::get_mut (and Arena::get_mut_with_allocator) would either return
// an option or panic if the data isn't there, and Arena wouldn't implement
// Deref/DerefMut/AsRef/AsMut.

/// Resettable Arena that provides a bump allocator to data it holds.
///
/// To make at least some part of the API safe, the arena leaks data when it
/// goes out of scope, if not explicitly dropped with
/// [`Arena::drop_and_reclaim`].
///
/// # Safety
///
/// Do not use the arena's allocator to allocate data living outside the
/// arena. This is fine by itself, but calling [`Arena::reset`] or
/// [`Arena::drop_and_reclaim`] invalidates all memory allocated with the
/// allocator.
pub struct Arena<T> {
    // SAFETY: Fields are ManuallyDrop for 2 reasons:
    //
    // 1) To control drop order: the data needs to be dropped before the
    //    allocator is reclaimed.
    //
    // 2) The allocator can leak to other places in the program once the arena
    //    has been created, so we can never safely drop it. It is safe, however,
    //    to leak it by default, and require the user to explicitly drop the
    //    arena.
    allocator: ManuallyDrop<Box<Linear, &'static Linear>>,
    allocator_footer: ManuallyDrop<Linear>,
    data: ManuallyDrop<T>,
}

impl<T> Arena<T> {
    pub fn new<C>(mut allocator: Linear, constructor: C) -> Self
    where
        C: Fn(&'static Linear) -> T,
    {
        // SAFETY: We need to ensure references to the allocator remain valid,
        // so we only allow taking references to allocator once it gets a stable
        // address and never move it out from there.
        //
        // Furthermore, we move it into memory it itself manages, concretely a
        // split small footer region.

        // NB: Size footer such that the split chunk of memory has size that is
        // multiple of 16.
        const FOOTER_SIZE: usize = 32;
        static_assert!(mem::size_of::<Linear>() <= FOOTER_SIZE);

        let allocator_footer = allocator.split(FOOTER_SIZE).unwrap();
        // SAFETY: Upgrading to static lifetime is safe, because we will never
        // use the footer again after this point unless reclaiming the entire
        // allocator, and the reclamation is marked unsafe.
        let allocator_footer_ref: &'static Linear = unsafe { static_lifetime(&allocator_footer) };
        let allocator = Box::new_in(allocator, allocator_footer_ref);
        // SAFETY: It is ok to pretend the allocator lives forever, because it
        // is unsafe to reclaim it.
        let data = constructor(unsafe { static_lifetime(&allocator) });

        Self {
            allocator: ManuallyDrop::new(allocator),
            allocator_footer: ManuallyDrop::new(allocator_footer),
            data: ManuallyDrop::new(data),
        }
    }

    /// Gets mutable access to the data stored inside the arena.
    ///
    /// The need for this should be rare, because the arena also implements
    /// [`Deref`] and [`DerefMut`] for easy field access. However, we sometimes
    /// need to get a mutable pointer to the entirety of the data inside,
    /// because we want to to manually sub-borrow it ([`Deref`] and [`DerefMut`]
    /// borrow the entire arena). We could use `&*` or `&mut *`, but this is a
    /// bit more clear.
    #[allow(dead_code)]
    pub fn get_mut(&mut self) -> &mut T {
        &mut self.data
    }

    /// Gets mutable access to the data stored inside the arena, as well as
    /// seemingly `'static` reference to the underlying allocator.
    ///
    /// The need for this should be rare, but sometimes we need to initialize
    /// more data that can reference the allocator after the arena has been set
    /// up.
    ///
    /// Using the allocator to allocate any data not managed by this arena is
    /// not recommended, because it puts you in danger of violating the safety
    /// contract for [`Self::reset`] and [`Self::drop_and_reclaim`].
    pub fn get_mut_with_allocator(&mut self) -> (&mut T, &'static Linear) {
        // SAFETY: It is ok to pretend the allocator lives forever, because it
        // is unsafe to reclaim it.
        (&mut self.data, unsafe { static_lifetime(&self.allocator) })
    }

    /// Gets the seemingly `'static` reference to the underlying allocator.
    ///
    /// Using the allocator to allocate any data not managed by this arena is
    /// not recommended, because it puts you in danger of violating the safety
    /// contract for [`Self::reset`] and [`Self::drop_and_reclaim`].
    #[allow(dead_code)]
    pub fn allocator(&self) -> &'static Linear {
        unsafe { static_lifetime(&self.allocator) }
    }

    /// Resets the arena.
    ///
    /// This makes any data living inside unavailable, and uses
    /// [`DefaulInArena`] to initialize new data, so that there's something to
    /// access.
    ///
    /// # Safety
    ///
    /// This is unsafe, because the allocator could have leaked and we can
    /// invalidate memory elsewhere in the program.
    pub unsafe fn reset<C>(arena: &mut Self, constructor: C)
    where
        C: Fn(&'static Linear) -> T,
    {
        // SAFETY: The order here is important - we must first drop the data
        // backed by the allocator, then reset the allocator, and finally create
        // new data.
        ManuallyDrop::drop(&mut arena.data);
        arena.allocator.reset();

        // SAFETY: It is ok to pretend the allocator lives forever, because it
        // is unsafe to reclaim it.
        arena.data = ManuallyDrop::new(constructor(static_lifetime(&arena.allocator)));
    }

    /// Explicitly cleans up data owned by the arena and returns back the
    /// allocator.
    ///
    /// # Safety
    ///
    /// This is unsafe, because the allocator could have leaked, and using the
    /// reclaimed allocator can invalidate memory elsewhere in the program.
    #[allow(dead_code)]
    pub unsafe fn drop_and_reclaim(mut arena: Self) -> Linear {
        // SAFETY: Drop order is important - first drop data, and only then
        // reclaim allocator.
        ManuallyDrop::drop(&mut arena.data);

        let mut allocator = Box::into_inner(ManuallyDrop::into_inner(arena.allocator));
        let allocator_footer = ManuallyDrop::into_inner(arena.allocator_footer);

        allocator.join(allocator_footer).unwrap();

        allocator
    }
}

impl<T> AsRef<T> for Arena<T> {
    fn as_ref(&self) -> &T {
        &self.data
    }
}

impl<T> AsMut<T> for Arena<T> {
    fn as_mut(&mut self) -> &mut T {
        &mut self.data
    }
}

impl<T> Deref for Arena<T> {
    type Target = T;

    fn deref(&self) -> &Self::Target {
        &self.data
    }
}

impl<T> DerefMut for Arena<T> {
    fn deref_mut(&mut self) -> &mut Self::Target {
        &mut self.data
    }
}

// NB: Transmute transmutes anything to anything, which easily produces hard to
// track down bugs. This restricts the types so that we know we are only
// extending the lifetime.
unsafe fn static_lifetime<'a>(allocator: &'a Linear) -> &'static Linear {
    mem::transmute(allocator)
}
