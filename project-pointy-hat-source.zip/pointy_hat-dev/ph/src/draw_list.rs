use alloc::vec::Vec;

use lfg_alloc::Linear;
use lfg_math::Rect;
use ph_renderer::{Draw2DRectCommand, Draw2DRectPrimitive};

#[derive(Debug)]
pub struct DrawList {
    commands: Vec<Draw2DRectCommand, &'static Linear>,
    primitives: Vec<Draw2DRectPrimitive, &'static Linear>,
}

impl DrawList {
    pub fn with_capacity_in(capacity: usize, allocator: &'static Linear) -> Self {
        Self {
            commands: Vec::with_capacity_in(capacity, allocator),
            primitives: Vec::with_capacity_in(capacity, allocator),
        }
    }

    pub fn commands(&self) -> &[Draw2DRectCommand] {
        &self.commands
    }

    pub fn primitives(&self) -> &[Draw2DRectPrimitive] {
        &self.primitives
    }

    pub fn draw_rect(&mut self, rect: Rect, texture_rect: Rect, color: u32, texture_id: u64) {
        self.primitives.push(Draw2DRectPrimitive {
            rect,
            texture_rect,
            color,
        });

        if let Some(command) = self.commands.last_mut() {
            if command.texture_id == texture_id {
                command.primitive_count += 1;
            } else {
                self.commands.push(Draw2DRectCommand {
                    primitive_count: 1,
                    texture_id,
                })
            }
        } else {
            self.commands.push(Draw2DRectCommand {
                primitive_count: 1,
                texture_id,
            })
        }
    }
}
