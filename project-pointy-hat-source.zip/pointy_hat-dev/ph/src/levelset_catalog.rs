use alloc::vec::Vec;
use core::ops::Index;

use hashbrown::hash_map::{DefaultHashBuilder, HashMap};
use lfg_alloc::Linear;

use crate::asset::{AssetId, AssetName};

// TODO(yan): Make it possible to chain level sets or go from levelset to a
// particular level, like the overworld. Likely we should make the levelset
// format in with cereal.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct LevelsetEntry {
    pub level_id: AssetId,
    pub level_name: AssetName,
}

#[derive(Debug)]
pub struct LevelsetCatalog {
    catalog: HashMap<AssetId, (usize, usize), DefaultHashBuilder, &'static Linear>,
    data: Vec<LevelsetEntry, &'static Linear>,
}

impl LevelsetCatalog {
    pub fn with_capacity_in(capacity: usize, allocator: &'static Linear) -> Self {
        Self {
            catalog: HashMap::with_capacity_in(capacity, allocator),
            data: Vec::with_capacity_in(capacity * 1024, allocator),
        }
    }

    pub fn insert(&mut self, levelset_id: AssetId, entries: &[LevelsetEntry]) {
        let index_start = self.data.len();
        let index_end = index_start + entries.len();

        self.data.extend(entries);
        self.catalog.insert(levelset_id, (index_start, index_end));
    }

    pub fn get(&self, levelset_id: AssetId) -> Option<&[LevelsetEntry]> {
        self.catalog
            .get(&levelset_id)
            .map(|&(index_start, index_end)| &self.data[index_start..index_end])
    }

    pub fn iter(&self) -> Iter<'_> {
        Iter {
            inner: self.catalog.iter(),
            data: &self.data,
        }
    }
}

pub struct Iter<'a> {
    inner: hashbrown::hash_map::Iter<'a, AssetId, (usize, usize)>,
    data: &'a [LevelsetEntry],
}

impl<'a> Iterator for Iter<'a> {
    type Item = (AssetId, &'a [LevelsetEntry]);

    fn next(&mut self) -> Option<Self::Item> {
        match self.inner.next() {
            Some((&levelset_id, &(index_start, index_end))) => {
                Some((levelset_id, &self.data[index_start..index_end]))
            }
            None => None,
        }
    }
}

impl<'a> IntoIterator for &'a LevelsetCatalog {
    type Item = (AssetId, &'a [LevelsetEntry]);
    type IntoIter = Iter<'a>;
    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}

impl Index<AssetId> for LevelsetCatalog {
    type Output = [LevelsetEntry];

    fn index(&self, index: AssetId) -> &Self::Output {
        self.get(index).unwrap()
    }
}
