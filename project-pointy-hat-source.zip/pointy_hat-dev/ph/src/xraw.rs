use alloc::collections::VecDeque;
use alloc::vec::Vec;
use core::alloc::Allocator;
use core::mem;
use core::ops::{BitAnd, BitAndAssign, BitOr, BitOrAssign};

use lfg_common::{cast_u32, cast_usize};

/*

XRAW format taken from https://twitter.com/ephtracy/status/653721698328551424

Note that we do not know if the format is little-endian or native-endian, but
assume native, because that's how these people think (and maybe I should too).

----------------------------------------------------------------
# bytes | Content                  | Value      | Description
----------------------------------------------------------------
4       | magic number             | "XRAW"     : X is stored first

1       | color channel data type  | 0          : unsigned integer <--
                                   | 1          : signed integer
                                   | 2          : float

1       | num of color channels    | 4          : RGBA, R is stored first <--
                                   | 3          : RGB
                                   | 2          : RG
                                   | 1          : R

1       | bits per channel         | 8          <--
                                   | 16
                                   | 32

1       | bits per index           | 8          : 256 colors    :  0 for empty voxel <--
                                   | 16         : 32768 colors  : ~0 for empty voxel <--

4       | width  x                 | address = x + y * width + z * (width * height)
4       | height y
4       | depth  z

4       | num of palette colors    | 256, 32768

----------------------------------------------------------------
-       | end of header
----------------------------------------------------------------

#V      | voxel buffer             | voxels     : if no palette
                                   | indices    : else

#P      | palette buffer

----------------------------------------------------------------
-       | end of file
----------------------------------------------------------------

 */

// We are using constants instead of enums (not even repr(C)) on purpose. It is
// UB in Rust to produce an enum with an illegal value, and we'll be casting
// into these. This also allows us to derive bytemuck::Zeroable and
// bytemuck::Pod for the header.

pub const XRAW_MAGIC_NUMBER: u32 = u32::from_le_bytes([b'X', b'R', b'A', b'W']);

pub const XRAW_COLOR_TYPE_UINT: u8 = 0;
pub const XRAW_COLOR_TYPE_SINT: u8 = 1;
pub const XRAW_COLOR_TYPE_FLOAT: u8 = 2;

pub const XRAW_COLOR_CHANNEL_COUNT_R: u8 = 1;
pub const XRAW_COLOR_CHANNEL_COUNT_RG: u8 = 2;
pub const XRAW_COLOR_CHANNEL_COUNT_RGB: u8 = 3;
pub const XRAW_COLOR_CHANNEL_COUNT_RGBA: u8 = 4;

pub const XRAW_COLOR_BITS_8: u8 = 8;
pub const XRAW_COLOR_BITS_16: u8 = 16;
pub const XRAW_COLOR_BITS_32: u8 = 32;

pub const XRAW_INDEX_BITS_DISABLED: u8 = 0;
pub const XRAW_INDEX_BITS_8: u8 = 8;
pub const XRAW_INDEX_BITS_16: u8 = 16;

pub const XRAW_PALETTE_COLOR_8: u32 = 1 << 8; // 256 from spec above
pub const XRAW_PALETTE_COLOR_15: u32 = 1 << 15; // 32768 from spec above

pub const XRAW_HEADER_SIZE: usize = mem::size_of::<XRawHeader>();
pub const XRAW_HEADER_ALIGN: usize = mem::align_of::<XRawHeader>();

pub const XRAW_VOXEL_INDEX_EMPTY_8: u8 = 0;
pub const XRAW_VOXEL_INDEX_EMPTY_16: u16 = !0; // See spec

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct XRawHeader {
    pub magic: u32,
    pub color_type: u8,
    pub color_channel_count: u8,
    pub color_bits: u8,
    pub index_bits: u8,

    pub size_x: u32,
    pub size_y: u32,
    pub size_z: u32,

    pub palette_size: u32,
}

// Note: The header is 24 bytes, meaning the voxel data is going to be have
// alignment of 4, if the entire structure is aligned.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum XRawDataRef<'a> {
    VoxelIndexed8PaletteRgbaU8(&'a [u8], &'a [RgbaU8]),
    VoxelIndexed16PaletteRgbaU8(&'a [u16], &'a [RgbaU8]),
}

#[derive(Debug, PartialEq, Eq, Hash)]
pub enum XRawDataMut<'a> {
    VoxelIndexed8PaletteRgbaU8(&'a mut [u8], &'a mut [RgbaU8]),
    VoxelIndexed16PaletteRgbaU8(&'a mut [u16], &'a mut [RgbaU8]),
}

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct RU8(pub [u8; 1]);

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct RgU8(pub [u8; 2]);

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct RgbU8(pub [u8; 3]);

#[repr(C)]
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[derive(bytemuck::Zeroable, bytemuck::Pod)]
pub struct RgbaU8(pub [u8; 4]);

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct XRawTrimDirections(u8);

impl XRawTrimDirections {
    pub const TOP: Self = Self(0x01);
    pub const BOTTOM: Self = Self(0x02);
    pub const LEFT: Self = Self(0x04);
    pub const RIGHT: Self = Self(0x08);
    pub const FRONT: Self = Self(0x10);
    pub const BACK: Self = Self(0x20);

    #[allow(dead_code)]
    pub const NONE: Self = Self(0);
    pub const ALL: Self =
        Self::TOP | Self::BOTTOM | Self::LEFT | Self::RIGHT | Self::FRONT | Self::BACK;

    #[allow(dead_code)]
    pub fn from_bits_truncate(bits: u8) -> Self {
        Self(Self::ALL.0 & bits)
    }

    #[allow(dead_code)]
    pub fn bits(&self) -> u8 {
        self.0
    }

    pub fn intersects(&self, other: Self) -> bool {
        self.0 & other.0 != 0
    }
}

impl const BitOr for XRawTrimDirections {
    type Output = Self;

    fn bitor(self, other: Self) -> Self {
        Self(self.0 | other.0)
    }
}

impl const BitOrAssign for XRawTrimDirections {
    fn bitor_assign(&mut self, other: Self) {
        self.0 |= other.0;
    }
}

impl const BitAnd for XRawTrimDirections {
    type Output = Self;

    fn bitand(self, other: Self) -> Self {
        Self(self.0 & other.0)
    }
}

impl const BitAndAssign for XRawTrimDirections {
    fn bitand_assign(&mut self, other: Self) {
        self.0 &= other.0;
    }
}

#[derive(Debug)]
pub enum XRawError {
    InvalidMagicNumber,
    InvalidColorChannelType,
    InvalidColorChannelCount,
    InvalidColorChannelBits,
    InvalidIndexBits,
    InvalidSize,
    InvalidPaletteSize,
    UnsupportedColorChannelType,
    UnsupportedColorChannelBits,
    UnsupportedIndexBits,
    UnsupportedSize { max: u32, got: u32 },
    NotEnoughHeaderBytes { expected: u32, got: u32 },
    NotEnoughDataBytes { expected: u32, got: u32 },
}

pub fn from_bytes(bytes: &[u8]) -> Result<(&XRawHeader, XRawDataRef<'_>), XRawError> {
    let header = header_from_bytes(bytes)?;
    let data = data_from_bytes_header(&bytes[XRAW_HEADER_SIZE..], header)?;

    Ok((header, data))
}

pub fn header_from_bytes(bytes: &[u8]) -> Result<&XRawHeader, XRawError> {
    // Because we are going to cast the bytes into the XRAW header (and later
    // also data) directly, we need to verify their alignment is correct.
    //
    // TODO(yan): Do we want to make this an error instead of an assertion?
    assert!(bytes.as_ptr() as usize % XRAW_HEADER_ALIGN == 0);

    if bytes.len() < XRAW_HEADER_SIZE {
        return Err(XRawError::NotEnoughHeaderBytes {
            expected: cast_u32!(XRAW_HEADER_SIZE),
            got: cast_u32!(bytes.len()),
        });
    }

    let header_bytes = &bytes[0..XRAW_HEADER_SIZE];
    let header: &XRawHeader = bytemuck::from_bytes(header_bytes);

    if header.magic != XRAW_MAGIC_NUMBER {
        return Err(XRawError::InvalidMagicNumber);
    }

    if ![
        XRAW_COLOR_TYPE_UINT,
        XRAW_COLOR_TYPE_SINT,
        XRAW_COLOR_TYPE_FLOAT,
    ]
    .contains(&header.color_type)
    {
        return Err(XRawError::InvalidColorChannelType);
    }

    if ![
        XRAW_COLOR_CHANNEL_COUNT_R,
        XRAW_COLOR_CHANNEL_COUNT_RG,
        XRAW_COLOR_CHANNEL_COUNT_RGB,
        XRAW_COLOR_CHANNEL_COUNT_RGBA,
    ]
    .contains(&header.color_channel_count)
    {
        return Err(XRawError::InvalidColorChannelCount);
    }

    if ![XRAW_COLOR_BITS_8, XRAW_COLOR_BITS_16, XRAW_COLOR_BITS_32].contains(&header.color_bits) {
        return Err(XRawError::InvalidColorChannelBits);
    }

    if ![
        XRAW_INDEX_BITS_DISABLED,
        XRAW_INDEX_BITS_8,
        XRAW_INDEX_BITS_16,
    ]
    .contains(&header.index_bits)
    {
        return Err(XRawError::InvalidIndexBits);
    }

    if header.size_x == 0 || header.size_y == 0 || header.size_z == 0 {
        return Err(XRawError::InvalidSize);
    }

    if ![XRAW_PALETTE_COLOR_8, XRAW_PALETTE_COLOR_15].contains(&header.palette_size) {
        return Err(XRawError::InvalidPaletteSize);
    }

    if header.color_type != XRAW_COLOR_TYPE_UINT {
        return Err(XRawError::UnsupportedColorChannelType);
    }

    // We likely won't lift this restriction, because casting into colors with
    // greater alignment requirement would require us to copy the data.
    if header.color_bits != XRAW_COLOR_BITS_8 {
        return Err(XRawError::UnsupportedColorChannelBits);
    }

    // We can lift this restriction and support inline data in the voxels, if we
    // so choose.
    if header.index_bits != XRAW_INDEX_BITS_8 && header.index_bits != XRAW_INDEX_BITS_16 {
        return Err(XRawError::UnsupportedIndexBits);
    }

    // This restriction keeps us below 10MB, even if we have 16-bit indices.
    const SIZE_LIMIT: u32 = 128;
    if header.size_x > SIZE_LIMIT {
        return Err(XRawError::UnsupportedSize {
            max: SIZE_LIMIT,
            got: header.size_x,
        });
    }
    if header.size_y > SIZE_LIMIT {
        return Err(XRawError::UnsupportedSize {
            max: SIZE_LIMIT,
            got: header.size_y,
        });
    }
    if header.size_z > SIZE_LIMIT {
        return Err(XRawError::UnsupportedSize {
            max: SIZE_LIMIT,
            got: header.size_z,
        });
    }

    Ok(header)
}

pub fn header_from_bytes_unchecked(bytes: &[u8]) -> &XRawHeader {
    // Because we are going to cast the bytes into the XRAW header (and later
    // also data) directly, we need to verify their alignment is correct.
    //
    // In this case, we are only debug-asserting, because we trust the data.
    debug_assert!(bytes.as_ptr() as usize % XRAW_HEADER_ALIGN == 0);
    let header_bytes = &bytes[0..XRAW_HEADER_SIZE];
    let header: &XRawHeader = bytemuck::from_bytes(header_bytes);

    header
}

pub fn data_from_bytes_header<'a>(
    bytes: &'a [u8],
    header: &'a XRawHeader,
) -> Result<XRawDataRef<'a>, XRawError> {
    // Because we are going to cast the bytes into the XRAW data directly, we
    // need to verify their alignment is correct.
    //
    // TODO(yan): Do we want to make this an error instead of an assertion?
    assert!(bytes.as_ptr() as usize % XRAW_HEADER_ALIGN == 0);

    let voxel_byte_len = voxel_byte_len(header);
    let palette_byte_len = palette_byte_len(header);
    let data_byte_len = voxel_byte_len + palette_byte_len;
    if data_byte_len > bytes.len() {
        // Out of bounds.
        return Err(XRawError::NotEnoughDataBytes {
            expected: cast_u32!(data_byte_len),
            got: cast_u32!(bytes.len()),
        });
    }

    // We could have received more bytes than than we need, therefore we trim
    // the slice to the size of data as defined by the header so that the
    // bytemuck cast succeeds.
    //
    // TODO(yan): Should we report this as an error?
    let bytes = &bytes[..data_byte_len];

    // There seems to be no alignment of the color segment, so we likely won't
    // be able to cast into 16bit or 32bit color channels without copying.
    let (voxel_bytes, color_bytes) = bytes.split_at(voxel_byte_len);

    let data = match header.index_bits {
        XRAW_INDEX_BITS_8 => {
            let voxels = voxel_bytes;
            let colors: &[RgbaU8] = bytemuck::cast_slice(color_bytes);

            XRawDataRef::VoxelIndexed8PaletteRgbaU8(voxels, colors)
        }
        XRAW_INDEX_BITS_16 => {
            let voxels: &[u16] = bytemuck::cast_slice(voxel_bytes);
            let colors: &[RgbaU8] = bytemuck::cast_slice(color_bytes);

            XRawDataRef::VoxelIndexed16PaletteRgbaU8(voxels, colors)
        }
        _ => unreachable!(),
    };

    Ok(data)
}

pub fn data_from_bytes_header_mut<'a>(
    bytes: &'a mut [u8],
    header: &'a XRawHeader,
) -> Result<XRawDataMut<'a>, XRawError> {
    // Because we are going to cast the bytes into the XRAW data directly, we
    // need to verify their alignment is correct.
    //
    // TODO(yan): Do we want to make this an error instead of an assertion?
    assert!(bytes.as_ptr() as usize % XRAW_HEADER_ALIGN == 0);

    let voxel_byte_len = voxel_byte_len(header);
    let palette_byte_len = palette_byte_len(header);
    let data_byte_len = voxel_byte_len + palette_byte_len;
    if data_byte_len > bytes.len() {
        // Out of bounds.
        return Err(XRawError::NotEnoughDataBytes {
            expected: cast_u32!(data_byte_len),
            got: cast_u32!(bytes.len()),
        });
    }

    // We could have received more bytes than than we need, therefore we trim
    // the slice to the size of data as defined by the header so that the
    // bytemuck cast succeeds.
    //
    // TODO(yan): Should we report this as an error?
    let bytes = &mut bytes[..data_byte_len];

    // There seems to be no alignment of the color segment, so we likely won't
    // be able to cast into 16bit or 32bit color channels without copying.
    let (voxel_bytes, color_bytes) = bytes.split_at_mut(voxel_byte_len);

    let data = match header.index_bits {
        XRAW_INDEX_BITS_8 => {
            let voxels = voxel_bytes;
            let colors: &mut [RgbaU8] = bytemuck::cast_slice_mut(color_bytes);

            XRawDataMut::VoxelIndexed8PaletteRgbaU8(voxels, colors)
        }
        XRAW_INDEX_BITS_16 => {
            let voxels: &mut [u16] = bytemuck::cast_slice_mut(voxel_bytes);
            let colors: &mut [RgbaU8] = bytemuck::cast_slice_mut(color_bytes);

            XRawDataMut::VoxelIndexed16PaletteRgbaU8(voxels, colors)
        }
        _ => unreachable!(),
    };

    Ok(data)
}

pub fn total_byte_len(header: &XRawHeader) -> usize {
    XRAW_HEADER_SIZE + voxel_byte_len(header) + palette_byte_len(header)
}

pub fn voxel_byte_len(header: &XRawHeader) -> usize {
    cast_usize!(header.size_x)
        * cast_usize!(header.size_y)
        * cast_usize!(header.size_z)
        * usize::from(header.index_bits / 8)
}

pub fn palette_byte_len(header: &XRawHeader) -> usize {
    cast_usize!(header.palette_size)
        * usize::from(header.color_bits / 8)
        * usize::from(header.color_channel_count)
}

pub fn position_to_index(header: &XRawHeader, x: u32, y: u32, z: u32) -> usize {
    cast_usize!(x + y * header.size_x + z * header.size_x * header.size_y)
}

pub fn trim<A: Allocator>(
    temp_allocator: A,
    header: &XRawHeader,
    data: XRawDataMut<'_>,
    trim_directions: XRawTrimDirections,
) -> Result<(), XRawError> {
    let pos_to_idx = |x, y, z| x + y * header.size_x + z * header.size_x * header.size_y;
    let idx_to_pos = |idx| {
        let x = idx % (header.size_x * header.size_y) % header.size_x;
        let y = idx % (header.size_x * header.size_y) / header.size_x;
        let z = idx / (header.size_x * header.size_y);

        [x, y, z]
    };

    let size = cast_usize!(header.size_x) * cast_usize!(header.size_y) * cast_usize!(header.size_z);

    const FLAG_VISITED: u8 = 0x01;

    let mut q: VecDeque<u32, _> = VecDeque::with_capacity_in(size, &temp_allocator);
    let mut search: Vec<u8, _> = Vec::with_capacity_in(size, &temp_allocator);
    search.resize(size, 0);

    if trim_directions.intersects(XRawTrimDirections::TOP) {
        for y in 0..header.size_y {
            for x in 0..header.size_x {
                let index = pos_to_idx(x, y, header.size_z - 1);
                q.push_back(index);
            }
        }
    }

    if trim_directions.intersects(XRawTrimDirections::BOTTOM) {
        for y in 0..header.size_y {
            for x in 0..header.size_x {
                let index = pos_to_idx(x, y, 0);
                q.push_back(index);
            }
        }
    }

    if trim_directions.intersects(XRawTrimDirections::LEFT) {
        for z in 0..header.size_z {
            for y in 0..header.size_y {
                let index = pos_to_idx(0, y, z);
                q.push_back(index);
            }
        }
    }

    if trim_directions.intersects(XRawTrimDirections::RIGHT) {
        for z in 0..header.size_z {
            for y in 0..header.size_y {
                let index = pos_to_idx(header.size_x - 1, y, z);
                q.push_back(index);
            }
        }
    }

    if trim_directions.intersects(XRawTrimDirections::FRONT) {
        for z in 0..header.size_z {
            for x in 0..header.size_x {
                let index = pos_to_idx(x, 0, z);
                q.push_back(index);
            }
        }
    }

    if trim_directions.intersects(XRawTrimDirections::BACK) {
        for z in 0..header.size_z {
            for x in 0..header.size_x {
                let index = pos_to_idx(x, header.size_y - 1, z);
                q.push_back(index);
            }
        }
    }

    while let Some(index) = q.pop_front() {
        let index_usize = cast_usize!(index);
        search[index_usize] |= FLAG_VISITED;

        match &data {
            XRawDataMut::VoxelIndexed8PaletteRgbaU8(voxels, _) => {
                if voxels[index_usize] != XRAW_VOXEL_INDEX_EMPTY_8 {
                    continue;
                }
            }
            XRawDataMut::VoxelIndexed16PaletteRgbaU8(voxels, _) => {
                if voxels[index_usize] != XRAW_VOXEL_INDEX_EMPTY_16 {
                    continue;
                }
            }
        }

        let [x, y, z] = idx_to_pos(index);

        for [dx, dy, dz] in [
            [-1, 0, 0],
            [1, 0, 0],
            [0, -1, 0],
            [0, 1, 0],
            [0, 0, -1],
            [0, 0, 1],
        ] {
            let sx = x as i32 + dx;
            let sy = y as i32 + dy;
            let sz = z as i32 + dz;

            if sx < 0 || sy < 0 || sz < 0 {
                continue;
            }

            if sx >= header.size_x as i32
                || sy >= header.size_y as i32
                || sz >= header.size_z as i32
            {
                continue;
            }

            let sindex = pos_to_idx(sx as u32, sy as u32, sz as u32);
            let sindex_usize = cast_usize!(sindex);

            if search[sindex_usize] & FLAG_VISITED == 0 {
                q.push_back(sindex);
            }
        }
    }

    match data {
        XRawDataMut::VoxelIndexed8PaletteRgbaU8(voxels, _) => {
            for (i, voxel) in voxels.iter_mut().enumerate() {
                if search[i] & FLAG_VISITED == 0 {
                    *voxel = XRAW_VOXEL_INDEX_EMPTY_8;
                }
            }
        }
        XRawDataMut::VoxelIndexed16PaletteRgbaU8(voxels, _) => {
            for (i, voxel) in voxels.iter_mut().enumerate() {
                if search[i] & FLAG_VISITED == 0 {
                    *voxel = XRAW_VOXEL_INDEX_EMPTY_16;
                }
            }
        }
    }

    Ok(())
}
