#![no_std]
#![feature(allocator_api)]
// TODO(yan): See if we still need to allow these once we are done with the
// code. These are stylistic lints that that should improve readability, but
// following them blindly sometimes decreases it.
#![allow(clippy::collapsible_else_if)] // tag: style
#![allow(clippy::derive_partial_eq_without_eq)] // tag: style
#![allow(clippy::match_like_matches_macro)] // tag: style

extern crate alloc;

mod fmt;
mod parser;

use alloc::vec::Vec;
use core::alloc::Allocator;
use core::str;

use arrayvec::{ArrayString, ArrayVec};
pub use lfg_cereal_derive::{Deserialize, Serialize};
use lfg_math::{IVec2, IVec3, IVec4, Vec2, Vec3, Vec4};

pub use crate::fmt::{ArrayLikeFormatter, DictionaryLikeFormatter, Formatter};
pub use crate::parser::{parse_in, Node, ParseError, Token};

pub const ARRAY_LIKE_MULTILINE_THRESHOLD: usize = 4;
pub const DICTIONARY_LIKE_MULTILINE_THRESHOLD: usize = 1;

pub fn serialize<T: Serialize, A: Allocator>(value: T, allocator: A) -> Vec<u8, A> {
    let mut f = Formatter::new_in(allocator);
    value.serialize(&mut f);

    f.into_data()
}

// TODO(yan): @Speed @Memory lfg_cereal::deserialize_in allocates the parse
// tree. It can use a separate allocator to do this so it doesn't fragment
// memory for simplistic allocators, but long term solution is to not allocate
// at all during parsing. Not sure if this is even possible without unsafe and
// poking bytes into uninitialized memory.

pub fn deserialize_in<T, A, PA>(
    str: &str,
    allocator: A,
    parse_allocator: PA,
) -> Result<T, DeserializeError>
where
    T: Deserialize<A>,
    A: Allocator + Clone,
    PA: Allocator + Clone,
{
    // TODO(yan): Use data from parse error.
    let tree = parse_in(str, parse_allocator).map_err(|_| DeserializeError)?;
    let value: T = T::deserialize(&tree, allocator)?;

    Ok(value)
}

pub trait Serialize {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>);
}

impl Serialize for bool {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.boolean(*self)
    }
}

impl Serialize for i8 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for i16 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for i32 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for i64 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for u8 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for u16 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for u32 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.int(*self)
    }
}

impl Serialize for f32 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.float(*self)
    }
}

impl Serialize for f64 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.float(*self)
    }
}

impl<T: Serialize> Serialize for [T] {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.array(self.len() > ARRAY_LIKE_MULTILINE_THRESHOLD, |array_fmt| {
            for item in self {
                array_fmt.item(|item_fmt| {
                    item.serialize(item_fmt);
                });
            }
        });
    }
}

macro_rules! impl_serialize_for_tuple {
    ( $length:expr; $( $ty:ident )+ ) => {
        impl<$($ty: Serialize),+> Serialize for ($($ty,)+)
        {
            #[allow(non_snake_case)]
            fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
                let ($(ref $ty,)+) = self;
                f.tuple($length > ARRAY_LIKE_MULTILINE_THRESHOLD, |tuple_fmt| {
                    $(tuple_fmt.item(|item_fmt| $ty.serialize(item_fmt));)+
                });
            }
        }
    };
}

impl_serialize_for_tuple! { 1; T1 }
impl_serialize_for_tuple! { 2; T1 T2 }
impl_serialize_for_tuple! { 3; T1 T2 T3 }
impl_serialize_for_tuple! { 4; T1 T2 T3 T4 }
impl_serialize_for_tuple! { 5; T1 T2 T3 T4 T5 }
impl_serialize_for_tuple! { 6; T1 T2 T3 T4 T5 T6 }
impl_serialize_for_tuple! { 7; T1 T2 T3 T4 T5 T6 T7 }
impl_serialize_for_tuple! { 8; T1 T2 T3 T4 T5 T6 T7 T8 }

impl Serialize for str {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        f.string(self)
    }
}

impl<T: Serialize> Serialize for Option<T> {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        match self {
            None => f.null(),
            Some(node) => node.serialize(f),
        }
    }
}

impl Serialize for IVec2 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        self.to_array().serialize(f)
    }
}

impl Serialize for IVec3 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        self.to_array().serialize(f)
    }
}

impl Serialize for IVec4 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        self.to_array().serialize(f)
    }
}

impl Serialize for Vec2 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        self.to_array().serialize(f)
    }
}

impl Serialize for Vec3 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        self.to_array().serialize(f)
    }
}

impl Serialize for Vec4 {
    fn serialize<A: Allocator>(&self, f: &mut fmt::Formatter<A>) {
        self.to_array().serialize(f)
    }
}

#[derive(Debug, PartialEq)]
pub struct DeserializeError;

impl core::fmt::Display for DeserializeError {
    fn fmt(&self, f: &mut core::fmt::Formatter) -> core::fmt::Result {
        write!(f, "{self:?}")
    }
}

pub trait Deserialize<A: Allocator + Clone>: Sized {
    fn deserialize<NA: Allocator + Clone>(
        node: &Node<NA>,
        allocator: A,
    ) -> Result<Self, DeserializeError>;
}

impl<A: Allocator + Clone> Deserialize<A> for bool {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Boolean(true) => Ok(true),
            Node::Boolean(false) => Ok(false),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for i8 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => i8::try_from(*int).map_err(|_| DeserializeError),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for i16 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => i16::try_from(*int).map_err(|_| DeserializeError),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for i32 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => i32::try_from(*int).map_err(|_| DeserializeError),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for i64 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => Ok(*int),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for u8 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => u8::try_from(*int).map_err(|_| DeserializeError),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for u16 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => u16::try_from(*int).map_err(|_| DeserializeError),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for u32 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Int(int) => u32::try_from(*int).map_err(|_| DeserializeError),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for f32 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            // TODO(yan): Fail if this would lose precision?
            Node::Int(int) => Ok(*int as f32),
            // TODO(yan): Fail if this would lose precision?
            Node::Float(float) => Ok(*float as f32),
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for f64 {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            // TODO(yan): Fail if this would lose precision?
            Node::Int(int) => Ok(*int as f64),
            Node::Float(float) => Ok(*float),
            _ => Err(DeserializeError),
        }
    }
}

// TODO(yan): Drop Default and Copy bounds and use MaybeUninit internally.
impl<A: Allocator + Clone, T: Deserialize<A> + Default + Copy, const N: usize> Deserialize<A>
    for [T; N]
{
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() != N {
                    return Err(DeserializeError);
                }

                let mut a = [T::default(); N];

                for (i, item_node) in array.iter().enumerate() {
                    let item = T::deserialize(item_node, allocator.clone())?;
                    a[i] = item;
                }

                Ok(a)
            }
            _ => Err(DeserializeError),
        }
    }
}

// TODO(yan): Drop Copy bounds and use MaybeUninit internally, if it's even possible.
macro_rules! impl_deserialize_for_tuple {
    ( $length:expr; $( $ty:ident )+ ) => {
        impl<A: Allocator + Clone, $($ty: Deserialize<A> + Copy),+> Deserialize<A> for ($($ty,)+)
        {

            fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
            where
                NA: Allocator + Clone,
            {
                #[allow(non_snake_case)]
                #[allow(unused_assignments)]
                match node {
                    Node::Tuple(tuple) => {
                        if tuple.len() != $length {
                            return Err(DeserializeError);
                        }

                        let mut i: usize = 0;
                        $(let $ty = {
                            let value = $ty::deserialize(&tuple[i], allocator.clone())?;
                            i += 1;

                            value
                        };)+

                        Ok(($($ty,)+))
                    }
                    _ => Err(DeserializeError),
                }
            }
        }
    };
}

impl_deserialize_for_tuple! { 1; T1 }
impl_deserialize_for_tuple! { 2; T1 T2 }
impl_deserialize_for_tuple! { 3; T1 T2 T3 }
impl_deserialize_for_tuple! { 4; T1 T2 T3 T4 }
impl_deserialize_for_tuple! { 5; T1 T2 T3 T4 T5 }
impl_deserialize_for_tuple! { 6; T1 T2 T3 T4 T5 T6 }
impl_deserialize_for_tuple! { 7; T1 T2 T3 T4 T5 T6 T7 }
impl_deserialize_for_tuple! { 8; T1 T2 T3 T4 T5 T6 T7 T8 }

impl<T: Deserialize<A>, A: Allocator + Clone> Deserialize<A> for Option<T> {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Null => Ok(None),
            node => Ok(Some(T::deserialize(node, allocator)?)),
        }
    }
}

impl<T: Deserialize<A>, A: Allocator + Clone> Deserialize<A> for Vec<T, A> {
    fn deserialize<NA: Allocator + Clone>(
        node: &Node<NA>,
        allocator: A,
    ) -> Result<Self, DeserializeError> {
        match node {
            Node::Array(array) => {
                let mut vec = Vec::with_capacity_in(array.len(), allocator.clone());

                for item_node in array {
                    let item = T::deserialize(item_node, allocator.clone())?;
                    vec.push(item);
                }

                Ok(vec)
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<T: Deserialize<A>, A: Allocator + Clone, const N: usize> Deserialize<A> for ArrayVec<T, N> {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() > N {
                    return Err(DeserializeError);
                }

                let mut arrayvec: ArrayVec<T, N> = ArrayVec::new();

                for item_node in array {
                    let item = T::deserialize(item_node, allocator.clone())?;
                    arrayvec.push(item);
                }

                Ok(arrayvec)
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone, const N: usize> Deserialize<A> for ArrayString<N> {
    fn deserialize<NA>(node: &Node<NA>, _: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::String(string) => {
                if string.len() > N {
                    return Err(DeserializeError);
                }

                let arraystring: ArrayString<N> =
                    ArrayString::from(unsafe { str::from_utf8_unchecked(string) })
                        .map_err(|_| DeserializeError)?;

                Ok(arraystring)
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for IVec2 {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() == Self::AXES.len() {
                    let x = i32::deserialize(&array[0], allocator.clone())?;
                    let y = i32::deserialize(&array[1], allocator)?;

                    Ok(Self::new(x, y))
                } else {
                    Err(DeserializeError)
                }
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for IVec3 {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() == Self::AXES.len() {
                    let x = i32::deserialize(&array[0], allocator.clone())?;
                    let y = i32::deserialize(&array[1], allocator.clone())?;
                    let z = i32::deserialize(&array[2], allocator)?;

                    Ok(Self::new(x, y, z))
                } else {
                    Err(DeserializeError)
                }
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for IVec4 {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() == Self::AXES.len() {
                    let x = i32::deserialize(&array[0], allocator.clone())?;
                    let y = i32::deserialize(&array[1], allocator.clone())?;
                    let z = i32::deserialize(&array[2], allocator.clone())?;
                    let w = i32::deserialize(&array[3], allocator)?;

                    Ok(Self::new(x, y, z, w))
                } else {
                    Err(DeserializeError)
                }
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for Vec2 {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() == Self::AXES.len() {
                    let x = f32::deserialize(&array[0], allocator.clone())?;
                    let y = f32::deserialize(&array[1], allocator)?;

                    Ok(Self::new(x, y))
                } else {
                    Err(DeserializeError)
                }
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for Vec3 {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() == Self::AXES.len() {
                    let x = f32::deserialize(&array[0], allocator.clone())?;
                    let y = f32::deserialize(&array[1], allocator.clone())?;
                    let z = f32::deserialize(&array[2], allocator)?;

                    Ok(Self::new(x, y, z))
                } else {
                    Err(DeserializeError)
                }
            }
            _ => Err(DeserializeError),
        }
    }
}

impl<A: Allocator + Clone> Deserialize<A> for Vec4 {
    fn deserialize<NA>(node: &Node<NA>, allocator: A) -> Result<Self, DeserializeError>
    where
        NA: Allocator + Clone,
    {
        match node {
            Node::Array(array) => {
                if array.len() == Self::AXES.len() {
                    let x = f32::deserialize(&array[0], allocator.clone())?;
                    let y = f32::deserialize(&array[1], allocator.clone())?;
                    let z = f32::deserialize(&array[2], allocator.clone())?;
                    let w = f32::deserialize(&array[3], allocator)?;

                    Ok(Self::new(x, y, z, w))
                } else {
                    Err(DeserializeError)
                }
            }
            _ => Err(DeserializeError),
        }
    }
}

// NB: This is only used by lfg_cereal macros. All strings in lfg_cereal are Vec<u8, A>
// instead of String<A> temporarily, until String<A> exists (and borrows as
// str).
#[doc(hidden)]
#[inline(always)]
pub fn cast_ident(bytes: &[u8]) -> &str {
    unsafe { core::str::from_utf8_unchecked(bytes) }
}
