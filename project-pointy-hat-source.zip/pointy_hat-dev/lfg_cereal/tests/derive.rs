#![feature(allocator_api)]

use std::alloc::Global;

use arrayvec::{ArrayString, ArrayVec};
use lfg_alloc::{Linear, LinearOptions};
use lfg_cereal as cereal;

#[test]
fn test_deserialize_in_global_dictionary_struct() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator(Global))]
    struct Foo {
        i: i32,
        u: u8,
        f: f64,
        s: arrayvec::ArrayString<16>,
        a: arrayvec::ArrayVec<u8, 32>,
        v: Vec<u8, Global>,
    }

    let str = r#"Foo { i: -1, u: 0, f: 123.23, s: "Peekaboo", a: [2, 3, 5], v: [1, 2, 3]}"#;
    let res = cereal::deserialize_in::<Foo, _, _>(str, Global, Global);
    let slice: &[u8] = &[2, 3, 5];

    #[rustfmt::skip]
    assert!(res == Ok(Foo {
        i: -1,
        u: 0,
        f: 123.23,
        s: ArrayString::from("Peekaboo").unwrap(),
        a: ArrayVec::try_from(slice).unwrap(),
        v: vec![1, 2, 3],
    }));
}

#[test]
fn test_deserialize_in_global_vec() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator(Global))]
    struct Foo(Vec<u8, Global>);

    let str = r#"Foo [[1, 2, 3, 4]]"#;
    let res = cereal::deserialize_in::<Foo, _, _>(str, Global, Global);

    assert!(res == Ok(Foo(vec![1, 2, 3, 4])));
}

#[test]
fn test_deserialize_in_global_vec_nested() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator(Global))]
    struct Foo(Vec<Vec<u8, Global>, Global>);

    let str = r#"Foo [[[1, 2], [3], [4]]]"#;
    let res = cereal::deserialize_in::<Foo, _, _>(str, Global, Global);

    assert!(res == Ok(Foo(vec![vec![1, 2], vec![3], vec![4]])));
}

#[test]
fn test_deserialize_in_linear_vec() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"))]
    struct Foo<'a>(Vec<u8, &'a Linear>);

    let alloc = make_linear();

    let str = r#"Foo [[1, 2, 3, 4]]"#;
    let res = cereal::deserialize_in::<Foo, _, _>(str, &alloc, &alloc);

    assert!(res == Ok(Foo(vec_in([1, 2, 3, 4], &alloc))));
}

#[test]
fn test_deserialize_in_linear_vec_nested() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator("&'a Linear"))]
    struct Foo<'a>(Vec<Vec<u8, &'a Linear>, &'a Linear>);

    let alloc = make_linear();

    let str = r#"Foo [[[1, 2], [3], [4]]]"#;
    let res = cereal::deserialize_in::<Foo, _, _>(str, &alloc, &alloc);

    #[rustfmt::skip]
    assert!(res == Ok(Foo(vec_in([
        vec_in([1, 2], &alloc),
        vec_in([3], &alloc),
        vec_in([4], &alloc),
    ], &alloc))));
}

#[test]
fn test_deserialize_rename_unit_struct() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(rename("MrNiceGuy"))]
    struct ActuallyChaos;

    let str = "MrNiceGuy";
    let res = cereal::deserialize_in::<ActuallyChaos, _, _>(str, Global, Global);

    assert!(res == Ok(ActuallyChaos));
}

#[test]
fn test_deserialize_rename_tuple_struct() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(rename("MrNiceGuy"))]
    struct ActuallyChaos(i32, f64);

    let str = "MrNiceGuy [1, 42.0]";
    let res = cereal::deserialize_in::<ActuallyChaos, _, _>(str, Global, Global);

    assert!(res == Ok(ActuallyChaos(1, 42.0)));
}

#[test]
fn test_deserialize_rename_dictionary_struct() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(rename("MrNiceGuy"))]
    struct ActuallyChaos {
        left_hand: i32,
        right_hand: f64,
    }

    let str = "MrNiceGuy { left_hand: 1, right_hand :42.0 }";
    let res = cereal::deserialize_in::<ActuallyChaos, _, _>(str, Global, Global);

    #[rustfmt::skip]
    assert!(res == Ok(ActuallyChaos {
        left_hand: 1,
        right_hand: 42.0
    }));
}

#[test]
fn test_deserialize_in_enum_unit_variant() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator(Global))]
    enum TheWorldIs {
        Full,
        Of(u32, i32),
        Difficult { choices: Vec<u8, Global> },
    }

    let str = "Full";
    let res = cereal::deserialize_in::<TheWorldIs, _, _>(str, Global, Global);

    assert!(res == Ok(TheWorldIs::Full));
}

#[test]
fn test_deserialize_in_enum_array_variant() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator(Global))]
    enum TheWorldIs {
        Full,
        Of(u32, i32),
        Difficult { choices: Vec<u8, Global> },
    }

    let str = "Of [234524, -123132]";
    let res = cereal::deserialize_in::<TheWorldIs, _, _>(str, Global, Global);

    assert!(res == Ok(TheWorldIs::Of(234524, -123132)));
}

#[test]
fn test_deserialize_in_enum_map_variant() {
    #[derive(Debug, PartialEq)]
    #[derive(cereal::Deserialize)]
    #[cereal(allocator(Global))]
    enum TheWorldIs {
        Full,
        Of(u32, i32),
        Difficult { choices: Vec<u8, Global> },
    }

    let str = r#"Difficult {
      choices: [0, 1, 1, 8, 9, 9, 9, 0, 1, 9, 1, 1, 0, 1, 1, 8, 7, 2, 5, 3],
    }"#;
    let res = cereal::deserialize_in::<TheWorldIs, _, _>(str, Global, Global);

    #[rustfmt::skip]
    assert!(res == Ok(TheWorldIs::Difficult {
        choices: vec![0, 1, 1, 8, 9, 9, 9, 0, 1, 9, 1, 1, 0, 1, 1, 8, 7, 2, 5, 3],
    }));
}

fn vec_in<T, A: core::alloc::Allocator, const N: usize>(array: [T; N], allocator: A) -> Vec<T, A> {
    let mut v = Vec::new_in(allocator);
    v.extend(array);

    v
}

fn make_linear() -> Linear {
    use core::ptr::NonNull;

    let memory = vec![0u8; 1 << 20];
    let memory_slice = memory.leak();
    let memory_ptr = NonNull::new(memory_slice.as_mut_ptr()).unwrap();
    let memory_len = memory_slice.len();

    let allocator_result = unsafe {
        Linear::new(
            memory_ptr,
            memory_len,
            &LinearOptions {
                fill_with_zeros: false,
            },
        )
    };

    allocator_result.unwrap()
}
