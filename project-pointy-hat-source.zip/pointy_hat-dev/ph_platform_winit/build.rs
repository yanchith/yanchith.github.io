use std::process::Command;

fn main() {
    if let Ok(output) = Command::new("git")
        .args(&["rev-parse", "--short", "HEAD"])
        .output()
    {
        let git_commit_hash = String::from_utf8_lossy(&output.stdout);
        println!("cargo:rustc-env=GIT_COMMIT_HASH={}", git_commit_hash);
    } else {
        println!("cargo:warning=Invoking git failed, not including git commit hash for this build");
        println!("cargo:rustc-env=GIT_COMMIT_HASH=unknown");
    }
}
