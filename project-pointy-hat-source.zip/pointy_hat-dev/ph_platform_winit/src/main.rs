#![feature(allocator_api)]

#[macro_use]
mod profile;

use std::alloc::Allocator;
use std::fs::{self, File};
use std::io::Read as _;
use std::mem;
use std::panic;
use std::path::Path;
use std::ptr::NonNull;
use std::thread;
use std::time::{Duration, Instant};

use arrayvec::ArrayVec;
use lfg_alloc::{Linear, LinearOptions};
use lfg_common::{cast_u16, cast_usize, megabytes};
use lfg_math::{uvec2, vec2, Vec2};
use ph::{self, Input, Key, KeyState, Mb};
use ph_platform::{
    AlignSlice,
    ColorBitDepth,
    ColorType,
    Image,
    ListedFile,
    Platform,
    PlatformError,
};
use ph_renderer_wgpu::WgpuRenderer;

struct WinitPlatform;

impl Platform for WinitPlatform {
    fn read_file<A: Allocator>(
        &self,
        allocator: A,
        path: &str,
    ) -> Result<Vec<u8, A>, PlatformError> {
        log::debug!("Reading file: {path}");
        let p = Path::new(path);

        match File::open(p) {
            Ok(mut f) => {
                let file_len = f.metadata().map(|m| m.len()).unwrap_or(0);
                if file_len == 0 {
                    // If we failed to find file metadata or the platform gave
                    // us back zero, fall back to reading one byte at a time.

                    log::warn!("Failed to read file len (or was zero) for {path}");

                    let mut data = Vec::with_capacity_in(1024, allocator);
                    for byte in f.bytes() {
                        match byte {
                            Ok(byte) => data.push(byte),
                            Err(_) => return Err(PlatformError),
                        }
                    }

                    Ok(data)
                } else {
                    let capacity = cast_usize!(file_len);
                    let mut data = Vec::with_capacity_in(capacity, allocator);
                    data.resize(capacity, 0);

                    f.read_exact(&mut data).map_err(|_| PlatformError)?;

                    Ok(data)
                }
            }
            Err(err) => {
                log::warn!("Failed to open file: {err}");
                Err(PlatformError)
            }
        }
    }

    fn read_file_align4<A: Allocator>(
        &self,
        allocator: A,
        path: &str,
    ) -> Result<AlignSlice<A>, PlatformError> {
        log::debug!("Reading file aligned to 4: {path}");
        let p = Path::new(path);

        fn vec_align4<A: Allocator>(capacity: usize, allocator: A) -> Vec<u8, A> {
            let aligned_capacity = capacity / 4 + if capacity % 4 == 0 { 0 } else { 1 };

            // Because we are reconstructing the same Vec, we are also not
            // bothering with A: Allocator + Clone, since it is literally the
            // same allocator. This is only possible, because we mem::forget the
            // aligned Vec.
            let mut aligned: Vec<u32, _> = Vec::with_capacity_in(aligned_capacity, &allocator);

            let aligned_ptr = aligned.as_mut_ptr();
            let aligned_len = aligned.len();
            let aligned_capacity_actual = aligned.capacity();

            mem::forget(aligned);

            unsafe {
                Vec::from_raw_parts_in(
                    aligned_ptr as *mut u8,
                    aligned_len * 4,
                    aligned_capacity_actual * 4,
                    allocator,
                )
            }
        }

        match File::open(p) {
            Ok(mut f) => {
                let file_len = f.metadata().map(|m| m.len()).unwrap_or(0);
                if file_len == 0 {
                    // If we failed to find file metadata or the platform gave
                    // us back zero, fall back to reading one byte at a time.

                    log::warn!("Failed to read file len (or was zero) for {path}");

                    let mut data = vec_align4(1024, allocator);
                    for byte in f.bytes() {
                        match byte {
                            Ok(byte) => data.push(byte),
                            Err(_) => return Err(PlatformError),
                        }
                    }

                    Ok(unsafe { AlignSlice::new_unchecked(data) })
                } else {
                    let capacity = cast_usize!(file_len);
                    let mut data = vec_align4(capacity, allocator);
                    data.resize(capacity, 0);

                    f.read_exact(&mut data).map_err(|_| PlatformError)?;

                    Ok(unsafe { AlignSlice::new_unchecked(data) })
                }
            }
            Err(err) => {
                log::warn!("Failed to open file: {err}");
                Err(PlatformError)
            }
        }
    }

    fn read_png<A: Allocator>(&self, allocator: A, path: &str) -> Result<Image<A>, PlatformError> {
        log::debug!("Reading PNG file: {path}");
        let p = Path::new(path);

        match File::open(p) {
            Ok(f) => {
                let decoder = png::Decoder::new(f);
                let mut reader = decoder.read_info().map_err(|_| PlatformError)?;

                let capacity = reader.output_buffer_size();
                let mut data = Vec::with_capacity_in(capacity, allocator);
                data.resize(capacity, 0);

                let info = reader.next_frame(&mut data).map_err(|_| PlatformError)?;
                log::debug!(
                    "PNG info: dimensions: {}x{}, colors: {:?}, bits: {:?}",
                    info.width,
                    info.height,
                    info.color_type,
                    info.bit_depth,
                );

                // TODO(yan): Relax this constraint and implement loading for more color
                // types and bit depths.
                assert_eq!(info.bit_depth, png::BitDepth::Eight);
                let color_type = match info.color_type {
                    png::ColorType::Rgb => ColorType::Rgb,
                    png::ColorType::Rgba => ColorType::Rgba,
                    _ => panic!("PNG Color type not supported"),
                };

                let width = cast_u16!(info.width);
                let height = cast_u16!(info.height);

                Ok(Image {
                    color_type,
                    color_bit_depth: ColorBitDepth::D8,
                    data,
                    width,
                    height,
                })
            }
            Err(err) => {
                log::warn!("Failed to open file: {err}");
                Err(PlatformError)
            }
        }
    }

    fn write_file(
        &self,
        _allocator: &Linear,
        path: &str,
        data: &[u8],
    ) -> Result<(), PlatformError> {
        log::debug!("Writing file: {path}");
        fs::write(path, data).map_err(|_| PlatformError)
    }

    fn write_new_file(
        &self,
        _allocator: &Linear,
        path: &str,
        data: &[u8],
    ) -> Result<(), PlatformError> {
        use std::fs::OpenOptions;
        use std::io::Write;

        log::debug!("Writing new file: {path}");
        match OpenOptions::new().write(true).create_new(true).open(path) {
            Ok(mut f) => match f.write_all(data) {
                Ok(_) => Ok(()),
                Err(_) => Err(PlatformError),
            },
            Err(_) => Err(PlatformError),
        }
    }

    fn list_files<'a>(
        &self,
        allocator: &'a Linear,
        path: &str,
        exts: &[&str],
    ) -> Result<Vec<ListedFile<'a>, &'a Linear>, PlatformError> {
        log::debug!("Listing files in: {path}");
        let p = Path::new(path);

        let mut files: Vec<ListedFile, _> = Vec::with_capacity_in(256, allocator);

        if p.is_dir() {
            match fs::read_dir(p) {
                Ok(read_dir) => {
                    for entry in read_dir {
                        match entry {
                            Ok(entry) => {
                                let entry_path = entry.path();
                                if let Some(entry_path_str) = entry_path.to_str() {
                                    if let Some(entry_ext) = entry_path.extension() {
                                        if let Some(entry_ext_str) = entry_ext.to_str() {
                                            if exts.contains(&entry_ext_str) {
                                                if let Some(entry_file_stem) =
                                                    entry_path.file_stem()
                                                {
                                                    if let Some(entry_file_stem_str) =
                                                        entry_file_stem.to_str()
                                                    {
                                                        let mut entry_file_path_string =
                                                            Vec::new_in(allocator);
                                                        let mut entry_file_stem_string =
                                                            Vec::new_in(allocator);
                                                        let mut entry_ext_string =
                                                            Vec::new_in(allocator);

                                                        entry_file_path_string
                                                            .extend(entry_path_str.as_bytes());
                                                        entry_file_stem_string
                                                            .extend(entry_file_stem_str.as_bytes());
                                                        entry_ext_string
                                                            .extend(entry_ext_str.as_bytes());

                                                        // TODO(yan): Windows
                                                        // gives us backslashes,
                                                        // if we didn't specify
                                                        // a forward slash
                                                        // manually. We should
                                                        // normalize it here,
                                                        // but that's harder to
                                                        // do without String<A>.
                                                        //
                                                        // entry_file_path_string.replace(b'\\', b'/');

                                                        files.push(ListedFile {
                                                            file_path: entry_file_path_string,
                                                            file_stem: entry_file_stem_string,
                                                            file_ext: entry_ext_string,
                                                        });
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            Err(err) => {
                                log::warn!("Failed to read directory entry: {err}");
                                return Err(PlatformError);
                            }
                        }
                    }
                }
                Err(err) => {
                    log::warn!("Failed to read directory: {err}");
                    return Err(PlatformError);
                }
            }
        } else {
            log::warn!("Could not list files, path was not a directory");
            return Err(PlatformError);
        }

        Ok(files)
    }
}

fn main() {
    // TODO(yan): Instrument global allocator, so we can see all the allocations
    // in profiles. Is there a way we can get file/line for each allocation?

    // TODO(yan): @Correctness @Bug? We sometimes (very rarely, once every 100
    // runs?) take down Windows somewhere up here, before we create the event
    // loop and the window, before anything even gets logged.
    //
    // It happens without tracy_client being compiled in, and it was happening
    // long before we startetd installing the panic hook, so it is either the
    // Instant::now, installing our logger, or something implicit that happens
    // before main runs, either in Windows, or our executable.
    //
    // Now *nothing* should take down Windows, but we can't do anything about
    // that. Do we have two computers with faulty hardware? How can we find out.
    //
    // The take down is less of an instant crash, and more of a
    // grind-to-halt. Windows starts missing frames and sound buffer output. It
    // still accepts cursor input for a while, but that looks jumpy because of
    // all the missed frames. After about 5-10 seconds, the computer reboots.
    //
    // On the laptop, this used to happen quite often, even for other
    // applications. On the desktop, it has only happened when we attempt to run
    // our game so far. Are these even the same problem?

    let time_start = Instant::now();

    #[cfg(feature = "ph_developer")]
    install_logger(time_start);
    #[cfg(feature = "ph_developer")]
    install_panic_hook();

    #[cfg(feature = "ph_profile")]
    tracy_client::Client::start();

    log::info!("-------------- Starting event loop and opening window... --------------");

    let event_loop = winit::event_loop::EventLoop::new();
    let window = winit::window::WindowBuilder::new()
        .with_title("Pointy Hat")
        .with_inner_size(winit::dpi::LogicalSize::new(1280, 720))
        // .with_maximized(true)
        // .with_window_icon(Some(icon))
        .build(&event_loop)
        .unwrap();

    let initial_window_scale_factor = window.scale_factor();
    let initial_window_physical_size = window.inner_size();

    let mut allocator = {
        // TODO(yan): @Speed Something about this allocation is really slow (try
        // changing to 1GB, e.g.). What is it? Zeroing the memory (here or in
        // Linear)? Something else? Do we switch VirtualAlloc on Windows?
        let memory = vec![0u8; megabytes(512)];
        let memory_slice = memory.leak();
        let memory_ptr = NonNull::new(memory_slice.as_mut_ptr()).unwrap();
        let memory_len = memory_slice.len();

        let allocator_result = unsafe {
            Linear::new(
                memory_ptr,
                memory_len,
                &LinearOptions {
                    fill_with_zeros: false,
                },
            )
        };

        allocator_result.unwrap()
    };

    let mut renderer = WgpuRenderer::new(
        &window,
        uvec2(
            initial_window_physical_size.width,
            initial_window_physical_size.height,
        ),
        initial_window_scale_factor as f32,
    );

    let mut game_input = Input {
        dtime: Duration::ZERO,

        window_scale_factor: initial_window_scale_factor as f32,
        physical_window_size: uvec2(
            initial_window_physical_size.width,
            initial_window_physical_size.height,
        ),
        physical_cursor_position: Vec2::ZERO,
        physical_scroll_delta: Vec2::ZERO,
        mouse_motion: Vec2::ZERO,

        keys: ArrayVec::new(),
        mbs: ArrayVec::new(),
        chars: ArrayVec::new(),
    };

    let mut game = ph::init(&mut allocator, &WinitPlatform, &mut renderer, &game_input);

    let mut focused = true;
    let mut time = time_start;

    event_loop.run(move |event, _, control_flow| {
        *control_flow = winit::event_loop::ControlFlow::Poll;

        match event {
            winit::event::Event::NewEvents(_) => {
                profile_start_frame!();
                profile_scope!("winit::event::Event::NewEvents");

                let time_now = Instant::now();

                let dtime = time_now.duration_since(time);
                time = time_now;

                game_input.dtime = dtime;

                game_input.physical_scroll_delta = Vec2::ZERO;
                game_input.mouse_motion = Vec2::ZERO;

                game_input.keys.clear();
                game_input.mbs.clear();
                game_input.chars.clear();
            }

            winit::event::Event::WindowEvent { event, .. } => match event {
                winit::event::WindowEvent::Resized(physical_size) => {
                    game_input.physical_window_size =
                        uvec2(physical_size.width, physical_size.height);

                    renderer.set_window_size(uvec2(physical_size.width, physical_size.height));
                }
                winit::event::WindowEvent::ScaleFactorChanged { scale_factor, .. } => {
                    game_input.window_scale_factor = scale_factor as f32;
                    renderer.set_window_scale_factor(scale_factor as f32);
                }
                winit::event::WindowEvent::CloseRequested => {
                    *control_flow = winit::event_loop::ControlFlow::Exit;
                }
                winit::event::WindowEvent::Focused(f) => {
                    focused = f;
                    log::debug!("Focused: {f}");
                }
                winit::event::WindowEvent::ReceivedCharacter(c) => {
                    game_input
                        .chars
                        .try_push(c)
                        .unwrap_or_else(|_| log::warn!("Dropped input char {c}"));
                }
                winit::event::WindowEvent::KeyboardInput { input, .. } => {
                    if focused {
                        let state = match input.state {
                            winit::event::ElementState::Pressed => KeyState::Press,
                            winit::event::ElementState::Released => KeyState::Release,
                        };

                        if let Some(virtual_keycode) = input.virtual_keycode {
                            if let Some(key) = virtual_keycode_to_key(virtual_keycode) {
                                game_input.keys.try_push((key, state)).unwrap_or_else(|_| {
                                    log::warn!("Dropped input key {key} ({state})");
                                });
                            }
                        }
                    }
                }
                winit::event::WindowEvent::CursorMoved {
                    position: physical_position,
                    ..
                } => {
                    game_input.physical_cursor_position =
                        vec2(physical_position.x as f32, physical_position.y as f32);
                }
                winit::event::WindowEvent::MouseWheel { delta, .. } => match delta {
                    winit::event::MouseScrollDelta::LineDelta(dx, dy) => {
                        game_input.physical_scroll_delta += 50.0 * Vec2::new(dx, dy);
                    }
                    winit::event::MouseScrollDelta::PixelDelta(physical_position) => {
                        game_input.physical_scroll_delta +=
                            Vec2::new(physical_position.x as f32, physical_position.y as f32);
                    }
                },
                winit::event::WindowEvent::MouseInput { state, button, .. } => {
                    let state = match state {
                        winit::event::ElementState::Pressed => KeyState::Press,
                        winit::event::ElementState::Released => KeyState::Release,
                    };

                    match button {
                        winit::event::MouseButton::Left => {
                            game_input
                                .mbs
                                .try_push((Mb::Left, state))
                                .unwrap_or_else(|_| log::warn!("Dropped mouse input Left"));
                        }
                        winit::event::MouseButton::Right => {
                            game_input
                                .mbs
                                .try_push((Mb::Left, state))
                                .unwrap_or_else(|_| log::warn!("Dropped mouse input Right"));
                        }
                        winit::event::MouseButton::Middle => {
                            game_input
                                .mbs
                                .try_push((Mb::Middle, state))
                                .unwrap_or_else(|_| log::warn!("Dropped mouse input Middle"));
                        }
                        _ => (),
                    }
                }
                _ => (),
            },

            winit::event::Event::DeviceEvent {
                event: winit::event::DeviceEvent::MouseMotion { delta },
                ..
            } => {
                if focused {
                    game_input.mouse_motion += vec2(delta.0 as f32, delta.1 as f32);
                }
            }

            winit::event::Event::MainEventsCleared => {
                profile_scope!("winit::event::Event::MainEventsCleared");
                ph::update(&mut game, &WinitPlatform, &mut renderer, &game_input);

                window.request_redraw();
            }

            winit::event::Event::RedrawRequested(_) => {
                profile_scope!("winit::event::Event::RedrawRequested");
                ph::render(&mut game, &mut renderer, &game_input);
            }

            winit::event::Event::RedrawEventsCleared => (),

            _ => (),
        }
    });
}

fn virtual_keycode_to_key(virtual_keycode: winit::event::VirtualKeyCode) -> Option<Key> {
    use winit::event::VirtualKeyCode;

    match virtual_keycode {
        VirtualKeyCode::Key0 => Some(Key::Num0),
        VirtualKeyCode::Key1 => Some(Key::Num1),
        VirtualKeyCode::Key2 => Some(Key::Num2),
        VirtualKeyCode::Key3 => Some(Key::Num3),
        VirtualKeyCode::Key4 => Some(Key::Num4),
        VirtualKeyCode::Key5 => Some(Key::Num5),
        VirtualKeyCode::Key6 => Some(Key::Num6),
        VirtualKeyCode::Key7 => Some(Key::Num7),
        VirtualKeyCode::Key8 => Some(Key::Num8),
        VirtualKeyCode::Key9 => Some(Key::Num9),

        VirtualKeyCode::A => Some(Key::A),
        VirtualKeyCode::B => Some(Key::B),
        VirtualKeyCode::C => Some(Key::C),
        VirtualKeyCode::D => Some(Key::D),
        VirtualKeyCode::E => Some(Key::E),
        VirtualKeyCode::F => Some(Key::F),
        VirtualKeyCode::G => Some(Key::G),
        VirtualKeyCode::H => Some(Key::H),
        VirtualKeyCode::I => Some(Key::I),
        VirtualKeyCode::J => Some(Key::J),
        VirtualKeyCode::K => Some(Key::K),
        VirtualKeyCode::L => Some(Key::L),
        VirtualKeyCode::M => Some(Key::M),
        VirtualKeyCode::N => Some(Key::N),
        VirtualKeyCode::O => Some(Key::O),
        VirtualKeyCode::P => Some(Key::P),
        VirtualKeyCode::Q => Some(Key::Q),
        VirtualKeyCode::R => Some(Key::R),
        VirtualKeyCode::S => Some(Key::S),
        VirtualKeyCode::T => Some(Key::T),
        VirtualKeyCode::U => Some(Key::U),
        VirtualKeyCode::V => Some(Key::V),
        VirtualKeyCode::W => Some(Key::W),
        VirtualKeyCode::X => Some(Key::X),
        VirtualKeyCode::Y => Some(Key::Y),
        VirtualKeyCode::Z => Some(Key::Z),

        VirtualKeyCode::Grave => Some(Key::Grave),
        VirtualKeyCode::Equals => Some(Key::Equals),
        VirtualKeyCode::Minus => Some(Key::Minus),
        VirtualKeyCode::LBracket => Some(Key::LBracket),
        VirtualKeyCode::RBracket => Some(Key::RBracket),
        VirtualKeyCode::Backslash => Some(Key::Backslash),
        VirtualKeyCode::Semicolon => Some(Key::Semicolon),
        VirtualKeyCode::Apostrophe => Some(Key::Apostrophe),
        VirtualKeyCode::Comma => Some(Key::Comma),
        VirtualKeyCode::Period => Some(Key::Period),
        VirtualKeyCode::Slash => Some(Key::Slash),

        VirtualKeyCode::F1 => Some(Key::F1),
        VirtualKeyCode::F2 => Some(Key::F2),
        VirtualKeyCode::F3 => Some(Key::F3),
        VirtualKeyCode::F4 => Some(Key::F4),
        VirtualKeyCode::F5 => Some(Key::F5),
        VirtualKeyCode::F6 => Some(Key::F6),
        VirtualKeyCode::F7 => Some(Key::F7),
        VirtualKeyCode::F8 => Some(Key::F8),
        VirtualKeyCode::F9 => Some(Key::F9),
        VirtualKeyCode::F10 => Some(Key::F10),
        VirtualKeyCode::F11 => Some(Key::F11),
        VirtualKeyCode::F12 => Some(Key::F12),

        VirtualKeyCode::Up => Some(Key::Up),
        VirtualKeyCode::Down => Some(Key::Down),
        VirtualKeyCode::Left => Some(Key::Left),
        VirtualKeyCode::Right => Some(Key::Right),

        VirtualKeyCode::Back => Some(Key::Backspace),
        VirtualKeyCode::Return => Some(Key::Return),
        VirtualKeyCode::Space => Some(Key::Space),
        VirtualKeyCode::Tab => Some(Key::Tab),
        VirtualKeyCode::Escape => Some(Key::Esc),
        VirtualKeyCode::Insert => Some(Key::Insert),
        VirtualKeyCode::Home => Some(Key::Home),
        VirtualKeyCode::Delete => Some(Key::Delete),
        VirtualKeyCode::End => Some(Key::End),
        VirtualKeyCode::PageUp => Some(Key::PageUp),
        VirtualKeyCode::PageDown => Some(Key::PageDown),

        VirtualKeyCode::LControl | VirtualKeyCode::RControl => Some(Key::Control),
        VirtualKeyCode::LAlt | VirtualKeyCode::RAlt => Some(Key::Alt),
        VirtualKeyCode::LShift | VirtualKeyCode::RShift => Some(Key::Shift),

        _ => None,
    }
}

#[cfg(feature = "ph_developer")]
fn install_logger(time_start: Instant) {
    use fern::colors::{Color, ColoredLevelConfig};

    // TODO(yan): Real log path or disable logs for shipping builds.
    static LOG_PATH: &str = concat!("./logs/", env!("GIT_COMMIT_HASH"), ".log");

    const APP_LEVEL_FILTER: log::LevelFilter = log::LevelFilter::Debug;
    const LIB_LEVEL_FILTER: log::LevelFilter = log::LevelFilter::Warn;

    let colors = ColoredLevelConfig::new()
        .error(Color::Red)
        .warn(Color::Yellow)
        .info(Color::Cyan)
        .debug(Color::BrightWhite)
        .trace(Color::White);

    let _ = fs::create_dir("./logs");
    let log_file = fern::log_file(LOG_PATH);

    let mut config = fern::Dispatch::new()
        .level(LIB_LEVEL_FILTER)
        .level_for("ph", APP_LEVEL_FILTER)
        .level_for("ph_platform", APP_LEVEL_FILTER)
        .level_for("ph_platform_winit", APP_LEVEL_FILTER)
        .level_for("ph_renderer", APP_LEVEL_FILTER)
        .level_for("ph_renderer_wgpu", APP_LEVEL_FILTER)
        .level_for("guise", APP_LEVEL_FILTER)
        .chain(
            fern::Dispatch::new()
                .format(move |out, message, record| {
                    let t = time_start.elapsed();
                    out.finish(format_args!(
                        "[{:>3}.{:0>6}][{:>5}][{:<17}] {}",
                        t.as_secs(),
                        t.subsec_micros(),
                        colors.color(record.level()),
                        record.target(),
                        message
                    ));
                })
                .chain(std::io::stdout()),
        );

    let mut log_file_success = true;
    if let Ok(log_file) = log_file {
        config = config.chain(
            fern::Dispatch::new()
                .format(move |out, message, record| {
                    let t = time_start.elapsed();
                    out.finish(format_args!(
                        "[{:>3}.{:0>6}][{:>5}][{:<17}] {}",
                        t.as_secs(),
                        t.subsec_micros(),
                        record.level(),
                        record.target(),
                        message
                    ));
                })
                .chain(log_file),
        );
    } else {
        log_file_success = false;
    }

    let _ = config.apply();

    if !log_file_success {
        log::error!("Failed to open log file at {LOG_PATH}");
    }
}

fn install_panic_hook() {
    // Keep original hook, so we can call it too. This hook will e.g. print the
    // backtrace, if we do RUST_BACKTRACE=1.
    let original_hook = panic::take_hook();
    panic::set_hook(Box::new(move |info| {
        let thread = thread::current();
        let thread = thread.name().unwrap_or("<unnamed>");

        let msg = match info.payload().downcast_ref::<&'static str>() {
            Some(s) => *s,
            None => match info.payload().downcast_ref::<String>() {
                Some(s) => &**s,
                None => "Box<Any>",
            },
        };

        match info.location() {
            Some(location) => {
                log::error!(
                    target: "panic", "thread '{}' panicked at '{}': {}:{}",
                    thread,
                    msg,
                    location.file(),
                    location.line(),
                );
            }
            None => log::error!(
                target: "panic",
                "thread '{}' panicked at '{}'",
                thread,
                msg,
            ),
        }

        original_hook(info);
    }));
}
