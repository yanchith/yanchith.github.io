macro_rules! profile_scope {
    ($name:expr) => {
        #[cfg(feature = "ph_profile")]
        let _span = tracy_client::span!($name);
    };
}

macro_rules! profile_start_frame {
    () => {
        #[cfg(feature = "ph_profile")]
        tracy_client::non_continuous_frame!("Frame");
    };
}
