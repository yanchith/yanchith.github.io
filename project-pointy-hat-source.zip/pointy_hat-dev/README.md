# Game 1

## Artists

First get a build of the game from somewhere.

### Controls Cheatsheet

#### In game and editor

- `(F1)`      Switch between game and editor.

- `(Ctrl+F1)` Switch between game and editor and open current level.

- `(F2)`      Switch to camera mode, which you can control with movement keys (WASDQE)
              and the mouse. Press Shift to move faster.

- `(F3)`      Switch between color and depth map. If your screen is all white, you
              accidentally pressed this. Press again to go back to normal.

#### In game

- `(WASD)`    Character movement
- `(QE)`      Character orientation (TODO(yan): Consider changing to SHIFT+WASD)
- `(X)`       Interact
- `(TAB)`     Cycle between characters
- `(Z)`       Undo
- `(R)`       Restart level

#### In editor

- `(ESC)`      Activate select tool. When in select tool, click or click+drag to
               select entities. Optionally hold down Ctrl while clicking to toggle
               selection.

- `(A)`        Select all entities in level if select tool is active.

- `(V)`        Activate move tool. Use movement keys `(WASDQE)` to move selected entities.

- `(DELETE)`   Deleted selected entities.

- `(Alt)`      Activate eyedropper tool. Click an entity while holding Alt to pick an
               entity for your entity brush tool `(B)`.

- `(B)`        Activate entity brush tool. Click or click & drag to paint the entity you
               have picked in the level.

- `(E)`        Activate eraser tool. Click or click & drag to remove entities from the
               level.

- `(Z)`        Undo

- `(Shift+Z)`  Redo

- `(Ctrl+S)`   Save current level

- `(O)`        Open a level

- `(K)`        Close current level

- `([)`        Switch to previous open level

- `(])`        Switch to next open level


### Known Bugs

- Rectangle selection in editor can in some cases fail to select things, if the
  rectangle is too thin. I know about this, but fixing it is too involved to do
  right now. If it doesn't pick up your selection, try drawing a slightly
  thicker rectangle.

- Entity brush in editor can sometimes paint unpredictably. When entity brushing
  on a surface made out of entities (e.g. brushing a second layer of ground),
  sometimes multiple brush preview cubes appear (in various positions), and
  possibly multiple entities are added. If you see this happening, try avoiding
  it by not dragging around the cursor and just single-click where you want to
  place the entity.

- There is a limit of 4 entities per tile. The game crashes if exceeded.


## Programmers

Make sure you have the following installed:

- [Rust](https://rustup.rs/)
- [Dependencies for `shaderc-sys`](https://github.com/google/shaderc-rs#building-from-source)
- Optional: [LunarG Vulkan SDK](https://www.lunarg.com/vulkan-sdk/) (tested with 1.2.162.1)

Project tasks:

- `cargo build` and `cargo build --release`
- `cargo run` and `cargo run --release`
- `cargo clippy` and `cargo clippy -- -W clippy::pedantic`
- `cargo fmt` and `cargo fmt -- --check`
- `cargo doc` and `cargo doc --open`
- `cargo test`
- `./check.sh` and `check.bat` for checking in isolation to prevent #![no_std] poisoning
